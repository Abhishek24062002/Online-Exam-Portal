﻿using Microsoft.AspNetCore.SignalR.Client;

class Program
{
    static async Task Main(string[] args)
    {
        var cancellationTokenSource = new CancellationTokenSource();

        Console.CancelKeyPress += (s, e) =>
        {
            cancellationTokenSource.Cancel();
            e.Cancel = true;
        };

        var connection = new HubConnectionBuilder()
            .WithUrl("http://localhost:7201/approvalHub")
            .Build();

        connection.On<string>("ReceiveNotification", (message) =>
        {
            Console.WriteLine($"🔔 Notification Received: {message}");
        });

        await connection.StartAsync();
        Console.WriteLine("✅ Connected. Press Ctrl+C to exit.");

        await Task.Delay(-1, cancellationTokenSource.Token);
    }
}
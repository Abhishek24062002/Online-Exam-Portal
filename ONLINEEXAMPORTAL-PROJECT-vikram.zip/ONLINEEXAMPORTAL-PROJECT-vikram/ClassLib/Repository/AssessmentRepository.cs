﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class AssessmentRepository : IAssessmentRepository
    {
        private readonly AppDbContext _context;

        public AssessmentRepository(AppDbContext context)
        {
            _context = context;
        }
        

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            List<object> result = new List<object>();
             var assessments = await _context.Assessments.Include(a=>a.Package).ToListAsync();
           // var assessments = await _context.Assessments.Include(a=> a.Package).ToListAsync();           
            foreach (var a in assessments)
            {
                var item = new
                {
                    a.AssessmentId,
                    a.Title,
                    a.Description,
                    a.AssessmentType,
                    a.Status,
                    a.ScheduledDate,
                    a.EndTime,
                    a.Duration,
                    a.MaxMark,
                    a.PassMark,
                    a.packageId
                   // a.CreatedByUserId
                };
                result.Add(item);
            }


           

            return result;
           
        }
        public async Task<IEnumerable<object>> GetPackages(int Id)
        {

            //List<object> result = new List<object>();
            //// var assessments = await _context.Assessments.ToListAsync();
            //var assessments = await _context.Assessments.Include(a => a.Package).Where(x=> x.CreatedByUserId==Id).Distinct().ToListAsync();
            
            //List<object> packages = new List<object>();
            //var ass = assessments.LastOrDefault(x => x.Package.PackageId == packageId);
            //var asc = ass.Package.Assessments.ToList();
            //foreach (var a in asc)
            //{
            //    var item = new
            //    {
            //        a.AssessmentId,
            //        a.Title,
            //        a.Description,
            //        a.AssessmentType,
            //        a.Status,
            //        a.ScheduledDate,
            //        a.EndTime,
            //        a.Duration,
            //        a.MaxMark,
            //        a.PassMark,
            //        a.packageId,
            //        a.CreatedByUserId
            //    };
            //    packages.Add(item);
            //    Console.WriteLine("AssesmentList: " + item.ToString());

            //}

            //foreach (var a in assessments)
            //{
            //    var item = new
            //    {
                    //a.AssessmentId,
                    //a.Title,
                    //a.Description,
                    //a.AssessmentType,
                    //a.Status,
                    //a.ScheduledDate,
                    //a.EndTime,
                    //a.Duration,
                    //a.MaxMark,
                    //a.PassMark,
                    //a.packageId
            //        a.Package
            //    };
               
            //    packages.Add(item);
            //}


            //return packages;

            var assessments = await _context.Assessments
            .Include(a => a.Package)
            .Where(x => x.CreatedByUserId == Id && x.Package != null)
            .ToListAsync();

            // Get distinct packages by PackageId
            var distinctPackages = assessments
                .Select(a => a.Package)
                .Where(p => p != null)
                .GroupBy(p => p.PackageId)
                .Select(g => g.First())
                .ToList();
            return distinctPackages;

        }


        public async Task<IEnumerable<object>> GetByIdAsync(int id)
        {
            List<object> result = new List<object>();
            var assessment = await _context.Assessments.FirstOrDefaultAsync(x => x.AssessmentId == id);

            if (assessment != null)
            {
                var item = new
                {
                    assessment.AssessmentId,
                    assessment.Title,
                    assessment.Description,
                    assessment.AssessmentType,
                    assessment.Status,
                    assessment.ScheduledDate,
                    assessment.EndTime,
                    assessment.Duration,
                    assessment.MaxMark,
                    assessment.PassMark
                };
                result.Add(item);
            }

            return result;
        }

        public async Task<IEnumerable<object>> GetAssessmentsByKeywordAsync(string keyword)
        {
            List<object> result = new List<object>();
            var assessments = await _context.Assessments.ToListAsync();

            foreach (var a in assessments)
            {
                if (a.Title != null && a.Title.Contains(keyword))
                {
                    var item = new
                    {
                        a.AssessmentId,
                        a.Title,
                        a.Description,
                        a.AssessmentType
                    };
                    result.Add(item);
                }
            }

            return result;
        }

        public async Task<Assessment> AddAsync(CreateAssessmentDto dto)
        {
            // Step 1: Validate packageId existence (if provided)
            AssessmentPackage validPackage = null;

            if (dto.packageId.HasValue && dto.packageId.Value > 0)
            {
                validPackage = await _context.AssessmentPackages
                    .FirstOrDefaultAsync(p => p.PackageId == dto.packageId.Value);

                if (validPackage == null)
                {
                    throw new InvalidOperationException($"Package with ID {dto.packageId.Value} not found.");
                }
            }

            // Step 2: Create the assessment entity
            var assessment = new Assessment
            {
                Title = dto.Title,
                Description = dto.Description,
                ScheduledDate = dto.ScheduledDate,
                Duration = dto.Duration,
                MaxMark = dto.MaxMark,
                PassMark = dto.PassMark,
                Status = dto.Status,
                EndTime = dto.EndTime,
                AssessmentType = dto.AssessmentType,
                CreatedByUserId = dto.CreatedByUserId,
                packageId = validPackage?.PackageId
            };

            _context.Assessments.Add(assessment);
            await _context.SaveChangesAsync();

            return assessment;
        }

        





        public async Task<bool> UpdateAsync(int id, CreateAssessmentDto updated)
        {
            var existing = await _context.Assessments.FindAsync(id);
            if (existing == null)
                return false;

            existing.Title = updated.Title;
            existing.Description = updated.Description;
            existing.AssessmentType = updated.AssessmentType;
            existing.ScheduledDate = updated.ScheduledDate;
            existing.EndTime = updated.EndTime;
            existing.Duration = updated.Duration;
            existing.MaxMark = updated.MaxMark;
            existing.PassMark = updated.PassMark;
            existing.Status = updated.Status;

            await _context.SaveChangesAsync();
            return true;
        }


        //public async Task<bool> DeleteAsync(int id)
        //{
        //    var assessment = await _context.Assessments.FindAsync(id);
        //    if (assessment == null) return false;

        //    _context.Assessments.Remove(assessment);
        //    await _context.SaveChangesAsync();
        //    return true;
        //}
        public async Task<bool> DeleteAsync(int id)

        {

            using var transaction = await _context.Database.BeginTransactionAsync();

            try

            {

                var assessment = await _context.Assessments.FindAsync(id);

                if (assessment == null) return false;

                // Get related Questions

                var questions = _context.Questions.Where(q => q.AssessmentId == id).ToList();

                // Get Question IDs

                var questionIds = questions.Select(q => q.QuestionId).ToList();

                // Delete Options linked to those Questions

                var options = _context.Options.Where(o => questionIds.Contains(o.QuestionId));

                _context.Options.RemoveRange(options);

                // Delete Questions

                _context.Questions.RemoveRange(questions);

                // Delete directly linked entities

                _context.Responses.RemoveRange(_context.Responses.Where(r => r.AssessmentId == id));

                _context.ExamAttempts.RemoveRange(_context.ExamAttempts.Where(e => e.AssessmentId == id));

                _context.Feedbacks.RemoveRange(_context.Feedbacks.Where(f => f.AssessmentId == id));

                // _context.Reports.RemoveRange(_context.Reports.Where(r => r.AssessmentId == id));

                _context.AssessmentAssignments.RemoveRange(_context.AssessmentAssignments.Where(a => a.AssessmentId == id));

                //_context.AssessmentPackages.RemoveRange(_context.AssessmentPackages.Where(p => p.AssessmentId == id));

                // _context.CandidateRequests.RemoveRange(_context.CandidateRequests.Where(c => c.AssessmentId == id));

                // _context.InstructorRequestViews.RemoveRange(_context.InstructorRequestViews.Where(i => i.AssessmentId == id));

                // _context.InstructorApprovals.RemoveRange(_context.InstructorApprovals.Where(i => i.AssessmentId == id));

                // Finally, delete the assessment

                _context.Assessments.Remove(assessment);

                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                return true;

            }

            catch (Exception)

            {

                await transaction.RollbackAsync();

                throw;

            }

        }


        public async Task<IEnumerable<object>> GetAssessmentsByPackageNameAsync(string packageName)
        {
            List<object> result = new List<object>();
            var packages = await _context.AssessmentPackages
                                          .Include(p => p.Assessments)
                                          .ToListAsync();

            foreach (var pack in packages)
            {
                if (pack.PackageName == packageName)
                {
                    foreach (var a in pack.Assessments)
                    {
                        var item = new
                        {
                            a.AssessmentId,
                            a.Title,
                            a.Description,
                            a.AssessmentType,
                            a.MaxMark,
                            a.PassMark
                        };
                        result.Add(item);
                    }
                }
            }

            return result;
        }

        //public async Task<IEnumerable<object>> GetAssessmentsByCreatorIdAsync(int userId)
        //{
        //    List<object> result = new List<object>();
        //    var assessments = await _context.Assessments.ToListAsync();

        //    foreach (var a in assessments)
        //    {
        //        if (a.CreatedByUserId == userId)
        //        {
        //            var item = new
        //            {
        //                a.AssessmentId,
        //                a.Title,
        //                a.Description,
        //                a.AssessmentType,
        //                a.Status
        //            };
        //            result.Add(item);
        //        }
        //    }

        //    return result;
        //}

        public async Task<IEnumerable<object>> GetAssessmentsByCreatorIdAsync(int userId)
        {
            List<object> result = new List<object>();
            var assessments = await _context.Assessments.ToListAsync();

            foreach (var a in assessments)
            {
                if (a.CreatedByUserId == userId)
                {
                    var item = new
                    {
                        a.AssessmentId,
                        a.Title,
                        a.Description,
                        a.AssessmentType,
                        a.Status,
                        a.ScheduledDate,
                        a.PassMark,
                        a.MaxMark,
                        a.EndTime,
                        a.Duration
                    };
                    result.Add(item);
                }
            }

            return result;


        }

        public async Task<IEnumerable<object>> GetAssignedAssessmentsByUserIdAsync(int userId)
        {
            List<object> result = new List<object>();
            var assignments = await _context.AssessmentAssignments
                                            .Include(a => a.Assessment)
                                            .ToListAsync();

            foreach (var assign in assignments)
            {
                if (assign.UserId == userId && assign.Assessment != null)
                {
                    var item = new
                    {
                        assign.AssignmentId,
                        assign.Assessment.AssessmentId,
                        assign.Assessment.Title,
                        assign.Assessment.Description,
                        assign.Assessment.AssessmentType,
                        assign.Assessment.ScheduledDate,
                        assign.Assessment.EndTime,
                        assign.Assessment.Status,
                        assign.Assessment.Duration
                    };
                    result.Add(item);
                }
            }

            return result;
        }

        public async Task<IEnumerable<object>> GetQuestionsWithOptionsByAssessmentIdAsync(int assessmentId)
        {
            List<object> result = new List<object>();
            var questions = await _context.Questions
                                          .Include(q => q.Options)
                                          .ToListAsync();

            foreach (var q in questions)
            {
                if (q.AssessmentId == assessmentId)
                {
                    List<object> optionsList = new List<object>();
                    foreach (var o in q.Options)
                    {
                        var optionData = new
                        {
                            o.OptionId,
                            o.OptionsText,
                            o.Answer
                        };
                        optionsList.Add(optionData);
                    }

                    var questionData = new
                    {
                        q.QuestionId,
                        q.QuestionText,
                        q.QuestionType,
                        q.Mark,
                        //q.IsAttempted,
                        Options = optionsList
                    };
                    result.Add(questionData);
                }
            }

            return result;
        }

        public async Task<IEnumerable<object>> GetQuestionsWithOptionsExamByAssessmentIdAsync(int assessmentId)
        {
            List<object> result = new List<object>();

            var questions = await _context.Questions.Include(q => q.Options).ToListAsync();

            foreach (var q in questions)
            {
                if (q.AssessmentId == assessmentId)
                {

                    List<object> optionsList = new List<object>();

                    foreach (var o in q.Options)
                    {
                        var optionData = new
                        {
                           
                            o.OptionsText
                        };

                        optionsList.Add(optionData);
                    }

                    var questionData = new
                    {
                       
                        q.QuestionText,
                       
                        q.Mark,
                        Options = optionsList
                    };

                    result.Add(questionData);

                }



            }

            return result;


        }
        public async Task<int> GetObtainedMarkByUserAsync(int userId, int assessmentId)
        {
            int totalMark = 0;
            var responses = await _context.Responses.ToListAsync();

            foreach (var r in responses)
            {
                if (r.UserId == userId && r.AssessmentId == assessmentId)
                {
                    totalMark += r.ObtainedMark;
                }
            }

            return totalMark;
        }

        public async Task<object> GetAssessmentSummaryAsync(int assessmentId)
        {
            var assessment = await _context.Assessments.FindAsync(assessmentId);
            if (assessment == null)
            {
                return new { Message = "Assessment not found." };
            }

            int passMark = assessment.PassMark;

            var scoresQuery =
                from r in _context.Responses
                where r.AssessmentId == assessmentId
                group r by r.UserId into g
                select new
                {
                    UserId = g.Key,
                    TotalMark = g.Sum(x => x.ObtainedMark),
                    IsPassed = g.Sum(x => x.ObtainedMark) >= passMark,
                    RawMarks = g.Select(x => x.ObtainedMark).ToList()
                };

            var scores = await scoresQuery.ToListAsync();

            var passed =
                from s in scores
                where s.IsPassed
                select s;

            var failed =
                from s in scores
                where !s.IsPassed
                select s;

            return new
            {
                AssessmentId = assessmentId,
                PassMark = passMark,
                TotalUsers = scores.Count,
                PassedUsers = passed.Count(),
                FailedUsers = failed.Count(),
                Users = scores
            };
        }
        //change
        public async Task<IEnumerable<object>> GetUsersByAssessmentAsync(int assessmentId)
        {
            var userIdsQuery =
                from r in _context.Responses
                where r.AssessmentId == assessmentId
                select r.UserId;

            var userIds = await userIdsQuery.Distinct().ToListAsync();

            var userQuery =
                from u in _context.Users
                where userIds.Contains(u.UserId)
                select new
                {
                    u.UserId,
                    u.Name,
                    u.Email
                };

            return await userQuery.ToListAsync();
        }

    }
}

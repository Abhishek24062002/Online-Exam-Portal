﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class CandidateRequestRepository : ICandidateRequestRepository
    {
        private readonly AppDbContext _context;

        public CandidateRequestRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<string?> SaveAsync(CandidateRequest request)
        {
            _context.CandidateRequests.Add(request);
            var response= await _context.SaveChangesAsync();
            return response != null ? "request raised" : null;
          
        }

        public async Task<IEnumerable<CandidateRequestDTO?>> GetAllAsync()
        {
            return await _context.CandidateRequests
                .Select(r => new CandidateRequestDTO
                {

                    UserId = r.UserId,
                    PackageId = r.PackageId,
                    RequestStatus = r.RequestStatus
                }).ToListAsync();
            
        }

        public async Task<IEnumerable<CandidateRequest?>> GetAll()
        {
           
            return await _context.CandidateRequests.ToListAsync();
        }

        public async Task<CandidateRequestDTO?> GetByIdAsync(int id)
        {
            var r = await _context.CandidateRequests.FindAsync(id);
            return r == null ? null : new CandidateRequestDTO
            {
                
                UserId = r.UserId,
                PackageId = r.PackageId,
                
                RequestStatus = r.RequestStatus
            };
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var r = await _context.Set<CandidateRequest>().FindAsync(id);
            if (r == null) return false;

            _context.Set<CandidateRequest>().Remove(r);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<CandidateRequestDTO>> GetByUserIdAsync(int userId)
        {
            return await _context.Set<CandidateRequest>()
                .Where(r => r.UserId == userId)
                .Select(r => new CandidateRequestDTO
                {
                  
                    UserId = r.UserId,
                    PackageId = r.PackageId,
                   
                    RequestStatus = r.RequestStatus
                }).ToListAsync();
        }

        public async Task<IEnumerable<CandidateRequestDTO>> GetByStatusAsync(string status)
        {
            if (!Enum.TryParse<RequestStatus>(status, true, out var parsedStatus))
                return Enumerable.Empty<CandidateRequestDTO>();

            return await _context.Set<CandidateRequest>()
                .Where(r => r.RequestStatus == parsedStatus)
                .Select(r => new CandidateRequestDTO
                {
                   
                    UserId = r.UserId,
                    PackageId = r.PackageId,
                  
                    RequestStatus = r.RequestStatus
                }).ToListAsync();
        }

        public void CreateRaiseApproval(InstructorRequestView raiseApproval)
        {
            _context.InstructorRequestViews.Add(raiseApproval);
            _context.SaveChanges();
        }
    }
}


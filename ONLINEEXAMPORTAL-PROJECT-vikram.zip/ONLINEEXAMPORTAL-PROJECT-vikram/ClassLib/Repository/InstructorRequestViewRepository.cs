﻿using ClassLib.Data;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class InstructorRequestViewRepository : IInstructorRequestViewRepository
    {
        private readonly AppDbContext _context;

        public InstructorRequestViewRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<InstructorRequestView?> FindRequestAsync(int id)
        {
           var response = await _context.InstructorRequestViews.FirstOrDefaultAsync(x => x.RequestId == id);
            if (response == null) { return null; }
            return response;
        }

        

        public async Task<IEnumerable<InstructorRequestView>>GetAllRequestAsync()
        {
            return  await _context.InstructorRequestViews.Include(x => x.User).Include(p=>p.CandidateRequest).ToListAsync();

        }

        public async Task<CandidateRequest> ReflectChange(int requestId)
        {
            var response =await _context.CandidateRequests.Include(x => x.User).FirstOrDefaultAsync(x => x.RequestId == requestId && x.RequestStatus==RequestStatus.Pending);
            return response;
        }

        public void UpdateStatus(CandidateRequest approvalState)
        {
           _context.CandidateRequests.Update(approvalState);
            _context.SaveChanges();
            
        }
       // Candidate
        public void UpdateStatus(InstructorRequestView findRequest)
        {
            _context.InstructorRequestViews.Update(findRequest);
            _context.SaveChanges();

        }
    }
}

﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;

namespace ClassLib.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly AppDbContext _context;

        public ReportRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ReportDetailsDto>> GetReportsAsync(string? assessmentTitle, string? userName)
        {
            var query = _context.Reports
                .Include(r => r.ExamAttempt)
                    .ThenInclude(e => e.AssessmentAssignment)
                        .ThenInclude(a => a.Assessment)
                .Include(r => r.ExamAttempt.AssessmentAssignment.User)
                .Include(r => r.Feedback)
                .AsQueryable();

            if (!string.IsNullOrEmpty(assessmentTitle))
            {
                query = query.Where(r => r.ExamAttempt.AssessmentAssignment.Assessment.Title.Contains(assessmentTitle));
            }

            if (!string.IsNullOrEmpty(userName))
            {
                query = query.Where(r => r.ExamAttempt.AssessmentAssignment.User.Name.Contains(userName));
            }

            return await query.Select(r => new ReportDetailsDto
            {
                UserName = r.ExamAttempt.AssessmentAssignment.User.Name,
                Email = r.ExamAttempt.AssessmentAssignment.User.Email,
                AssessmentTitle = r.ExamAttempt.AssessmentAssignment.Assessment.Title,
                TotalMarkObtained = r.ExamAttempt.TotalMarkObtained,
                FeedbackComments = r.Feedback != null ? r.Feedback.Comments : "No Feedback",
                FeedbackRating = r.Feedback != null ? r.Feedback.Rating : 0
            }).ToListAsync();
        }
    }
}

﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;

public class ExamAttemptRepository : IExamAttemptRepository
{
    private readonly AppDbContext _context;

    public ExamAttemptRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<ExamAttempt>> GetAllAsync()
    {
        return await _context.ExamAttempts
            .Include(e => e.AssessmentAssignment)
            .ToListAsync();
    }

    public async Task<ExamAttempt?> GetByIdAsync(int id)
    {
        return await _context.ExamAttempts
            .Include(e => e.AssessmentAssignment)
            .FirstOrDefaultAsync(e => e.AttemptId == id);
    }

    public async Task AddAsync(ExamAttempt attempt)
    {
        await _context.ExamAttempts.AddAsync(attempt);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(ExamAttempt attempt)
    {
        _context.ExamAttempts.Update(attempt);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var attempt = await _context.ExamAttempts.FindAsync(id);
        if (attempt != null)
        {
            _context.ExamAttempts.Remove(attempt);
            await _context.SaveChangesAsync();
        }
    }

    public int GetAttemptCountByAssessmentId(int assessmentId)
    {
        return _context.ExamAttempts.Count(e => e.AssessmentId == assessmentId);
    }

    public List<UserSummaryDTO> GetUsersByAssessmentId(int assessmentId)
    {
        return _context.ExamAttempts
            .Include(e => e.AssessmentAssignment)
            .Where(e => e.AssessmentId == assessmentId)
            .Select(e => new UserSummaryDTO
            {
                UserId = e.AssessmentAssignment.UserId,
                Name = e.AssessmentAssignment.User.Name
            })
            .ToList();
    }

    public async Task<ExamAttempt?> GetAttemptAsync(int userId, int assessmentId)
    {
        return await _context.ExamAttempts
            .FirstOrDefaultAsync(e => e.UserId == userId && e.AssessmentId == assessmentId);
    }


    public async Task<List<Response>> GetResponsesAsync(int userId, int assessmentId)
    {
        return await _context.Responses
            .Where(r => r.UserId == userId && r.AssessmentId == assessmentId)
            .ToListAsync();
    }

    public async Task<int> GetQuestionCountAsync(int assessmentId)
    {
        return await _context.Questions
            .CountAsync(q => q.AssessmentId == assessmentId);
    }

    public async Task<Assessment?> GetAssessmentAsync(int assessmentId)
    {
        return await _context.Assessments
            .FirstOrDefaultAsync(a => a.AssessmentId == assessmentId);
    }

    public async Task SaveAttemptAsync(ExamAttempt attempt)
    {
        _context.ExamAttempts.Update(attempt);
        await _context.SaveChangesAsync();
    }

    public async Task<ExamAttempt> CreateAttemptAsync(ExamAttempt attempt)
    {
        attempt.AttemptDate = DateTime.UtcNow; 
        await _context.ExamAttempts.AddAsync(attempt);
        await _context.SaveChangesAsync();
        return attempt;
    }

    public AssessmentAssignment? GetAssignment(int userId, int assessmentId)
    {
        return  _context.AssessmentAssignments
            .FirstOrDefault(e => e.UserId == userId && e.AssessmentId == assessmentId);
    }

    public void SaveAssignment(AssessmentAssignment assignment)
    {
        _context.AssessmentAssignments.Update(assignment);
        _context.SaveChanges();
    }

}
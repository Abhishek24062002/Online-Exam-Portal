﻿using ClassLib.Data;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class ResponseRepository : IResponseRepository
    {
        private readonly AppDbContext _context;

        public ResponseRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            var query =
                from r in _context.Responses
                select new
                {
                    r.ResponseId,
                    r.UserId,
                    r.AssessmentId,
                    r.QuestionId,
                    r.OptionId,
                    TotalMark = r.ObtainedMark
                };

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<object>> GetAllAsync(int userId, int assessmentId)
        {
            var query =
                from r in _context.Responses
                where r.UserId == userId && r.AssessmentId == assessmentId
                select new
                {
                    r.ResponseId,
                    r.UserId,
                    r.AssessmentId,
                    r.QuestionId,
                    r.OptionId,
                    TotalMark = r.ObtainedMark
                };

            return await query.ToListAsync();
        }

        public async Task<Response> AddAsync(Response entity)
        {
            // ✅ Get the question and its assessment
            var question = await _context.Questions
                .Include(q => q.Assessment)
                .FirstOrDefaultAsync(q => q.QuestionId == entity.QuestionId);

            if (question == null)
                throw new InvalidOperationException("Question not found.");

            var assessmentId = question.AssessmentId;

            // ✅ Count total questions in the assessment
            var totalQuestions = await _context.Questions
                .CountAsync(q => q.AssessmentId == assessmentId);

            // ✅ Count how many questions the user has already responded to
            var totalResponses = await _context.Responses
                .CountAsync(r => r.UserId == entity.UserId &&
                                 _context.Questions.Any(q => q.QuestionId == r.QuestionId && q.AssessmentId == assessmentId));

            if (totalResponses >= totalQuestions)
            {
                throw new InvalidOperationException("Assessment already completed.");
            }

            // ✅ Get correct option ID
            var correctOptionId = await _context.Options
                .Where(o => o.QuestionId == entity.QuestionId && o.Answer == "True")
                .Select(o => o.OptionId)
                .FirstOrDefaultAsync();

            // ✅ Calculate obtained mark
            entity.ObtainedMark = entity.OptionId == correctOptionId ? question.Mark : 0;

            // ✅ Check for existing response to this question
            var existingResponse = await _context.Responses
                .FirstOrDefaultAsync(r => r.UserId == entity.UserId &&
                                          r.QuestionId == entity.QuestionId);

            if (existingResponse != null)
            {
                // Overwrite existing response
                existingResponse.OptionId = entity.OptionId;
                existingResponse.ObtainedMark = entity.ObtainedMark;
                _context.Responses.Update(existingResponse);
                await _context.SaveChangesAsync();
                return existingResponse;
            }

            // ✅ No previous response — add new
            _context.Responses.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }




        public Task<IEnumerable<object>> GetByIdAsync(int id) => Task.FromResult(Enumerable.Empty<object>());
        public Task<bool> UpdateAsync(int id, Response updated) => Task.FromResult(false);
        public Task<bool> DeleteAsync(int id) => Task.FromResult(false);

        public async Task<List<Response>> GetResponsesByUserAndAssessmentAsync(int userId, int assessmentId)

        {

            return await _context.Responses

                .Where(r => r.UserId == userId && r.AssessmentId == assessmentId)

                .ToListAsync();

        }

        public async Task DeleteResponsesAsync(List<Response> responses)

        {

            _context.Responses.RemoveRange(responses);

            await _context.SaveChangesAsync();

        }

    }
}

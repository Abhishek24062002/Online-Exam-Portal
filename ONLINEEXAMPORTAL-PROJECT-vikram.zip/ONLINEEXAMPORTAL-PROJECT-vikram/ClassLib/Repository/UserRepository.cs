﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;


        public UserRepository(AppDbContext context)
        {
            _context = context;
        }
       
        public Task<UserTable> FindByEmail(string Email)
        {
            throw new NotImplementedException();
        }

        public Task<UserTable> FindById(int id)
        {
            throw new NotImplementedException();
        }

       public async Task<UserTable?>SaveUserAsync(UserTable user)
        {
            _context.Users.Add(user);
            var response = await _context.SaveChangesAsync();
            Console.WriteLine($"Saved user with ID {user.UserId}");
            if (response != 0)
                return user;

            return null;
        }

        public  void SaveInsApprovalAsync(InstructorApproval user)
        {
            _context.InstructorApprovals.Add(user);
             _context.SaveChanges();
            
        }

        public async Task<InstructorApproval?> GetApprovalByUserIdAsync(int userId)
        {
            return await _context.InstructorApprovals
                .FirstOrDefaultAsync(a => a.UserId == userId);
        }

        public async Task UpdateApprovalAsync(InstructorApproval approval)
        {
            _context.InstructorApprovals.Update(approval);
            await _context.SaveChangesAsync();
        }

        public async Task<LoginWithRoleDTO?> FindUserAsync(LoginDTO credentials)
        {

           
            UserTable? user = await _context.Users.FirstOrDefaultAsync(x => x.Email == credentials.Email && x.Password == credentials.Password );
            if (user == null)
            {
                return null;
            }

            if(user.RoleType == RoleType.Admin || user.RoleType == RoleType.Candidate)
            {
               return new LoginWithRoleDTO { Name=user.Name ,Email = user.Email, Password = user.Password ,Role=user.RoleType.ToString()};
            }
            else 
            {
               

                InstructorApproval? approval =await _context.InstructorApprovals.FirstOrDefaultAsync(a => a.UserId == user.UserId);
                //Console.WriteLine(approval.ApprovalStatus + " " + approval.UserId);

                if (approval != null && approval.ApprovalStatus == ApprovalStatus.Approved)
                {
                    // return new LoginDTO { Email = user.Email, Password = user.Password };
                    return new LoginWithRoleDTO {Name=user.Name, Email = user.Email, Password = user.Password, Role = user.RoleType.ToString() };
                }
                return null;
      
            }



        }

        public async Task<UserTable> FindByIdAsync(int id) { 
        //{ var response = await _context.Users.FirstOrDefaultAsync(x => x.UserId == id);
        //    return response;

            var user = _context.Users
    .Include(u => u.CandidateRequests)
    .FirstOrDefault(u => u.UserId == id);

            return user;
        }

        public List<UserTable> FindAll() => _context.Users.Include(a => a.AssessmentAssignments).Include(u => u.CandidateRequests).ToList();

        public  UserTable FindByEmailAsync(string Email)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == Email);
            return user;
        }

        //public async Task< UserTable> Delete(UserTable user)
        //{
        //    var response = _context.Users.Remove(user);
        //    await _context.SaveChangesAsync();

        //    return user;
        //}

        public async Task<bool> DeleteAsync(int id)

        {

            using var transaction = await _context.Database.BeginTransactionAsync();

            try

            {

                var assessment = await _context.Assessments.FindAsync(id);

                if (assessment == null) return false;

                // Get related Questions

                var questions = _context.Questions.Where(q => q.AssessmentId == id).ToList();

                // Get Question IDs

                var questionIds = questions.Select(q => q.QuestionId).ToList();

                // Delete Options linked to those Questions

                var options = _context.Options.Where(o => questionIds.Contains(o.QuestionId));

                _context.Options.RemoveRange(options);

                // Delete Questions

                _context.Questions.RemoveRange(questions);

                // Delete directly linked entities

                _context.Responses.RemoveRange(_context.Responses.Where(r => r.AssessmentId == id));

                _context.ExamAttempts.RemoveRange(_context.ExamAttempts.Where(e => e.AssessmentId == id));

                _context.Feedbacks.RemoveRange(_context.Feedbacks.Where(f => f.AssessmentId == id));

                // _context.Reports.RemoveRange(_context.Reports.Where(r => r.AssessmentId == id));

                _context.AssessmentAssignments.RemoveRange(_context.AssessmentAssignments.Where(a => a.AssessmentId == id));

                //_context.AssessmentPackages.RemoveRange(_context.AssessmentPackages.Where(p => p.AssessmentId == id));

                // _context.CandidateRequests.RemoveRange(_context.CandidateRequests.Where(c => c.AssessmentId == id));

                // _context.InstructorRequestViews.RemoveRange(_context.InstructorRequestViews.Where(i => i.AssessmentId == id));

                // _context.InstructorApprovals.RemoveRange(_context.InstructorApprovals.Where(i => i.AssessmentId == id));

                // Finally, delete the assessment

                _context.Assessments.Remove(assessment);

                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                return true;

            }

            catch (Exception)

            {

                await transaction.RollbackAsync();

                throw;

            }

        }


        public async Task<UserTable> Delete(UserTable user)

        {

            using var transaction = await _context.Database.BeginTransactionAsync();

            try

            {

                int userId = user.UserId;

                // Delete related entities

                _context.Responses.RemoveRange(_context.Responses.Where(r => r.UserId == userId));

                _context.ExamAttempts.RemoveRange(_context.ExamAttempts.Where(e => e.UserId == userId));

                _context.Feedbacks.RemoveRange(_context.Feedbacks.Where(f => f.UserId == userId));

                _context.Reports.RemoveRange(_context.Reports.Where(r => r.UserId == userId));

                _context.AssessmentAssignments.RemoveRange(_context.AssessmentAssignments.Where(a => a.UserId == userId));

                _context.CandidateRequests.RemoveRange(_context.CandidateRequests.Where(c => c.UserId == userId));

                _context.InstructorRequestViews.RemoveRange(_context.InstructorRequestViews.Where(i => i.UserId == userId));

                _context.InstructorApprovals.RemoveRange(_context.InstructorApprovals.Where(i => i.UserId == userId));

                // Delete the user

                _context.Users.Remove(user);

                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                return user;

            }

            catch (Exception)

            {

                await transaction.RollbackAsync();

                throw;

            }

        }


        public async Task<UserTable> GetDetails(string user)
        {
            var item = await _context.Users.Include(a => a.AssessmentAssignments).Include(u => u.CandidateRequests).ThenInclude(s=>s.AssessmentPackage).FirstOrDefaultAsync(x => x.Email == user); 
            if (item != null)
            {
                return item;
            }
            return null;
        }

        public UserTable Update(UserTable user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
            return user;

        }


        public async Task<UserTable?> GetUserByEmailAsync(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<UserTable?> GetUserByResetTokenAsync(string token)
        {
            return await _context.Users.FirstOrDefaultAsync(u =>
            u.PasswordResetToken == token && u.TokenExpiry > DateTime.UtcNow);
        }

        public async Task UpdateUserAsync(UserTable user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public List<InstructorApproval> GetApproveList()
        {
            var users = _context.InstructorApprovals.Include(u => u.User).ToList();
            return users;
        }
    }
}

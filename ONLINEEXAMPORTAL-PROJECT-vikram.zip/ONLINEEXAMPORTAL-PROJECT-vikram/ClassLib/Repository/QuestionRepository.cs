﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class QuestionRepository : IQuestionRepository
    {
        private readonly AppDbContext _context;

        public QuestionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            return await _context.Questions
                .Include(q => q.Options)
                .Select(q => new
                {
                    q.QuestionId,
                    q.QuestionText,
                    q.QuestionType,
                    q.Mark,
                    q.AssessmentId,
                    Options = q.Options.Select(o => new
                    {
                        o.OptionId,
                        o.OptionsText,
                        o.Answer
                    })
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<object>> GetByIdAsync(int id)
        {
            var question = await _context.Questions
                .Where(q => q.QuestionId == id)
                .Include(q => q.Options)
                .Select(q => new
                {
                    q.QuestionId,
                    q.QuestionText,
                    q.QuestionType,
                    q.Mark,
                    q.AssessmentId,
                    Options = q.Options.Select(o => new
                    {
                        o.OptionId,
                        o.OptionsText,
                        o.Answer
                    }).ToList()
                })
                .FirstOrDefaultAsync();

            return question != null ? new[] { question } : Enumerable.Empty<object>();
        }

        public async Task<Question> AddAsync(Question entity)
        {
            _context.Questions.Add(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        //public async Task<bool> UpdateAsync(int id, Question updated)
        //{
        //    var existing = await _context.Questions.FindAsync(id);
        //    if (existing == null) return false;

        //    existing.QuestionText = updated.QuestionText;
        //    existing.QuestionType = updated.QuestionType;
        //    existing.Mark = updated.Mark;
        //    await _context.SaveChangesAsync();
        //    return true;
        //}

        public async Task<bool> UpdateAsync(int id, CreateQuestionDto updated)
        {
            var existing = await _context.Questions
                .Include(q => q.Options)
                .FirstOrDefaultAsync(q => q.QuestionId == id);

            if (existing == null) return false;

            // Update question fields
            existing.QuestionText = updated.QuestionText;
            existing.QuestionType = updated.QuestionType;
            existing.Mark = updated.Mark;

            // Clear existing options and replace with new ones
            _context.Options.RemoveRange(existing.Options);

            var newOptions = updated.Options.Select(o => new Option
            {
                OptionsText = o.OptionsText,
                Answer = o.Answer,
                QuestionId = id
            }).ToList();

            await _context.Options.AddRangeAsync(newOptions);

            await _context.SaveChangesAsync();
            return true;
        }



        //public async Task<bool> DeleteAsync(int id)
        //{
        //    var entity = await _context.Questions.FindAsync(id);
        //    if (entity == null) return false;

        //    _context.Questions.Remove(entity);
        //    await _context.SaveChangesAsync();
        //    return true;
        //}
        public async Task<bool> DeleteAsync(int id)
        {
            var question = await _context.Questions
                .Include(q => q.Options)
                .FirstOrDefaultAsync(q => q.QuestionId == id);

            if (question == null) return false;

            _context.Options.RemoveRange(question.Options);
            _context.Questions.Remove(question);
            await _context.SaveChangesAsync();
            return true;
        }

    }
}

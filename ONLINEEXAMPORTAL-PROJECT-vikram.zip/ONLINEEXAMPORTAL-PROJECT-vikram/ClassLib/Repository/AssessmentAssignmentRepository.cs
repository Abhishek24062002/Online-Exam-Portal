﻿using ClassLib.Data;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;


namespace ClassLib.Repository
{
    public class AssessmentAssignmentRepository : IAssessmentAssignmentRepository
    {
        private readonly AppDbContext _context;

        public AssessmentAssignmentRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<AssessmentAssignment> EnrollUserAsync(int userId, int assessmentId)
        {
            // Check for existing assignment
            var query =
                from aa in _context.AssessmentAssignments
                where aa.UserId == userId && aa.AssessmentId == assessmentId
                select aa;

            var existing = await query.FirstOrDefaultAsync();

            if (existing != null)
            {
                return existing; // Already enrolled
            }

            var assignment = new AssessmentAssignment
            {
                UserId = userId,
                AssessmentId = assessmentId,
                AssignedDate = DateTime.UtcNow,
                IsCompleted = false,
                AttemptId = 0
            };

            _context.AssessmentAssignments.Add(assignment);
            await _context.SaveChangesAsync();
            return assignment;
        }

        public async Task<IEnumerable<Assessment>> FindAllAssessments(int packageId, int userId)
        {
            var Pack = await _context.AssessmentPackages.Include(x => x.Assessments).FirstOrDefaultAsync(x => x.PackageId == packageId);

            var assesments =  Pack.Assessments.ToList();

            return assesments;

            


        }

        public async Task<IEnumerable<object>> GetByUserIdAsync(int userId)
        {
            var query =
                from aa in _context.AssessmentAssignments
                where aa.UserId == userId
                select new
                {
                    aa.AssignmentId,
                    aa.AssessmentId,
                    aa.UserId,
                    aa.AssignedDate,
                    aa.IsCompleted
                };

            return await query.ToListAsync();
        }

    }
}

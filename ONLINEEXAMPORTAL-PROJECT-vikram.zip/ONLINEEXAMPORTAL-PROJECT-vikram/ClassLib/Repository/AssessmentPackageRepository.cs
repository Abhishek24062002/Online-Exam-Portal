﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class AssessmentPackageRepository : IAssessmentPackageRepository
    {
        private readonly AppDbContext _context;

        public AssessmentPackageRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            var packages = await _context.AssessmentPackages
                .Include(p => p.Assessments)
                .Select(p => new
                {
                    p.PackageId,
                    p.PackageName,
                    Assessments = p.Assessments.Select(a => new
                    {
                        a.AssessmentId,
                        a.Title,
                        a.Description,
                        AssessmentType=a.AssessmentType.ToString()
                    }).ToList()
                })
                .ToListAsync();

            return packages;
        }


        public async Task<IEnumerable<AssessmentPackageDto>> GetByIdAsync(int id)
        {
            var packageQuery =
                from p in _context.AssessmentPackages.Include(p => p.Assessments)
                where p.PackageId == id
                select new AssessmentPackageDto
                {
                    PackageName = p.PackageName,
                    Assessments =
                        (from a in p.Assessments
                         select new AssessmentSummaryDto
                         {
                             AssessmentId = a.AssessmentId,
                             Title = a.Title,
                             Description = a.Description
                         }).ToList()
                };

            var result = await packageQuery.ToListAsync();
            return result;
        }
        




        public async Task<IEnumerable<object>> GetAssessmentsByTitleKeywordAsync(string keyword)
        {
            var query =
                from a in _context.Assessments
                where EF.Functions.Like(a.Title, $"%{keyword}%")
                select new
                {
                    a.AssessmentId,
                    a.Title,
                    a.Description,
                    a.AssessmentType,
                    a.Status,
                    a.ScheduledDate,
                    a.EndTime,
                    a.Duration
                };

            return await query.ToListAsync();
        }

        public async Task<AssessmentPackageDto> SaveAsync(AssessmentPackage package)
        {
            _context.AssessmentPackages.Add(package);
            await _context.SaveChangesAsync();






            return new AssessmentPackageDto
            {
                  PackageName = package.PackageName,
                Assessments = package.Assessments.Select(a => new AssessmentSummaryDto
                {
                    AssessmentId = a.AssessmentId,
                    Title = a.Title,
                    
                  //  AssessmentType = a.AssessmentType.ToString()
                }).ToList()



            };
        }


        //public async Task<bool> UpdateAsync(int id, CreateAssessmentPackageDto updated)
        //{
        //    var existing =
        //        await _context.AssessmentPackages
        //        .Include(p => p.Assessments)
        //        .FirstOrDefaultAsync(p => p.PackageId == id);

        //    if (existing == null) return false;

        //    existing.PackageName = updated.PackageName;
        //    existing.Assessments = (ICollection<Assessment>?)updated.Assessments;

        //    await _context.SaveChangesAsync();
        //    return true;
        //}
        public async Task<bool> UpdateAsync(int id, CreateAssessmentPackageDto updated)
        {
            var existing = await _context.AssessmentPackages
                .Include(p => p.Assessments)
                .FirstOrDefaultAsync(p => p.PackageId == id);

            if (existing == null) return false;

            existing.PackageName = updated.PackageName;

            // Clear existing assessments if needed
            existing.Assessments.Clear();

            // Map DTOs to entities
            foreach (var dto in updated.Assessments)
            {
                var assessment = new Assessment
                {
                    Title = dto.Title,
                    Description = dto.Description,
                    ScheduledDate = dto.ScheduledDate,
                    Duration = dto.Duration,
                    MaxMark = dto.MaxMark,
                    PassMark = dto.PassMark,
                    Status = dto.Status,
                    EndTime = dto.EndTime,
                    AssessmentType = dto.AssessmentType,
                    CreatedByUserId = dto.CreatedByUserId
                };

                existing.Assessments.Add(assessment);
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var package = await _context.AssessmentPackages.Include(p => p.Assessments).FirstOrDefaultAsync(p => p.PackageId == id);
            
            if (package == null) return false;

            foreach(var p in package.Assessments)
            {
                _context.Assessments.Remove(p);
            }
            _context.AssessmentPackages.Remove(package);
            await _context.SaveChangesAsync();
            return true;
        }

        

        public async Task<IEnumerable<object>> GetPackagesByUserIdAsync(int userId)
        {
            var query = 
                from assignment in _context.AssessmentAssignments
                where assignment.UserId == userId
                join assessment in _context.Assessments
                    on assignment.AssessmentId equals assessment.AssessmentId
                join package in _context.AssessmentPackages
                    on assessment.packageId equals package.PackageId
                group new { assessment, package } by package.PackageId into grouped
                select new
                {
                    PackageId = grouped.Key,
                    PackageName = grouped.Select(x => x.package.PackageName).FirstOrDefault(),
                    Assessments =
                        grouped.Select(x => new
                        {
                            x.assessment.AssessmentId,
                            x.assessment.Title,
                            x.assessment.Description
                        }).Distinct().ToList()
                };

            return await query.ToListAsync();
        }

        public AssessmentPackage GetPackage(int id)
        {
            return _context.AssessmentPackages.Include(p => p.Assessments).FirstOrDefault(x => x.PackageId == id);
        }
    }
}

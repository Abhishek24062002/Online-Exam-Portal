﻿using ClassLib.Data;
using ClassLib.IRepository;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Repository
{
    public class OptionRepository : IOptionRepository
    {
        private readonly AppDbContext _context;

        public OptionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            return await _context.Options
                .Select(o => new
                {
                    o.OptionId,
                    o.OptionsText,
                    o.Answer,
                    o.QuestionId
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<object>> GetByIdAsync(int questionId)
        {
            return await _context.Options
                .Where(o => o.QuestionId == questionId)
                .Select(o => new
                {
                    o.OptionId,
                    o.OptionsText,
                    o.Answer,
                    o.QuestionId
                })
                .ToListAsync();
        }

        public async Task<CreateOptionDto> AddAsync(CreateOptionDto entity,int questionId)
        {
            var validquestion =  await _context.Options.FindAsync(questionId);

            
            if (validquestion != null)
            {
                return null;
            }
                var options = new Option
                {
                    QuestionId = questionId,
                    OptionsText = entity.OptionsText,
                    Answer = entity.Answer
                };

            _context.Options.Add(options);
                await _context.SaveChangesAsync();

            return new CreateOptionDto
            {
                OptionsText = entity.OptionsText,
                Answer = entity.Answer,
                //QuestionId = questionId
            };
        }

        public async Task<bool> UpdateAsync(int id, Option updated)
        {
            var existing = await _context.Options.FindAsync(id);
            if (existing == null) return false;

            existing.OptionsText = updated.OptionsText;
            existing.Answer = updated.Answer;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var entity = await _context.Options.FindAsync(id);
            if (entity == null) return false;

            _context.Options.Remove(entity);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}

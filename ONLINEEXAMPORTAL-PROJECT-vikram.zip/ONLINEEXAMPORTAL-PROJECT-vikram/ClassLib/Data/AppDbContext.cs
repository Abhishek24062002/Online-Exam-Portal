﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLib.Models;
using ClassLib.Configuration;
namespace ClassLib.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
        {
        }
       

        public DbSet<UserTable> Users { get; set; }
        public DbSet<Assessment> Assessments { get; set; }
        public DbSet<AssessmentPackage> AssessmentPackages { get; set; }
        public DbSet<CandidateRequest> CandidateRequests { get; set; }
        public DbSet<InstructorRequestView> InstructorRequestViews { get; set; }
        public DbSet<InstructorApproval> InstructorApprovals { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Option> Options { get; set; }
        public DbSet<Response> Responses { get; set; }
        public DbSet<ExamAttempt> ExamAttempts { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<LeaderBoard> LeaderBoards { get; set; }
        public DbSet<AssessmentAssignment> AssessmentAssignments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Apply Fluent configurations
            modelBuilder.ApplyConfiguration(new UserTableConfig());
            modelBuilder.ApplyConfiguration(new AssessmentConfig());
            modelBuilder.ApplyConfiguration(new AssessmentPackageConfig());
            modelBuilder.ApplyConfiguration(new CandidateRequestConfig());
            modelBuilder.ApplyConfiguration(new InstructorRequestViewConfig());
            modelBuilder.ApplyConfiguration(new InstructorApprovalConfig());
            modelBuilder.ApplyConfiguration(new QuestionConfig());
            modelBuilder.ApplyConfiguration(new OptionConfig());
            modelBuilder.ApplyConfiguration(new ResponseConfig());
            modelBuilder.ApplyConfiguration(new ExamAttemptConfig());
            modelBuilder.ApplyConfiguration(new FeedbackConfig());
            modelBuilder.ApplyConfiguration(new ReportConfig());
            modelBuilder.ApplyConfiguration(new LeaderBoardConfig());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Dto
{
    public class UserSummaryDTO
    {
        public int UserId { get; set; }
        public string Name { get; set; }
    }
}

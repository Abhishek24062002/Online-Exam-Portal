﻿public class CreateOptionDto
{
    public string OptionsText { get; set; }
    public string Answer { get; set; }

    //public int QuestionId { get; set; }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Dto
{
    public class ExamAttemptDTO
    {
        public int AttemptId { get; set; }
        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public DateTime AttemptDate { get; set; }
        public string CompletionStatus { get; set; }
        public int TotalMarkObtained { get; set; }
        public bool IsPassed { get; set; }

        public UserSummaryDTO User { get; set; }

    }
}
﻿namespace ClassLib.Dto
{
    public class SubmitResponseDto
    {
        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public int QuestionId { get; set; }
        public int OptionId { get; set; }
    }
}

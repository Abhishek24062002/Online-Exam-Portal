﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ClassLib.Dto
{
    public class CreateQuestionDto
    {
        [Required]
        public string QuestionText { get; set; } = string.Empty;

        [Required]
        public string QuestionType { get; set; } = string.Empty; // e.g. "Mcq", "TrueFalse"

        [Range(1, 100)]
        public int Mark { get; set; }

        [Required]
        public int AssessmentId { get; set; } // Foreign key reference

        [MinLength(2, ErrorMessage = "At least two options are required.")]
        public List<CreateOptionDto> Options { get; set; } = new();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Dto
{
    public class ReportDetailsDto
    {
        public string UserName { get; set; } = default!;
        public string Email { get; set; } = default!;
        public string AssessmentTitle { get; set; } = default!;
        public int TotalMarkObtained { get; set; }
        public string FeedbackComments { get; set; } = default!;
        public int FeedbackRating { get; set; }
    }


}
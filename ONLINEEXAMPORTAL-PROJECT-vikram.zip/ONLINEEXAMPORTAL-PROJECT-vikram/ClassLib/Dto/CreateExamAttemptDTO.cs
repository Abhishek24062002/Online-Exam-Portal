﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Dto
{
    public class CreateExamAttemptDTO
    {
        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public int? AssignmentId { get; set; }
    }

}

﻿using System.Collections.Generic;

namespace ClassLib.Dto
{
    public class AssessmentPackageDto
    {
        public string PackageName { get; set; } = string.Empty;
        public List<AssessmentSummaryDto> Assessments { get; set; } = new();
    }

    public class AssessmentSummaryDto
    {
        public int AssessmentId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}

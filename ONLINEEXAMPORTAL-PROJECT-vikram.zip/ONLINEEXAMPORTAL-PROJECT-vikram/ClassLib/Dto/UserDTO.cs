﻿using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Dto
{
    public class UserDTO
    {
       
       
        [Required]
        [StringLength(50)]
        public string Name { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string Email { get; set; } = null!;

        [Required]
        [StringLength(50)]
        [DataType(DataType.Password)]
        public string Password { get; set; } = null!;

        [Required]
        public DateTime RegistrationDate { get; set; }


        [Required]
        public RoleType RoleType { get; set; }
    }
}

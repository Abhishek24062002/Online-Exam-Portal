﻿using ClassLib.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace ClassLib.Dto
{

    public class CreateAssessmentDto

    {
        [Required]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        public DateTime ScheduledDate { get; set; } = DateTime.UtcNow;

        [Range(1, 1000)]
        public int Duration { get; set; }

        [Range(1, int.MaxValue)]
        public int MaxMark { get; set; }

        [Range(0, int.MaxValue)]
        public int PassMark { get; set; }

        [Required]
        public string Status { get; set; } = "Scheduled";

        public DateTime EndTime { get; set; } = DateTime.UtcNow.AddHours(1);

        [Required]
        public AssessmentType AssessmentType { get; set; }

        public int? CreatedByUserId { get; set; }

        public int? packageId { get; set; }
    }
}





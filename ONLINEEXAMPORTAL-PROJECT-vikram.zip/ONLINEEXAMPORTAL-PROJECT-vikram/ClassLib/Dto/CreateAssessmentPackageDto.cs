﻿using ClassLib.Models;
using System;
using System.Collections.Generic;

namespace ClassLib.Dto
{
    public class CreateAssessmentPackageDto
    {
        public string PackageName { get; set; } = string.Empty;
        public List<AssessmentDto> Assessments { get; set; } = new();
    }

    public class AssessmentDto
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime ScheduledDate { get; set; }
        public int Duration { get; set; }
        public int MaxMark { get; set; }
        public int PassMark { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime EndTime { get; set; }
        public AssessmentType AssessmentType { get; set; }
        public int CreatedByUserId { get; set; }
        public int AssessmentId { get; internal set; }

        
    }
}

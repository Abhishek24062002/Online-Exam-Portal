﻿using ClassLib.Dto;

public interface IExamAttemptService
{
    Task<IEnumerable<ExamAttemptDTO>> GetAllAttemptsAsync();
    Task<ExamAttemptDTO> GetAttemptByIdAsync(int id);
    int GetAttemptCountByAssessmentId(int assessmentId);
    List<UserSummaryDTO> GetUsersByAssessmentId(int assessmentId);
    Task UpdateAttemptStatusAsync(int userId, int assessmentId);

    Task<ExamAttemptDTO> CreateAttemptAsync(CreateExamAttemptDTO dto);

}
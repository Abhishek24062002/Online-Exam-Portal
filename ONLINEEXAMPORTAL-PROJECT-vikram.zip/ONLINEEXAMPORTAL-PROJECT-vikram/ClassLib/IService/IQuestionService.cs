﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IQuestionService
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetByIdAsync(int id);
        Task<Question> AddAsync(Question question);
        Task<bool> UpdateAsync(int id, CreateQuestionDto updated);
        Task<bool> DeleteAsync(int id);
    }
}

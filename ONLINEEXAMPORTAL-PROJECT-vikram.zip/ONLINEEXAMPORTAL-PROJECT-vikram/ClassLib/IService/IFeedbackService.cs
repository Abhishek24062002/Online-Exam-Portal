﻿using ClassLib.Dto;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IService
{

    public interface IFeedbackService
    {
        Task<FeedbackDto> CreateFeedbackAsync(CreateFeedbackDto dto);
        Task<bool> UpdateFeedbackAsync(int id, UpdateFeedbackDto dto);
        Task<FeedbackDto?> GetFeedbackByIdAsync(int id);
        Task<IEnumerable<FeedbackDto>> GetAllFeedbacksAsync();
    }
}

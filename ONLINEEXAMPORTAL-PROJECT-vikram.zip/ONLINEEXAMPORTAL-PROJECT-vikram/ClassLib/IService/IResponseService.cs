﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IResponseService
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetAllAsync(int userId, int assessmentId);
        Task<Response> SubmitAsync(SubmitResponseDto dto);

        Task<bool> DeleteResponsesAsync(int userId, int assessmentId);
    }
}

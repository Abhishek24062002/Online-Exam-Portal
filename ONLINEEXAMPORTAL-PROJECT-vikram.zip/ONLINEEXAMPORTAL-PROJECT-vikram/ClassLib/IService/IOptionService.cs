﻿using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IOptionService
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetByIdAsync(int questionId);
        Task<CreateOptionDto> AddAsync(CreateOptionDto option,int Questionid);
        Task<bool> UpdateAsync(int id, Option updated);
        Task<bool> DeleteAsync(int id);
    }
}

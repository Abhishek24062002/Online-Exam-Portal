﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IAssessmentPackageService
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<AssessmentPackageDto>> GetPackageByIdAsync(int id);
        Task<IEnumerable<object>> GetPackagesByUserIdAsync(int userId);
        Task<IEnumerable<object>> GetAssessmentsByTitleKeywordAsync(string keyword);
        Task<AssessmentPackageDto> AddPackageAsync(CreateAssessmentPackageDto dto);
        Task<bool> UpdateAsync(int id, CreateAssessmentPackageDto updated);
        Task<bool> DeleteAsync(int id);
        public AssessmentPackage GetPackageById(int id);
    }
}

﻿using ClassLib.Models;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IAssessmentAssignmentService
    {
        Task<AssessmentAssignment> EnrollAsync(int userId, int assessmentId);

        Task<IEnumerable<object>> GetByUserIdAsync(int userId);

        Task<IEnumerable<AssessmentAssignment>> CandidateRequestEnrollAsync(int packageId, int userId);
    }
}

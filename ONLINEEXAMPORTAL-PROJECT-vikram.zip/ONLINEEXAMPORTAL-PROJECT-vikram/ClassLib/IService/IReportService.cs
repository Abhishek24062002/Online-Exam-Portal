﻿using ClassLib.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IReportService
    {
        Task<IEnumerable<ReportDetailsDto>> GetFilteredReportsAsync(string? assessmentTitle, string? userName);
        Task GenerateReportsAsync();
    }
}
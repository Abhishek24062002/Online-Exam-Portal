﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IAssessmentService
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetByIdAsync(int id);
        Task<IEnumerable<object>> GetAssessmentsByKeywordAsync(string keyword);
        Task<IEnumerable<object>> GetAssessmentsByPackageNameAsync(string packageName);
        Task<IEnumerable<object>> GetAssessmentsByCreatorIdAsync(int userId);
        Task<IEnumerable<object>> GetAssignedAssessmentsByUserIdAsync(int userId);
        Task<IEnumerable<object>> GetQuestionsWithOptionsByAssessmentIdAsync(int assessmentId);

        Task<IEnumerable<object>> GetQuestionsWithOptionsExamByAssessmentIdAsync(int assessmentId);
        Task<int> GetObtainedMarkByUserAsync(int userId, int assessmentId);
        Task<Assessment> AddAsync(CreateAssessmentDto dto);
        Task<bool> UpdateAsync(int id, CreateAssessmentDto updated);
        Task<bool> DeleteAsync(int id);

        Task<object> GetAssessmentSummaryAsync(int assessmentId);
        Task<IEnumerable<object>> GetUsersByAssessmentAsync(int assessmentId);
        Task<IEnumerable<object>> GetPackages(int userId);
    }
}

﻿using ClassLib.Dto;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IUserService
    {   //Registration api
        Task<UserTable?> CreateAsync(UserDTO user);
        Task<UserTable?> UpdateUser(UserDTO user);

        Task<UserTable> DeleteByIdAsync(int id);
        public List<UserDTO> GetAll();
       Task<UserTable?> GetUser(string email);

        //Login api
        public string GenerateToken(LoginWithRoleDTO user);
        Task<LoginWithRoleDTO?> LoginAsync(LoginDTO credentials );//Dto needed
        
        Task<ApprovalResultDTO> Approval(int userId);

        bool IsValidEmail(string email);
        bool IsValidPassword(string password);
        //user can do
        Task<string?> RequestPasswordResetAsync(string email, string origin);
        Task ResetPasswordAsync(ResetPasswordDto dto);

        Task<UserTable> DeleteByEmailAsync(string email);
        public List<InstructorApproval>  GetApprovalList();
    }
}

﻿using Azure.Core;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IService
{
    public interface IInstructorRequestViewService
    {
        Task<IEnumerable<InstructorRequestView>> GetInstructorsRequestAsync();
       
        Task<string> GiveApproval(int requestId,RequestStatus status);


    }
}

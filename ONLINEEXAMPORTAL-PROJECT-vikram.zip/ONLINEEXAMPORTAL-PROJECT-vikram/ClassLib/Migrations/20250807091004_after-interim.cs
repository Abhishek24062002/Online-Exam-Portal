﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClassLib.Migrations
{
    /// <inheritdoc />
    public partial class afterinterim : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Instructor_Approval_UserTable_UserId",
                table: "Instructor_Approval");

            migrationBuilder.AddForeignKey(
                name: "FK_Instructor_Approval_UserTable_UserId",
                table: "Instructor_Approval",
                column: "UserId",
                principalTable: "UserTable",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Instructor_Approval_UserTable_UserId",
                table: "Instructor_Approval");

            migrationBuilder.AddForeignKey(
                name: "FK_Instructor_Approval_UserTable_UserId",
                table: "Instructor_Approval",
                column: "UserId",
                principalTable: "UserTable",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}

﻿using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Services
{
    public class InstructorRequestViewService : IInstructorRequestViewService
    {
        private readonly IInstructorRequestViewRepository _repo;

        private readonly IAssessmentAssignmentService _assessmentAssignmentService;
        public InstructorRequestViewService(IInstructorRequestViewRepository repo, IAssessmentAssignmentService assessmentAssignmentService) {
        _repo = repo;
            _assessmentAssignmentService = assessmentAssignmentService;
        }
        public async Task<IEnumerable<InstructorRequestView> >GetInstructorsRequestAsync()
        {
            //var response = await _repo.GetAllRequestAsync();
            //Console.WriteLine(response.FirstOrDefault(x => x.CandidateRequest.AssessmentPackage.PackageName == "rajat");
            return await _repo.GetAllRequestAsync();
        }

        public async Task<string> GiveApproval(int requestId,RequestStatus status)

        {
            
           var findRequest = await _repo.FindRequestAsync(requestId);
            if (findRequest != null && status == RequestStatus.Rejected)
            {

                //findRequest.RequestStatus = RequestStatus.Rejected;
                //_repo.UpdateStatus(findRequest);
                //await _repo.ReflectChange(requestId);

                //return "Request REJECTED";
                // ........................
                findRequest.RequestStatus = RequestStatus.Rejected;
                _repo.UpdateStatus(findRequest);
                var ApprovalState = await _repo.ReflectChange(requestId);
                ApprovalState.RequestStatus = RequestStatus.Rejected;
                ApprovalState.ReviewDate = DateTime.Now;
                ApprovalState.ReviewedBY = ApprovalState.User.Name;
                _repo.UpdateStatus(ApprovalState);

                return "Request REJECTED";

            }
            else if (findRequest != null && findRequest.RequestStatus == RequestStatus.Pending)
            {
                

                var ApprovalState = await _repo.ReflectChange(requestId);
                if (ApprovalState != null)
                {
                    var packageid = ApprovalState.PackageId;
                    var userid = ApprovalState.UserId;

                    var response = await _assessmentAssignmentService.CandidateRequestEnrollAsync(packageid, userid);

                    if(response== null)
                    {
                        

                        findRequest.RequestStatus = RequestStatus.Rejected;
                        _repo.UpdateStatus(findRequest);

                        ApprovalState.RequestStatus = RequestStatus.Rejected;
                        ApprovalState.ReviewDate = DateTime.Now;
                        ApprovalState.ReviewedBY = ApprovalState.User.Name;
                        _repo.UpdateStatus(ApprovalState);

                        return "Request REJECTED";
                    }

                    findRequest.RequestStatus = RequestStatus.Approved;
                    _repo.UpdateStatus(findRequest);

                    ApprovalState.RequestStatus = RequestStatus.Approved;
                    ApprovalState.ReviewDate = DateTime.Now;
                    ApprovalState.ReviewedBY = ApprovalState.User.Name;
                    _repo.UpdateStatus(ApprovalState);
                    return "Assesments assigned successfully";
                }
                    else
                     {
                    findRequest.RequestStatus = RequestStatus.Rejected;
                    _repo.UpdateStatus(findRequest);

                    return "Request REJECTED";
                    }
                }
          
            else if (findRequest != null && findRequest.RequestStatus == RequestStatus.Approved ) return "Request already APPROVED";// need to change
            else  { return "NO REQUEST WITH REQUEST ID FOUND !!!"; }

            

            
        }


    }
}

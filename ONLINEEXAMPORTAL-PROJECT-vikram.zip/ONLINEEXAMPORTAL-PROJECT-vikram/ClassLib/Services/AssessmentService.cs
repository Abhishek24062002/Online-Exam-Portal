﻿using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using ClassLib.IRepository;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace ClassLib.Services
{

    public class AssessmentService : IAssessmentService
    {
        private readonly IAssessmentRepository _repo;

        public AssessmentService(IAssessmentRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            var result = await _repo.GetAllAsync();
            List<object> assessments = new List<object>();

            foreach (var item in result)
            {
                assessments.Add(item);
            }

            return assessments;
        }

        public async Task<IEnumerable<object>> GetByIdAsync(int id)
        {
            var result = await _repo.GetByIdAsync(id);
            List<object> assessments = new List<object>();

            foreach (var item in result)
            {
                assessments.Add(item);
            }

            return assessments;
        }

        public async Task<IEnumerable<object>> GetAssessmentsByKeywordAsync(string keyword)
        {
            var result = await _repo.GetAssessmentsByKeywordAsync(keyword);
            List<object> assessments = new List<object>();

            foreach (var item in result)
            {
                assessments.Add(item);
            }

            return assessments;
        }

        public async Task<IEnumerable<object>> GetAssessmentsByPackageNameAsync(string packageName)
        {
            var result = await _repo.GetAssessmentsByPackageNameAsync(packageName);
            List<object> assessments = new List<object>();

            foreach (var item in result)
            {
                assessments.Add(item);
            }

            return assessments;
        }

        public async Task<IEnumerable<object>> GetAssessmentsByCreatorIdAsync(int userId)
        {
            var result = await _repo.GetAssessmentsByCreatorIdAsync(userId);
            List<object> assessments = new List<object>();

            foreach (var item in result)
            {
                assessments.Add(item);
            }

            return assessments;
        }

        public async Task<IEnumerable<object>> GetAssignedAssessmentsByUserIdAsync(int userId)
        {
            var result = await _repo.GetAssignedAssessmentsByUserIdAsync(userId);
            List<object> assignments = new List<object>();

            foreach (var item in result)
            {
                assignments.Add(item);
            }

            return assignments;
        }

        public async Task<IEnumerable<object>> GetQuestionsWithOptionsByAssessmentIdAsync(int assessmentId)
        {
            var result = await _repo.GetQuestionsWithOptionsByAssessmentIdAsync(assessmentId);
            List<object> questions = new List<object>();

            foreach (var item in result)
            {
                questions.Add(item);
            }

            return questions;
        }

        public async Task<IEnumerable<object>> GetQuestionsWithOptionsExamByAssessmentIdAsync(int assessmentId)
        {
            var result = await _repo.GetQuestionsWithOptionsExamByAssessmentIdAsync(assessmentId);

            return result;
        }
        public Task<int> GetObtainedMarkByUserAsync(int userId, int assessmentId)
        {
            return _repo.GetObtainedMarkByUserAsync(userId, assessmentId);
        }

        public Task<Assessment> AddAsync(CreateAssessmentDto dto)
        {
            return _repo.AddAsync(dto);
            
        }

        public async Task<bool> UpdateAsync(int id, CreateAssessmentDto updated)
        {
           

            return await _repo.UpdateAsync(id, updated);
        }

        public Task<bool> DeleteAsync(int id)
        {
            return _repo.DeleteAsync(id);
        }

        public Task<object> GetAssessmentSummaryAsync(int assessmentId) =>
    _repo.GetAssessmentSummaryAsync(assessmentId);

        public Task<IEnumerable<object>> GetUsersByAssessmentAsync(int assessmentId) =>
            _repo.GetUsersByAssessmentAsync(assessmentId);

        public Task<IEnumerable<object>> GetPackages(int userId)
        {
            return _repo.GetPackages(userId);
        }
    }
}

﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using ClassLib.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
namespace ClassLib.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repo;
        private readonly IEmailService _emailService;
        private readonly IConfiguration _configuration;

        public UserService(IUserRepository repo,  IEmailService emailService, IConfiguration configuration)
        {
            _repo = repo;
            _configuration = configuration;
            
            _emailService = emailService;
        }

        public async Task<UserTable?> CreateAsync(UserDTO user) {

            if (user.RoleType == RoleType.Instructor)
            {
                var details = new UserTable
                {
                    Name = user.Name,
                    Email = user.Email,
                    Password = user.Password,
                    RegistrationDate = user.RegistrationDate,
                    RoleType = user.RoleType,
                    TokenExpiry =null,
                    PasswordResetToken = null
                };
                await _repo.SaveUserAsync(details);
                Console.WriteLine($"Saved user with ID {details.UserId}");
                var instructor = new InstructorApproval
                {
                    UserId = details.UserId,
                    ApprovalStatus = ApprovalStatus.Pending,

                };
                
                _repo.SaveInsApprovalAsync(instructor);

                     return details; 
            }
           
            else
            {
                var details = new UserTable
                {
                    Name = user.Name,
                    Email = user.Email,
                    Password = user.Password,
                    RegistrationDate = user.RegistrationDate,
                    RoleType = user.RoleType,
                    TokenExpiry = null,
                    PasswordResetToken = null
                };
                return await _repo.SaveUserAsync(details);
            }


            }

        public string GenerateToken(LoginWithRoleDTO user)
        {



            var claims = new List<Claim>()
            {

                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Email, user.Email),

                new Claim("Password", user.Password),
                //new Claim(ClaimTypes.Role,user.Role)
                new Claim("role", user.Role)

            };

           // var key = _configuration.GetValue<string>("ApiSettings:Secret");
            var key = _configuration["ApiSettings:Secret"];
            var secured = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var signinData = new SigningCredentials(secured, SecurityAlgorithms.HmacSha256);


            var token = new JwtSecurityToken(

                issuer: "OnlineExamPortal",
                audience: "Candidates",
                expires: DateTime.Now.AddHours(4),
                claims: claims,
                signingCredentials: signinData
                );
            var tokenHandler = new JwtSecurityTokenHandler();
            return tokenHandler.WriteToken(token);
        }

        public async Task<UserTable> DeleteByIdAsync(int id)
        {
            var userExist =await _repo.FindByIdAsync(id);
            if (userExist != null)
                return await _repo.Delete(userExist);

            return userExist;


        }

        public async Task<UserTable> DeleteByEmailAsync(string email)
        {
            var userExist =  _repo.FindByEmailAsync(email);

            if (userExist != null &&     userExist.RoleType != RoleType.Admin)
                return await _repo.Delete(userExist);

            return userExist;
        }

        public  bool IsValidEmail(string email)
        {
            // Basic email pattern
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            return Regex.IsMatch(email, pattern);
        }

        public  bool IsValidPassword(string password)
        {
            // Password must be at least 8 characters, include uppercase, lowercase, digit and special character
            string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$";

            return Regex.IsMatch(password, pattern);
        }

        public async Task<LoginWithRoleDTO?> LoginAsync(LoginDTO credentials)
        {    var user= await _repo.FindUserAsync(credentials);
            if(user == null)
            {
                return null;
            }
            return new LoginWithRoleDTO { Name = user.Name ,Email = user.Email, Password = user.Password , Role=user.Role};

        }



        public async Task<UserTable?> UpdateUser(UserDTO user)
        {
            var item =await _repo.GetDetails(user.Email);

            if (item != null)
            {
                // item.Name   = !string.IsNullOrWhiteSpace(user.Name) ?  user.Name : item.Name;
                if (!string.IsNullOrWhiteSpace(user.Name))
                    item.Name = user.Name;

                // item.Email = !string.IsNullOrWhiteSpace(user.Email) ?  user.Email :  item.Email;

                if (!string.IsNullOrWhiteSpace(user.Email))
                    item.Email = user.Email;
                //  item.Password = !string.IsNullOrWhiteSpace(user.Password) ?  user.Password :  item.Password;

                if (!string.IsNullOrWhiteSpace(user.Password))
                    item.Password = user.Password;
                
                
                //  item.RoleType = !string.IsNullOrWhiteSpace(user.RoleType.ToString()) ?  user.RoleType :  item.RoleType;
                //need to comment this after authorization. this is for practice purpose
                //if (!string.IsNullOrWhiteSpace(user.RoleType.ToString()))
                //    item.RoleType = user.RoleType;
                //if (user.RoleType != null)
                //    item.RoleType = user.RoleType;




                return _repo.Update(item);

            }
            return null;
        }

       

        

       

        public List<UserDTO> GetAll()
        {
           
            var response= _repo.FindAll();
            var item = new List<UserDTO>();
            foreach (var item1 in response)
            {
                var user = new UserDTO
                {
                    Name = item1.Name,
                    Email = item1.Email,
                    Password = item1.Password,
                    RoleType = item1.RoleType,
                    RegistrationDate = item1.RegistrationDate,

                };
                item.Add(user);
            }
            return item;
        }

        public async Task< UserTable?> GetUser(string email)
        {
           var item =await _repo.GetDetails(email);

            return item;
        }

        public async Task<ApprovalResultDTO> Approval(int userId)
        {
            var approval = await _repo.GetApprovalByUserIdAsync(userId);
            if (approval == null)
                return new ApprovalResultDTO { Success = false, Message = "Instructor approval failed" };

            if (approval.ApprovalStatus == ApprovalStatus.Approved)
                return new ApprovalResultDTO
                {
                    Success = true,
                    Message = "Already approved"
                };

            approval.ApprovalStatus = ApprovalStatus.Approved;
            await _repo.UpdateApprovalAsync(approval);

            

            return new ApprovalResultDTO
            {
                Success = true,
                Message = "Instructor approved successfully"
            };
        }

        public async Task<string?> RequestPasswordResetAsync(string email, string origin)
        {
            var user = await _repo.GetUserByEmailAsync(email);
            if (user == null)
            {
                Console.WriteLine("User not found for email: " + email);
                return null;
            }

            var token = Guid.NewGuid().ToString();
            user.PasswordResetToken = token;
            user.TokenExpiry = DateTime.UtcNow.AddHours(1);
            await _repo.UpdateUserAsync(user);

            var resetLink = $"{origin}/reset-password?token={token}";

            //var resetLink = $"{origin}/reset-password?{token}";
            //var loginLink =$"{origin}/Login/login";
            var emailBody = $"Click here to reset your password: <a href='{resetLink}'>Reset Password</a>";

            await _emailService.SendEmailAsync(email, "Password Reset", emailBody);

            return token;
        }

        public async Task ResetPasswordAsync(ResetPasswordDto dto)
        {
            var user = await _repo.GetUserByResetTokenAsync(dto.Token);
            if (user == null || user.TokenExpiry < DateTime.UtcNow)
                throw new Exception("Invalid or expired token.");

            user.Password = dto.NewPassword;
            user.PasswordResetToken = null;
            user.TokenExpiry = null;

            await _repo.UpdateUserAsync(user);
        }

        public List<InstructorApproval> GetApprovalList()
        {
            var ApprovalList = _repo.GetApproveList();

            var list = ApprovalList.FindAll(x => x.ApprovalStatus == ApprovalStatus.Pending).ToList();

            return list;
        }
    }
    }

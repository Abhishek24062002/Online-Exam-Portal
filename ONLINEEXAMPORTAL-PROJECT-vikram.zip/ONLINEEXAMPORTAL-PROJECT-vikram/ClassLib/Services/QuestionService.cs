﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class QuestionService : IQuestionService
    {
        private readonly IQuestionRepository _repo;

        public QuestionService(IQuestionRepository repo)
        {
            _repo = repo;
        }

        public Task<IEnumerable<object>> GetAllAsync() => _repo.GetAllAsync();
        public Task<IEnumerable<object>> GetByIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task<Question> AddAsync(Question question) => _repo.AddAsync(question);
        public Task<bool> UpdateAsync(int id, CreateQuestionDto updated) => _repo.UpdateAsync(id, updated);
        public Task<bool> DeleteAsync(int id) => _repo.DeleteAsync(id);
    }
}

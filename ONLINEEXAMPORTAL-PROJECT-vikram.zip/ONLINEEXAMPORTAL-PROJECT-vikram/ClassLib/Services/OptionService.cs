﻿using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class OptionService : IOptionService
    {
        private readonly IOptionRepository _repo;

        public OptionService(IOptionRepository repo)
        {
            _repo = repo;
        }

        public Task<IEnumerable<object>> GetAllAsync() => _repo.GetAllAsync();
        public Task<IEnumerable<object>> GetByIdAsync(int questionId) => _repo.GetByIdAsync(questionId);
        public Task<CreateOptionDto> AddAsync(CreateOptionDto option, int questionId) => _repo.AddAsync( option,questionId);
        public Task<bool> UpdateAsync(int id, Option updated) => _repo.UpdateAsync(id, updated);
        public Task<bool> DeleteAsync(int id) => _repo.DeleteAsync(id);
    }
}

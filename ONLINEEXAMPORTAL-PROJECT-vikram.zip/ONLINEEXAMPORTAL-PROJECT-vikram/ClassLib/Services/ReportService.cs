﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Services
{
    public class ReportService : IReportService
    {
        private readonly IReportRepository _reportRepository;
        private readonly AppDbContext _context;

        public ReportService(IReportRepository reportRepository, AppDbContext context)
        {
            _reportRepository = reportRepository;
            _context = context;
        }

        public async Task<IEnumerable<ReportDetailsDto>> GetFilteredReportsAsync(string? assessmentTitle, string? userName)
        {
            return await _reportRepository.GetReportsAsync(assessmentTitle, userName);
        }

        
        public async Task GenerateReportsAsync()
        {
            var attempts = await _context.ExamAttempts
                .Include(e => e.AssessmentAssignment)
                    .ThenInclude(aa => aa.Assessment)
                .Include(e => e.AssessmentAssignment.User)
                .ToListAsync();

            foreach (var attempt in attempts)
            {
                var assignment = attempt.AssessmentAssignment;
                if (assignment == null || assignment.Assessment == null || assignment.User == null)
                {
                    Console.WriteLine($"Missing navigation for AttemptId: {attempt.AttemptId}");
                    continue;
                }

                bool reportExists = await _context.Reports.AnyAsync(r => r.AttemptId == attempt.AttemptId);
                if (reportExists) continue;

                var feedback = await _context.Feedbacks
                    .FirstOrDefaultAsync(f =>
                        f.UserId == attempt.UserId &&
                        f.AssessmentId == assignment.Assessment.AssessmentId);

                if (feedback == null)
                {
                    Console.WriteLine($"No feedback for UserId: {attempt.UserId}, AssessmentId: {assignment.Assessment.AssessmentId}");
                    continue;
                }

                var report = new Report
                {
                    UserId = attempt.UserId,
                    AttemptId = attempt.AttemptId,
                    FeedbackId = feedback.FeedbackId,
                    Remarks = attempt.IsPassed ? "Passed" : "Failed",
                    MarkDetails = $"Scored {attempt.TotalMarkObtained} out of {assignment.Assessment.MaxMark}",
                    ExamAttempt = attempt,
                    Feedback = feedback
                };

                _context.Reports.Add(report);
            }

            await _context.SaveChangesAsync();
        }

    }
}

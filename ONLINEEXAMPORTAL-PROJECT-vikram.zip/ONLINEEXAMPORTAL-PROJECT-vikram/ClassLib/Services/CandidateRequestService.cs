﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;


public class CandidateRequestService : ICandidateRequestService
{
    private readonly ICandidateRequestRepository _repo;

    public CandidateRequestService(ICandidateRequestRepository repo)
    {
        _repo = repo;
    }

    public async Task<string?> CreateAsync(CandidateRequestDTO dto)
    {
        var entity = new CandidateRequest
        {
            UserId = dto.UserId,
            PackageId = dto.PackageId,
            
            RequestStatus = RequestStatus.Pending
        };
        var response=await _repo.SaveAsync(entity);
        var RaiseApproval = new InstructorRequestView
        {
            RequestId = entity.RequestId,
            UserId = entity.UserId,
            RequestStatus = entity.RequestStatus
        };

         _repo.CreateRaiseApproval(RaiseApproval);


        return response;
    }

    public async Task<IEnumerable<CandidateRequestDTO?>> GetAllAsync() {
        var response=await _repo.GetAllAsync();
        return response!=null ? response : Enumerable.Empty<CandidateRequestDTO>(); 
}

    public async Task<IEnumerable<CandidateRequest?>> GetAll()
    {
        var response = await _repo.GetAll();
        return response != null ? response : Enumerable.Empty<CandidateRequest>();
    }
    public async Task<CandidateRequestDTO?> GetByIdAsync(int id) => await _repo.GetByIdAsync(id);

    public async Task<bool> DeleteAsync(int id) => await _repo.DeleteAsync(id);

    public async Task<IEnumerable<CandidateRequestDTO>> GetByUserIdAsync(int userId) => await _repo.GetByUserIdAsync(userId);

    public async Task<IEnumerable<CandidateRequestDTO>> GetByStatusAsync(string status) => await _repo.GetByStatusAsync(status);
}





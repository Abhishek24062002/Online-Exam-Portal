﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;

public class ExamAttemptService : IExamAttemptService
{
    private readonly IExamAttemptRepository _repo;

    public ExamAttemptService(IExamAttemptRepository repo)
    {
        _repo = repo;
    }

    public async Task<IEnumerable<ExamAttemptDTO>> GetAllAttemptsAsync()
    {
        var attempts = await _repo.GetAllAsync();

        return attempts.Select(attempt => new ExamAttemptDTO
        {
            AttemptId = attempt.AttemptId,
            UserId = attempt.UserId,
            AssessmentId = attempt.AssessmentId,
            AttemptDate = attempt.AttemptDate,
            CompletionStatus = attempt.CompletionStatus,
            TotalMarkObtained = attempt.TotalMarkObtained,
            IsPassed = attempt.IsPassed,
            User = attempt.AssessmentAssignment != null
                ? new UserSummaryDTO
                {
                    UserId = attempt.AssessmentAssignment.UserId,
                    Name = attempt.AssessmentAssignment.User?.Name ?? "Unknown"
                }
                : null
        });
    }

    public async Task<ExamAttemptDTO> GetAttemptByIdAsync(int id)
    {
        var attempt = await _repo.GetByIdAsync(id);
        if (attempt == null) return null;

        return new ExamAttemptDTO
        {
            AttemptId = attempt.AttemptId,
            UserId = attempt.UserId,
            AssessmentId = attempt.AssessmentId,
            AttemptDate = attempt.AttemptDate,
            CompletionStatus = attempt.CompletionStatus,
            TotalMarkObtained = attempt.TotalMarkObtained,
            IsPassed = attempt.IsPassed,
            User = attempt.AssessmentAssignment != null
                ? new UserSummaryDTO
                {
                    UserId = attempt.AssessmentAssignment.UserId,
                    Name = attempt.AssessmentAssignment.User?.Name ?? "Unknown"
                }
                : null
        };
    }

    public int GetAttemptCountByAssessmentId(int assessmentId)
    {
        return _repo.GetAttemptCountByAssessmentId(assessmentId);
    }

    public List<UserSummaryDTO> GetUsersByAssessmentId(int assessmentId)
    {
        return _repo.GetUsersByAssessmentId(assessmentId);
    }

 

    public async Task UpdateAttemptStatusAsync(int userId, int assessmentId)
    {
        var attempt = await _repo.GetAttemptAsync(userId, assessmentId)
            ?? throw new InvalidOperationException("Attempt not found.");

        var responses = await _repo.GetResponsesAsync(userId, assessmentId);
        var assessment = await _repo.GetAssessmentAsync(assessmentId)
            ?? throw new InvalidOperationException("Assessment not found.");
        int questionCount = await _repo.GetQuestionCountAsync(assessmentId);

        attempt.TotalMarkObtained = responses.Sum(r => r.ObtainedMark);
        bool allQuestionsAnswered = responses.Count == questionCount;

        attempt.CompletionStatus = allQuestionsAnswered ? "Completed" : "Pending";
        attempt.IsPassed = allQuestionsAnswered && attempt.TotalMarkObtained >= assessment.PassMark;

        var assignmentStatus = _repo.GetAssignment(userId, assessmentId);
        if (assignmentStatus != null && attempt.CompletionStatus == "Completed")
        {
            assignmentStatus.IsCompleted = true;

            _repo.SaveAssignment(assignmentStatus);

        }

        await _repo.SaveAttemptAsync(attempt);
    }

    
    public async Task<ExamAttemptDTO> CreateAttemptAsync(CreateExamAttemptDTO dto)
    {
        var newAttempt = new ExamAttempt
        {
            UserId = dto.UserId,
            AssessmentId = dto.AssessmentId,
            AssignmentId = dto.AssignmentId,
            AttemptDate = DateTime.UtcNow,
            CompletionStatus = "Pending",     // Default state
            TotalMarkObtained = 0,
            IsPassed = false
        };

        var inserted = await _repo.CreateAttemptAsync(newAttempt);

        return new ExamAttemptDTO
        {
            AttemptId = inserted.AttemptId,
            UserId = inserted.UserId,
            AssessmentId = inserted.AssessmentId,
            AttemptDate = inserted.AttemptDate,
            CompletionStatus = inserted.CompletionStatus,
            TotalMarkObtained = inserted.TotalMarkObtained,
            IsPassed = inserted.IsPassed,
            User = null // Populate if needed
        };
    }

}
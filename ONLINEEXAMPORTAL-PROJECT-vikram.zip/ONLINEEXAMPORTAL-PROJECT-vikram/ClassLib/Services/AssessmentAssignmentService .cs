﻿using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class AssessmentAssignmentService : IAssessmentAssignmentService
    {
        private readonly IAssessmentAssignmentRepository _repo;

        public AssessmentAssignmentService(IAssessmentAssignmentRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<AssessmentAssignment>> CandidateRequestEnrollAsync(int packageId, int userId)
        {
            var assessments = await _repo.FindAllAssessments(packageId,userId);

            var ReturnList = new List<AssessmentAssignment>();

            foreach (var item in assessments)
            {

            
               ReturnList.Add( await EnrollAsync(userId,item.AssessmentId));
            }
          
            return ReturnList;
        }

        public Task<AssessmentAssignment> EnrollAsync(int userId, int assessmentId) =>
            _repo.EnrollUserAsync(userId, assessmentId);

        public Task<IEnumerable<object>> GetByUserIdAsync(int userId) =>
        _repo.GetByUserIdAsync(userId);




    }
}

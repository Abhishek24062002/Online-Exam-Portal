﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class ResponseService : IResponseService
    {
        private readonly IResponseRepository _repo;

        public ResponseService(IResponseRepository repo)
        {
            _repo = repo;
        }

        public Task<IEnumerable<object>> GetAllAsync() => _repo.GetAllAsync();

        public Task<IEnumerable<object>> GetAllAsync(int userId, int assessmentId) =>
            _repo.GetAllAsync(userId, assessmentId);

        public async Task<Response> SubmitAsync(SubmitResponseDto dto)
        {
            var entity = new Response
            {
                UserId = dto.UserId,
                AssessmentId = dto.AssessmentId,
                QuestionId = dto.QuestionId,
                OptionId = dto.OptionId
            };
                

            


            return await _repo.AddAsync(entity);
        }
        public async Task<bool> DeleteResponsesAsync(int userId, int assessmentId)
        {
            var responses = await _repo.GetResponsesByUserAndAssessmentAsync(userId, assessmentId);
            if (!responses.Any()) return false;

            await _repo.DeleteResponsesAsync(responses);
            return true;
        }
    }
}

﻿using ClassLib.IService;
using Microsoft.Extensions.Configuration;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _config;
        public EmailService(IConfiguration config) => _config = config;

        public async Task SendEmailAsync(string to, string subject, string htmlMessage)
        {
            var smtpHost = _config["Smtp:Host"];
            var smtpPort = int.Parse(_config["Smtp:Port"]);
            var from = _config["Smtp:From"];
            var username = _config["Smtp:Username"];
            var password = _config["Smtp:Password"];
            var timeout = int.Parse(_config["Smtp:Timeout"] ?? "120000");

            using var smtp = new SmtpClient(smtpHost)
            {
                Port = smtpPort,
                Credentials = new NetworkCredential(username, password),
                EnableSsl = true,
                Timeout=timeout
            };

            var mail = new MailMessage(from, to, subject, htmlMessage)
            {
                IsBodyHtml = true
            };

            await smtp.SendMailAsync(mail);
        }
    }
}
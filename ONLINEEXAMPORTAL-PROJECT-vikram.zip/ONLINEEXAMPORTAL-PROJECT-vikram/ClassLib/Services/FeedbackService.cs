﻿using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Services
{

    public class FeedbackService : IFeedbackService
    {
        private readonly IFeedbackRepository _repository;

        public FeedbackService(IFeedbackRepository repository)
        {
            _repository = repository;

        }


        public async Task<FeedbackDto> CreateFeedbackAsync(CreateFeedbackDto dto)
        {
            var isCompleted = await _repository.IsAssignmentCompletedAsync(dto.AssignmentId);
            if (!isCompleted)
            {
                throw new InvalidOperationException("Feedback can only be submitted for completed assessments.");
            }

            var feedback = new Feedback
            {
                UserId = dto.UserId,
                AssessmentId = dto.AssessmentId,
                AssignmentId = dto.AssignmentId,
                Rating = dto.Rating,
                Comments = dto.Comments
            };

            await _repository.AddAsync(feedback);

            return new FeedbackDto
            {
                UserId = feedback.UserId,
                AssessmentId = feedback.AssessmentId,
                AssignmentId = feedback.AssignmentId,
                Rating = feedback.Rating,
                Comments = feedback.Comments
            };
        }




        public async Task<bool> UpdateFeedbackAsync(int id, UpdateFeedbackDto dto)
        {
            var feedback = await _repository.GetByIdAsync(id);
            if (feedback == null) return false;

            feedback.Rating = dto.Rating;
            feedback.Comments = dto.Comments;

            await _repository.UpdateAsync(feedback);
            return true;
        }

        public async Task<FeedbackDto?> GetFeedbackByIdAsync(int id)
        {
            var feedback = await _repository.GetByIdAsync(id);
            if (feedback == null) return null;

            return new FeedbackDto
            {
                UserId = feedback.UserId,
                AssessmentId = feedback.AssessmentId,
                Rating = feedback.Rating,
                Comments = feedback.Comments,
                AssignmentId=feedback.AssignmentId
            };
        }

        public async Task<IEnumerable<FeedbackDto>> GetAllFeedbacksAsync()
        {
            var feedbacks = await _repository.GetAllAsync();
            return feedbacks.Select(f => new FeedbackDto
            {
                UserId = f.UserId,
                AssessmentId = f.AssessmentId,
                Rating = f.Rating,
                Comments = f.Comments,
                AssignmentId=f.AssignmentId
            });
        }
    }
}
﻿using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.Service
{
    public class AssessmentPackageService : IAssessmentPackageService
    {
        private readonly IAssessmentPackageRepository _repo;

        public AssessmentPackageService(IAssessmentPackageRepository repo)
        {
            _repo = repo;
        }

        public Task<IEnumerable<object>> GetAllAsync() =>
            _repo.GetAllAsync();

        public Task<IEnumerable<AssessmentPackageDto>> GetPackageByIdAsync(int id) =>
            _repo.GetByIdAsync(id);

        public Task<IEnumerable<object>> GetPackagesByUserIdAsync(int userId) =>
            _repo.GetPackagesByUserIdAsync(userId);

        public Task<IEnumerable<object>> GetAssessmentsByTitleKeywordAsync(string keyword) =>
            _repo.GetAssessmentsByTitleKeywordAsync(keyword);

        public async Task<AssessmentPackageDto> AddPackageAsync(CreateAssessmentPackageDto dto)
        {
            var package = new AssessmentPackage
            {
                PackageName = dto.PackageName,
                Assessments = new List<Assessment>()
            };

            foreach (var a in dto.Assessments)
            {
                package.Assessments.Add(new Assessment
                {
                    Title = a.Title,
                    Description = a.Description,
                    ScheduledDate = a.ScheduledDate,
                    Duration = a.Duration,
                    MaxMark = a.MaxMark,
                    PassMark = a.PassMark,
                    Status = a.Status,
                    EndTime = a.EndTime,
                    AssessmentType = a.AssessmentType,
                    CreatedByUserId = a.CreatedByUserId
                   
                });
            }

            return await _repo.SaveAsync(package);
        }

        public Task<bool> UpdateAsync(int id, CreateAssessmentPackageDto updated) =>
            _repo.UpdateAsync(id, updated);

        public Task<bool> DeleteAsync(int id) =>
            _repo.DeleteAsync(id);

        public AssessmentPackage GetPackageById(int id)
        {
           return _repo.GetPackage(id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ClassLib.Models
{
    public enum RequestStatus
    {
        Pending,
        Approved,
        Rejected,
        //Reviewed
    }


    [Table("Candidate_Request")]
    public class CandidateRequest
    {
        [Key]
        public int RequestId { get; set; }

        public int UserId { get; set; }
        public int PackageId { get; set; }


        public string? ReviewedBY { get; set; } 
        public DateTime? ReviewDate { get; set; } 

        public RequestStatus RequestStatus { get; set; }


        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public UserTable? User { get; set; }
       // [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public AssessmentPackage? AssessmentPackage { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public ICollection<InstructorRequestView>? InstructorRequestViews { get; set; }
    }
}

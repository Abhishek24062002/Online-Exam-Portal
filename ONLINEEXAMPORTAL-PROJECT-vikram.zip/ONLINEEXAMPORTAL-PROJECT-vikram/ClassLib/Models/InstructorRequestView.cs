﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ClassLib.Models
{
    [Table("Instructor_Request_View")]
    public class InstructorRequestView
    {
        [Key]
        public int RequestViewId { get; set; }

        public int RequestId { get; set; }
        public RequestStatus RequestStatus { get; set; } 
        public int UserId { get; set; }


        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public CandidateRequest? CandidateRequest { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public UserTable? User { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("Report")]
    public class Report
    {
        [Key]
        public int ReportId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public int AttemptId { get; set; }

        [Required]
        public int FeedbackId { get; set; }

        [Required]
        [StringLength(255)]
        public string Remarks { get; set; } = default!;

        [Required]
        [StringLength(255)]
        public string MarkDetails { get; set; } = default!;

        // Navigation properties
        public UserTable? User { get; set; }
       // public Response? Response { get; set; }

        public ExamAttempt ExamAttempt { get; set; }
        public Feedback? Feedback { get; set; }
    }
}

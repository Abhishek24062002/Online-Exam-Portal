﻿
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("Exam_Attempt")]
    public class ExamAttempt
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AttemptId { get; set; }

        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public DateTime AttemptDate { get; set; }
        public string CompletionStatus { get; set; } = default!;
        public int TotalMarkObtained { get; set; }
        public bool IsPassed { get; set; }

        //public User? User { get; set; }
        //public Assessment? Assessment { get; set; }
        public int? AssignmentId { get; set; }
        public AssessmentAssignment? AssessmentAssignment { get; set; }
      

        //public int ReportId {  get; set; }
        //public Report Report { get; set; }
    }
}

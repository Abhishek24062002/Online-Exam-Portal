﻿using ClassLib.Models;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


 
namespace ClassLib.Models
{
    [Table("Question")]
    public class Question
    {
        [Key]
        public int QuestionId { get; set; }

        public int AssessmentId { get; set; }
        public string QuestionText { get; set; } = default!;
        public string QuestionType { get; set; } = "Mcq";
        public int Mark { get; set; }
        //public bool IsAttempted { get; set; }=false;

        public Assessment? Assessment { get; set; }
        public ICollection<Option>? Options { get; set; }
        public ICollection<Response>? Responses { get; set; }
    }
}



//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace ClassLib.Models
//{
//    [Table("Question")]
//    public class Question
//    {
//        [Key]
//        public int QuestionId { get; set; }

//        public int AssessmentId { get; set; }
//        public string QuestionText { get; set; } = default!;
//        public string QuestionType { get; set; } = "Mcq";
//        public int SelectedOption { get; set; }
//        public int Mark { get; set; }
//        public bool IsAttempted { get; set; }
//        public int ObtainedMark { get; set; }

//        public Assessment? Assessment { get; set; }
//        public ICollection<Option>? Options { get; set; }
//        public ICollection<Response>? Responses { get; set; }
//    }
//}

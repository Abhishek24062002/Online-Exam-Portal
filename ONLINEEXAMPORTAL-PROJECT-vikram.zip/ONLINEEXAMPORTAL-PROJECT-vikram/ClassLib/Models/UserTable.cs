﻿using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ClassLib.Models
{
    public enum RoleType
    {
        Candidate,
        Instructor,
        Admin
    }

    [Table("UserTable")]
    public class UserTable
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        public string Name { get; set; } = default!;

        [Required, EmailAddress]
        public string Email { get; set; } = default!;

        [Required]
        public string Password { get; set; } = default!;

        public DateTime RegistrationDate { get; set; }

        [Required]
        public RoleType RoleType { get; set; }

        public string? PasswordResetToken { get; set; }
        public DateTime? TokenExpiry { get; set; }

        // Navigation: Created Assessments
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<Assessment>? CreatedAssessments { get; set; }

        // Navigation: Assigned to User
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<AssessmentAssignment>? AssessmentAssignments { get; set; }

        // Other Navigation Properties
        // public ICollection<AssessmentPackage>? AssessmentPackages { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<CandidateRequest>? CandidateRequests { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<InstructorRequestView>? InstructorRequestViews { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<ExamAttempt>? ExamAttempts { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<Response>? Responses { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<Feedback>? Feedbacks { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<Report>? Reports { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ICollection<LeaderBoard>? LeaderBoards { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public ICollection<InstructorApproval>? InstructorApprovals { get; set; }
    }
}


//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace ClassLib.Models
//{
//    public enum RoleType
//    {
//        Candidate,
//        Instructor,
//        Admin
//    }

//    [Table("User")]
//    public class User
//    {
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
//        public int UserId { get; set; }
//        [Required]
//        [StringLength(50)]
//        public string Name { get; set; } = null!;

//        [Required]
//        [StringLength(50)]
//        public string Email { get; set; } = null!;

//        [Required]
//        [StringLength(50)]
//        [DataType(DataType.Password)]
//        public string Password { get; set; } = null!;

//        [Required]
//        public DateTime RegistrationDate { get; set; }


//        [Required]
//        public RoleType RoleType { get; set; }   // ✅ now correctly required

//        // Navigation properties
//        public ICollection<Assessment>? Assessments { get; set; }
//        public ICollection<AssessmentPackage>? AssessmentPackages { get; set; }
//        public ICollection<CandidateRequest>? CandidateRequests { get; set; }
//        public ICollection<InstructorRequestView>? InstructorRequestViews { get; set; }
//        public ICollection<ExamAttempt>? ExamAttempts { get; set; }
//        public ICollection<Response>? Responses { get; set; }
//        public ICollection<Feedback>? Feedbacks { get; set; }
//        public ICollection<Report>? Reports { get; set; }
//        public ICollection<LeaderBoard>? LeaderBoards { get; set; }
//        public ICollection<InstructorApproval>? InstructorApprovals { get; set; }
//        public ICollection<AssessmentAssignment>AssessmentAssignments { get; internal set; }
//    }
//}

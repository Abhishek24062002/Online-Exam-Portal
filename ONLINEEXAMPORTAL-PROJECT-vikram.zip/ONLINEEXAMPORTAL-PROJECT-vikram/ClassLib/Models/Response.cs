﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("Response")]
    public class Response
    {
        [Key]
        public int ResponseId { get; set; }

        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public int QuestionId { get; set; }
        public int OptionId { get; set; }
        public int ObtainedMark { get; set; }

       // public bool IsAttempted { get; set; }=false;


        public UserTable? User { get; set; }//remove in dto
        public Assessment? Assessment { get; set; }//remove in dto
        public Question? Question { get; set; }
        public Option? Option { get; set; }

        public ICollection<Report>? Reports { get; set; }
        public ICollection<LeaderBoard>? LeaderBoards { get; set; }
    }
}

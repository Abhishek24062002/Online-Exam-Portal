﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("Feedback")]
    public class Feedback
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int FeedbackId { get; set; }

        public int AssignmentId { get; set; }
        public int UserId { get; set; }
        public int AssessmentId { get; set; }
        public int Rating { get; set; }
        public string Comments { get; set; } = default!;

        public AssessmentAssignment AssessmentAssignment { get; set; }  

      //  public UserTable? User { get; set; }
      //  public Assessment? Assessment { get; set; }

       

       public Report Reports { get; set; }
    }
}

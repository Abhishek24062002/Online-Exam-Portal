﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("Option")]
    public class Option
    {
        [Key]
        public int OptionId { get; set; }

        public int QuestionId { get; set; }
        public string OptionsText { get; set; } = default!;
        public string Answer { get; set; } = default!;

        public Question? Question { get; set; }
    }
}

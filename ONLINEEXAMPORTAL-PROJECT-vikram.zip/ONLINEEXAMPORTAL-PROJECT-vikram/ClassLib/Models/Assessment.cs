﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    public enum AssessmentType
    {
        Quiz,
        Assignment,
        Interview
    }

    [Table("Assessment")]
    public class Assessment
    {
        [Key]
        public int AssessmentId { get; set; }

        [Required]
        public string Title { get; set; } = default!;

        [Required]
        public string Description { get; set; } = default!;

        public DateTime ScheduledDate { get; set; }
        public int Duration { get; set; }
        public int MaxMark { get; set; }
        public int PassMark { get; set; }

        [Required]
        public string Status { get; set; } = default!;
        public DateTime EndTime { get; set; }

        [Required]
        public AssessmentType AssessmentType { get; set; }

        public int? CreatedByUserId { get; set; }
        public UserTable? CreatedByUser { get; set; }

        // ✅ Nullable foreign key for optional package
        public int? packageId { get; set; }
        public AssessmentPackage? Package { get; set; }

        // Navigation Properties
        public ICollection<Question>? Questions { get; set; }
        public ICollection<Feedback>? Feedbacks { get; set; }
        public ICollection<Response>? Responses { get; set; }
        public ICollection<AssessmentAssignment>? AssessmentAssignment { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ClassLib.Models
{
    public enum ApprovalStatus
    {
        Pending,
        Approved,
        Denied
    }
    [Table("Instructor_Approval")]
    public class InstructorApproval
    {
        [Key]
        public int ApprovalId { get; set; }

        [Required]
        public int UserId { get; set; }

        public ApprovalStatus ApprovalStatus { set; get; } = ApprovalStatus.Pending;  // 'Accept' or 'Reject'

        // Navigation property
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public UserTable? User { get; set; }
    }
}

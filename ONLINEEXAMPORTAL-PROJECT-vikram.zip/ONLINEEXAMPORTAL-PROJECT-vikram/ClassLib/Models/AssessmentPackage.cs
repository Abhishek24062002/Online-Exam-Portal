﻿using ClassLib.Models;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace ClassLib.Models
{
    [Table("Assessment_Package")]
    public class AssessmentPackage
    {
        [Key]
        public int PackageId { get; set; }

        public string PackageName { get; set; }



        // public int UserId { get; set; }
        // public int AssessmentId { get; set; }

        //public UserTable? User { get; set; }
        //public ICollection<Assessment?> Assessments { get; set; }
        //[JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    
        public ICollection<Assessment>? Assessments { get; set; } = new List<Assessment>();
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]

        public ICollection<CandidateRequest?> CandidateRequests { get; set; }
    }
}




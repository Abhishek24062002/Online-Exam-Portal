﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ClassLib.Models
{
    public class AssessmentAssignment
    {
        [Key]
        public int AssignmentId { get; set; }


        public int AssessmentId { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public Assessment Assessment { get; set; }

        public int UserId { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public UserTable User { get; set; }

        public DateTime AssignedDate { get; set; }
        public bool IsCompleted { get; set; }

        public int AttemptId { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public ExamAttempt? ExamAttempt { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
        public Feedback Feedback { get; set; }
       
    }

}

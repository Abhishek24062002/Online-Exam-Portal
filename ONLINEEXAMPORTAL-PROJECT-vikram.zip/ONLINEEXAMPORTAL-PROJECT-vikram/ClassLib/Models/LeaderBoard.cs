﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClassLib.Models
{
    [Table("LeaderBoard")]
    public class LeaderBoard
    {
        [Key]
        public int LeaderboardId { get; set; }

        [Required]
        public int ResponseId { get; set; }

        [Required]
        public int Rank { get; set; }

        [Required]
        public int UserId { get; set; }

        // Navigation properties
        public Response? Response { get; set; }
        public UserTable? User { get; set; }
    }
}

﻿////using Microsoft.AspNetCore.Http;
////using Microsoft.AspNetCore.Mvc.Filters;
////using System.Web.Http.Results;
////using System.Web.Mvc;

////public class CustomExceptionFilter : IExceptionFilter
////{
////    public void OnException(ExceptionContext context)
////    {
////        var exception = context.Exception;
////        var statusCode = StatusCodes.Status500InternalServerError;
////        var errorResponse = new
////        {
////            ExceptionType = exception.GetType().Name,
////            Message = exception.Message
////        };

////        context.Result = new JsonResult(errorResponse)
////        {
////            StatusCode = statusCode
////        };


////        context.ExceptionHandled = true;
////    }
////}




//var result = new JsonResult(new { ExceptionName = "Custom Error", Exception = context.Exception.Message });
//result.StatusCode = StatusCodes.Status500InternalServerError;

//context.ExceptionHandled = true;
//context.Result = result;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;

public class CustomExceptionFilter : IExceptionFilter
{
    private readonly ILogger<CustomExceptionFilter> _logger;

    public CustomExceptionFilter(ILogger<CustomExceptionFilter> logger)
    {
        _logger = logger;
    }

    public void OnException(ExceptionContext context)
    {
        var exception = context.Exception;
        int statusCode = StatusCodes.Status500InternalServerError;
        string exceptionName = "Unhandled Exception";
        string message = exception.Message;

        switch (exception)
        {
            case ArgumentNullException argNullEx:
                exceptionName = "Argument Null Exception";
                message = argNullEx.Message;
                statusCode = StatusCodes.Status400BadRequest;
                break;

            case UnauthorizedAccessException unauthorizedEx:
                exceptionName = "Unauthorized Access";
                message = unauthorizedEx.Message;
                statusCode = StatusCodes.Status401Unauthorized;
                break;

            case InvalidOperationException invalidOpEx:
                exceptionName = "Invalid Operation";
                message = invalidOpEx.Message;
                statusCode = StatusCodes.Status409Conflict;
                break;

            case KeyNotFoundException keyNotFoundEx:
                exceptionName = "Key Not Found";
                message = keyNotFoundEx.Message;
                statusCode = StatusCodes.Status404NotFound;
                break;

            default:
                exceptionName = "Generic Error";
                message = exception.Message;
                statusCode = StatusCodes.Status500InternalServerError;
                break;
        }


        /*
           //Another way to print the details exceptions
            

         var root = exception;
         while (root.InnerException != null)
        root = root.InnerException;

         _logger.LogError(exception,
        "[{Timestamp}] {ExceptionType}: {RootMessage}",
          DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
        exceptionName,
        root.Message);
                    
        var response = new ExceptionResponse
         {

    ExceptionName = exceptionName,
    ExceptionMessage = root.Message
     };

         
         
         
         */








        //Catching the actual error 
        var baseEx = exception.GetBaseException();


        //  Log with timestamp and full exception info for log purposes i created this
        _logger.LogError(exception,
            "[{Timestamp}] {ExceptionType}: {ExceptionMessage}",
            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            exceptionName,
            baseEx.Message);

        // to give the error or exception response without stack trace
        var response = new ExceptionResponse
        {
            ExceptionName = exceptionName,
            ExceptionMessage = baseEx.Message
        };

        context.Result = new ObjectResult(response)
        {
            StatusCode = statusCode
        };

        context.ExceptionHandled = true;
    }
}


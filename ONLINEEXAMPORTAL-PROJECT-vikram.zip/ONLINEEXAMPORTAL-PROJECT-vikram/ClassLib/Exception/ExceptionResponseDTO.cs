﻿public class ExceptionResponse
{
    public string ExceptionName { get; set; } = string.Empty;
    public string ExceptionMessage { get; set; } = string.Empty;
   // public string? StackTrace { get; set; }
}

﻿using ClassLib.Dto;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{


    public interface IReportRepository
    {
        Task<IEnumerable<ReportDetailsDto>> GetReportsAsync(string? assessmentTitle, string? userName);
    }


}
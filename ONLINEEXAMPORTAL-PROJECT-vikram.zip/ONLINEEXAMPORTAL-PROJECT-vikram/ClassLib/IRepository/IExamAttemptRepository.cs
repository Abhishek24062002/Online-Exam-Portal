﻿using ClassLib.Dto;
using ClassLib.Models;

public interface IExamAttemptRepository
{
    Task<IEnumerable<ExamAttempt>> GetAllAsync();
    Task<ExamAttempt> GetByIdAsync(int id);
    Task AddAsync(ExamAttempt attempt);
    Task UpdateAsync(ExamAttempt attempt);
    Task DeleteAsync(int id);

    int GetAttemptCountByAssessmentId(int assessmentId);
    List<UserSummaryDTO> GetUsersByAssessmentId(int assessmentId);
    Task<ExamAttempt?> GetAttemptAsync(int userId, int assessmentId);
    Task<List<Response>> GetResponsesAsync(int userId, int assessmentId);
    Task<int> GetQuestionCountAsync(int assessmentId);
    Task<Assessment?> GetAssessmentAsync(int assessmentId);
    Task SaveAttemptAsync(ExamAttempt attempt);

    AssessmentAssignment? GetAssignment(int userId, int assessmentId);
    void SaveAssignment(AssessmentAssignment assignment);

    Task<ExamAttempt> CreateAttemptAsync(ExamAttempt attempt);

}
﻿using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IOptionRepository
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetByIdAsync(int questionId);
        Task<CreateOptionDto> AddAsync(CreateOptionDto entity, int questionId);
        Task<bool> UpdateAsync(int id, Option updated);
        Task<bool> DeleteAsync(int id);
    }
}

﻿using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IResponseRepository
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<object>> GetAllAsync(int userId, int assessmentId);
        Task<Response> AddAsync(Response entity);
        Task<IEnumerable<object>> GetByIdAsync(int id);
        Task<bool> UpdateAsync(int id, Response updated);
        Task<bool> DeleteAsync(int id);
        Task DeleteResponsesAsync(List<Response> responses);
        Task<List<Response>> GetResponsesByUserAndAssessmentAsync(int userId, int assessmentId);

    }
}

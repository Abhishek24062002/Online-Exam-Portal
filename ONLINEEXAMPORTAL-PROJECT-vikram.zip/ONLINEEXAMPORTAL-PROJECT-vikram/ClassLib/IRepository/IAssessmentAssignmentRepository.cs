﻿using ClassLib.Models;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IAssessmentAssignmentRepository
    {
        Task<AssessmentAssignment> EnrollUserAsync(int userId, int assessmentId);
        Task<IEnumerable<Assessment>> FindAllAssessments(int packageId,int userId);
        Task<IEnumerable<object>> GetByUserIdAsync(int userId);

    }
}

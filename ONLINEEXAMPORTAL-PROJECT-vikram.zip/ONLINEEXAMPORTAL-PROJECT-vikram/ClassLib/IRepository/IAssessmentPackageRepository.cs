﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IAssessmentPackageRepository
    {
        Task<IEnumerable<object>> GetAllAsync();
        Task<IEnumerable<AssessmentPackageDto>> GetByIdAsync(int id);
        Task<IEnumerable<object>> GetPackagesByUserIdAsync(int userId);
        Task<IEnumerable<object>> GetAssessmentsByTitleKeywordAsync(string keyword);
        Task<AssessmentPackageDto> SaveAsync(AssessmentPackage package);
        Task<bool> UpdateAsync(int id, CreateAssessmentPackageDto updated);
        Task<bool> DeleteAsync(int id);
       public AssessmentPackage GetPackage(int id);
    }
}

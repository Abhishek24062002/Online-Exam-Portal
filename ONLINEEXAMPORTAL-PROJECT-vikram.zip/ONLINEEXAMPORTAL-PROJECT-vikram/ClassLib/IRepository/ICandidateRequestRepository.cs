﻿using ClassLib.Dto;
using ClassLib.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface ICandidateRequestRepository
{
    Task<string?> SaveAsync(CandidateRequest request);
    Task<IEnumerable<CandidateRequestDTO?>> GetAllAsync();

    Task<IEnumerable<CandidateRequest?>> GetAll();
    Task<CandidateRequestDTO?> GetByIdAsync(int id);
    Task<bool> DeleteAsync(int id);
    Task<IEnumerable<CandidateRequestDTO>> GetByUserIdAsync(int userId);
    Task<IEnumerable<CandidateRequestDTO>> GetByStatusAsync(string status);
     void CreateRaiseApproval(InstructorRequestView raiseApproval);
}

﻿using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IInstructorRequestViewRepository
    {
        Task<IEnumerable<InstructorRequestView>> GetAllRequestAsync();
        Task <InstructorRequestView?> FindRequestAsync(int id);
        Task<CandidateRequest> ReflectChange(int requestId);
        void UpdateStatus(CandidateRequest? approvalState);
        void UpdateStatus(InstructorRequestView? findRequest);
    }
}

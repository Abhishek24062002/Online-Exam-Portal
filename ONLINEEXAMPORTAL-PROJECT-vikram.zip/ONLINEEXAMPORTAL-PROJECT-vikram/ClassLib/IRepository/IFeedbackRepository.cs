﻿using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{

    public interface IFeedbackRepository
    {
        Task<IEnumerable<Feedback>> GetAllAsync();
        Task<Feedback?> GetByIdAsync(int id);
        Task AddAsync(Feedback feedback);
        Task UpdateAsync(Feedback feedback);
        Task<bool> IsAssignmentCompletedAsync(int assignmentId);

        //Task DeleteAsync(int id);
        // Task<IEnumerable<Feedback>> GetFeedbacksByAssessmentIdAsync(int assessmentId);
    }

}

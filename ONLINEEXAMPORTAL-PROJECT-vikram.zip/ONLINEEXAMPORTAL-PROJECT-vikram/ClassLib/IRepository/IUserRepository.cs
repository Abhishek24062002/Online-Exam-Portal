﻿using ClassLib.Dto;
using ClassLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.IRepository
{
    public interface IUserRepository
    {

        Task<UserTable> FindByIdAsync(int id);//
        Task<LoginWithRoleDTO?> FindUserAsync(LoginDTO credentials);
        Task<UserTable> Delete(UserTable user);//
        List<UserTable> FindAll();//
        UserTable FindByEmailAsync(string Email);
        Task<UserTable?>SaveUserAsync(UserTable user);//
        void SaveInsApprovalAsync(InstructorApproval user);
        Task<UserTable?> GetDetails(string user);
        UserTable Update(UserTable user);

        Task<InstructorApproval?> GetApprovalByUserIdAsync(int userId);
        Task UpdateApprovalAsync(InstructorApproval approval);

        Task<UserTable?> GetUserByEmailAsync(string email);
        Task<UserTable?> GetUserByResetTokenAsync(string token);
        Task UpdateUserAsync(UserTable user);
       List<InstructorApproval> GetApproveList();
    }
}

﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClassLib
{
    public class InstructorRequestViewConfig : IEntityTypeConfiguration<InstructorRequestView>
    {
        public void Configure(EntityTypeBuilder<InstructorRequestView> builder)
        {
            builder.ToTable("Instructor_Request_View");

            builder.HasKey(v => v.RequestViewId);

            builder.Property(v => v.RequestId)
                   .IsRequired();

            builder.Property(v => v.RequestStatus)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.Property(v => v.UserId)
                   .IsRequired();

            builder.HasOne(v => v.CandidateRequest)
                   .WithMany(r => r.InstructorRequestViews)
                   .HasForeignKey(v => v.RequestId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(v => v.User)
                   .WithMany(u => u.InstructorRequestViews)
                   .HasForeignKey(v => v.UserId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

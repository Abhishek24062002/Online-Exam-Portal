﻿using ClassLib.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClassLib.Configuration
{
    public class UserTableConfig : IEntityTypeConfiguration<UserTable>
    {
        public void Configure(EntityTypeBuilder<UserTable> builder)
        {
            builder.ToTable("UserTable");

            builder.HasKey(u => u.UserId);

            builder.Property(u => u.Name)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.Property(u => u.Email)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.HasIndex(u => u.Email)
                   .IsUnique();

            builder.Property(u => u.Password)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.Property(u => u.RegistrationDate)
                   .IsRequired();

            builder.Property(u => u.RoleType)
                   .IsRequired()
                   .HasConversion<string>()
                   .HasMaxLength(50);

            builder.HasMany(u => u.CreatedAssessments)
                   .WithOne(a => a.CreatedByUser)
                   .HasForeignKey(a => a.CreatedByUserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.AssessmentAssignments)
                   .WithOne(a => a.User)
                   .HasForeignKey(a => a.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            //builder.HasMany(u => u.AssessmentPackages)
            //       .WithOne(p => p.User)
            //       .HasForeignKey(p => p.UserId)
            //       .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.CandidateRequests)
                   .WithOne(c => c.User)
                   .HasForeignKey(c => c.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.InstructorRequestViews)
                   .WithOne(i => i.User)
                   .HasForeignKey(i => i.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            //builder.HasMany(u => u.ExamAttempts)
            //       .WithOne(e => e.User)
            //       .HasForeignKey(e => e.UserId)
            //       .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.Responses)
                   .WithOne(r => r.User)
                   .HasForeignKey(r => r.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            //builder.HasMany(u => u.Feedbacks)
            //       .WithOne(f => f.User)
            //       .HasForeignKey(f => f.UserId)
            //       .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.Reports)
                   .WithOne(rp => rp.User)
                   .HasForeignKey(rp => rp.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.LeaderBoards)
                   .WithOne(lb => lb.User)
                   .HasForeignKey(lb => lb.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(u => u.InstructorApprovals)
                   .WithOne(ia => ia.User)
                   .HasForeignKey(ia => ia.UserId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}


//using ClassLib.Models;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;

//namespace ClassLib.Configuration
//{
//    public class UserConfig : IEntityTypeConfiguration<User>
//    {
//        public void Configure(EntityTypeBuilder<User> builder)
//        {
//            builder.ToTable("User");

//            builder.HasKey(u => u.UserId);

//            builder.Property(u => u.Name)
//                   .IsRequired()
//                   .HasMaxLength(255);

//            builder.Property(u => u.Email)
//                   .IsRequired()
//                   .HasMaxLength(255);

//            builder.HasIndex(u => u.Email)
//                   .IsUnique();

//            builder.Property(u => u.Password)
//                   .IsRequired()
//                   .HasMaxLength(255);

//            builder.Property(u => u.RegistrationDate)
//                   .IsRequired();

//            builder.Property(u => u.RoleType)
//                   .IsRequired()
//                   .HasConversion<string>()
//                   .HasMaxLength(50);  

//           // Navigation relationships(no changes needed)
//            builder.HasMany(u => u.Assessments)
//                   .WithOne(a => a.User)
//                   .HasForeignKey(a => a.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.AssessmentPackages)
//                   .WithOne(p => p.User)
//                   .HasForeignKey(p => p.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.CandidateRequests)
//                   .WithOne(c => c.User)
//                   .HasForeignKey(c => c.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.InstructorRequestViews)
//                   .WithOne(i => i.User)
//                   .HasForeignKey(i => i.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.ExamAttempts)
//                   .WithOne(e => e.User)
//                   .HasForeignKey(e => e.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.Responses)
//                   .WithOne(r => r.User)
//                   .HasForeignKey(r => r.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.Feedbacks)
//                   .WithOne(f => f.User)
//                   .HasForeignKey(f => f.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.Reports)
//                   .WithOne(rp => rp.User)
//                   .HasForeignKey(rp => rp.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.LeaderBoards)
//                   .WithOne(lb => lb.User)
//                   .HasForeignKey(lb => lb.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(u => u.InstructorApprovals)
//                   .WithOne(ia => ia.User)
//                   .HasForeignKey(ia => ia.UserId)
//                   .OnDelete(DeleteBehavior.Restrict);
//        }
//    }
//}

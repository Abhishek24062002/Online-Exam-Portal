﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib.Configuration
{
    public class OptionConfig : IEntityTypeConfiguration<Option>
    {
        public void Configure(EntityTypeBuilder<Option> builder)
        {
            builder.ToTable("Option");

            builder.HasKey(o => o.OptionId);

            builder.Property(o => o.QuestionId)
                   .IsRequired();

            builder.Property(o => o.OptionsText)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.Property(o => o.Answer)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.HasOne(o => o.Question)
                   .WithMany(q => q.Options)
                   .HasForeignKey(o => o.QuestionId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

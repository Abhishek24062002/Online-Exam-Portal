﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib.Configuration
{
    public class ExamAttemptConfig : IEntityTypeConfiguration<ExamAttempt>
    {
        public void Configure(EntityTypeBuilder<ExamAttempt> builder)
        {
            builder.ToTable("Exam_Attempt");

            builder.HasKey(e => e.AttemptId);

            builder.Property(e => e.UserId)
                   .IsRequired();

            builder.Property(e => e.AssessmentId)
                   .IsRequired();

            builder.Property(e => e.AttemptDate)
                   .IsRequired();

            builder.Property(e => e.CompletionStatus)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.Property(e => e.TotalMarkObtained)
                   .IsRequired();

            builder.Property(e => e.IsPassed)
                   .IsRequired();

            //builder.HasOne(e => e.User)
            //       .WithMany(u => u.ExamAttempts)
            //       .HasForeignKey(e => e.UserId)
            //       .OnDelete(DeleteBehavior.Restrict);

            //builder.HasOne(e => e.Assessment)
            //       .WithMany(a => a.ExamAttempts)
            //       .HasForeignKey(e => e.AssessmentId)
            //       .OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(e => e.AssessmentAssignment)
              .WithOne(a => a.ExamAttempt)
              .HasForeignKey<ExamAttempt>(e => e.AssignmentId)
              .IsRequired(false); // Optional binding

        }
    }
}

﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib.Configuration
{
    public class ResponseConfig : IEntityTypeConfiguration<Response>
    {
        public void Configure(EntityTypeBuilder<Response> builder)
        {
            builder.ToTable("Response");

            builder.HasKey(r => r.ResponseId);

            builder.Property(r => r.UserId)
                   .IsRequired();

            builder.Property(r => r.AssessmentId)
                   .IsRequired();

            builder.Property(r => r.QuestionId)
                   .IsRequired();

            builder.Property(r => r.OptionId)
                   .IsRequired();

            builder.Property(r => r.ObtainedMark)
                   .IsRequired();

            builder.HasOne(r => r.User)
                   .WithMany(u => u.Responses)
                   .HasForeignKey(r => r.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(r => r.Assessment)
                   .WithMany(a => a.Responses)
                   .HasForeignKey(r => r.AssessmentId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(r => r.Question)
                   .WithMany(q => q.Responses)
                   .HasForeignKey(r => r.QuestionId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(r => r.Option)
                   .WithMany()
                   .HasForeignKey(r => r.OptionId)
                   .OnDelete(DeleteBehavior.Restrict);

            //builder.HasMany(r => r.Reports)
            //       .WithOne(rep => rep.Response)
            //       .HasForeignKey(rep => rep.ResponseId)
            //       .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(r => r.LeaderBoards)
                   .WithOne(lb => lb.Response)
                   .HasForeignKey(lb => lb.ResponseId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

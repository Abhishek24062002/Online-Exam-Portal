﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class AssessmentPackageConfig : IEntityTypeConfiguration<AssessmentPackage>
{
    public void Configure(EntityTypeBuilder<AssessmentPackage> builder)
    {
        builder.ToTable("Assessment_Package");

        builder.HasKey(p => p.PackageId);

        builder.Property(p => p.PackageName)
               .IsRequired()
               .HasMaxLength(100);

        builder.HasMany(p => p.CandidateRequests)
               .WithOne(r => r.AssessmentPackage)
               .HasForeignKey(r => r.PackageId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasMany(p => p.Assessments)
               .WithOne(a => a.Package)
               .HasForeignKey(a => a.packageId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}

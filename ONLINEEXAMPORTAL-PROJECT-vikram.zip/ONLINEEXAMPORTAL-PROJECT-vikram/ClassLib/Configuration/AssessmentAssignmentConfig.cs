﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLib.Configuration
{
    

    public class AssessmentAssignmentConfig : IEntityTypeConfiguration<AssessmentAssignment>
    {
        public void Configure(EntityTypeBuilder<AssessmentAssignment> builder)
        {
            builder.ToTable("Assessment_Assignment");

            builder.HasKey(a => a.AssignmentId);

            builder.Property(a => a.AssignedDate)
                   .IsRequired();

            builder.Property(a => a.IsCompleted)
                   .HasDefaultValue(false);

            builder.HasOne(a => a.User)
                   .WithMany(u => u.AssessmentAssignments)
                   .HasForeignKey(a => a.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(a => a.Assessment)
                   .WithMany(u => u.AssessmentAssignment)
                   .HasForeignKey(a => a.AssessmentId)
                   .OnDelete(DeleteBehavior.Cascade);


            //builder.HasOne(e => e.ExamAttempt)
            //    .WithOne(a => a.AssessmentAssignment)
            //    .HasForeignKey(e => e.AssignmentId);

            builder.HasOne(e => e.ExamAttempt)
       .WithOne(a => a.AssessmentAssignment)
       .HasForeignKey<ExamAttempt>(e => e.AssignmentId);

            builder.HasOne(a => a.Feedback)
             .WithOne(f => f.AssessmentAssignment)
             .HasForeignKey<Feedback>(f => f.AssignmentId);


        }
    }
}

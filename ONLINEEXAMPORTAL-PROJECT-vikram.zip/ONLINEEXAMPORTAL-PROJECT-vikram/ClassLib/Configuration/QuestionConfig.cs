﻿using ClassLib.Models;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClassLib.Configuration
{
    public class QuestionConfig : IEntityTypeConfiguration<Question>
    {
        public void Configure(EntityTypeBuilder<Question> builder)
        {
            builder.ToTable("Question");

            builder.HasKey(q => q.QuestionId);

            builder.Property(q => q.AssessmentId).IsRequired();
            builder.Property(q => q.QuestionText).IsRequired().HasMaxLength(255);
            builder.Property(q => q.QuestionType).IsRequired().HasMaxLength(50);
            builder.Property(q => q.Mark).IsRequired();
          //  builder.Property(q => q.IsAttempted).IsRequired();

            builder.HasOne(q => q.Assessment)
                   .WithMany(a => a.Questions)
                   .HasForeignKey(q => q.AssessmentId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(q => q.Options)
                   .WithOne(o => o.Question)
                   .HasForeignKey(o => o.QuestionId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(q => q.Responses)
                   .WithOne(r => r.Question)
                   .HasForeignKey(r => r.QuestionId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}



//using ClassLib.Models;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata.Builders;


//namespace ClassLib.Configuration
//{
//    public class QuestionConfig : IEntityTypeConfiguration<Question>
//    {
//        public void Configure(EntityTypeBuilder<Question> builder)
//        {
//            builder.ToTable("Question");

//            builder.HasKey(q => q.QuestionId);

//            builder.Property(q => q.AssessmentId)
//                   .IsRequired();

//            builder.Property(q => q.QuestionText)
//                   .IsRequired()
//                   .HasMaxLength(255);

//            builder.Property(q => q.QuestionType)
//                   .IsRequired()
//                   .HasMaxLength(50);

//            builder.Property(q => q.SelectedOption)
//                   .IsRequired();

//            builder.Property(q => q.Mark)
//                   .IsRequired();

//            builder.Property(q => q.IsAttempted)
//                   .IsRequired();

//            builder.Property(q => q.ObtainedMark)
//                   .IsRequired();

//            builder.HasOne(q => q.Assessment)
//                   .WithMany(a => a.Questions)
//                   .HasForeignKey(q => q.AssessmentId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(q => q.Options)
//                   .WithOne(o => o.Question)
//                   .HasForeignKey(o => o.QuestionId)
//                   .OnDelete(DeleteBehavior.Restrict);

//            builder.HasMany(q => q.Responses)
//                   .WithOne(r => r.Question)
//                   .HasForeignKey(r => r.QuestionId)
//                   .OnDelete(DeleteBehavior.Restrict);
//        }
//    }
//}

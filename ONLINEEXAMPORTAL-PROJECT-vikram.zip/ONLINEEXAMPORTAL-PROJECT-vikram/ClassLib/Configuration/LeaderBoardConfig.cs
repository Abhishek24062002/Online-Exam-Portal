﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClassLib
{
    public class LeaderBoardConfig : IEntityTypeConfiguration<LeaderBoard>
    {
        public void Configure(EntityTypeBuilder<LeaderBoard> builder)
        {
            builder.ToTable("LeaderBoard");

            builder.HasKey(lb => lb.LeaderboardId);

            builder.Property(lb => lb.ResponseId)
                   .IsRequired();

            builder.Property(lb => lb.Rank)
                   .IsRequired();

            builder.Property(lb => lb.UserId)
                   .IsRequired();

            builder.HasOne(lb => lb.User)
                   .WithMany(u => u.LeaderBoards)
                   .HasForeignKey(lb => lb.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(lb => lb.Response)
                   .WithMany(r => r.LeaderBoards)
                   .HasForeignKey(lb => lb.ResponseId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

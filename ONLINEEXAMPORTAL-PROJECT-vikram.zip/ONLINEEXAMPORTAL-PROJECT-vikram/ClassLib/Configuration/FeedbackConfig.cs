﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib
{
    public class FeedbackConfig : IEntityTypeConfiguration<Feedback>
    {
        public void Configure(EntityTypeBuilder<Feedback> builder)
        {
            builder.ToTable("Feedback");

            builder.HasKey(f => f.FeedbackId);

            builder.Property(f => f.UserId)
                   .IsRequired();

            builder.Property(f => f.AssessmentId)
                   .IsRequired();

            builder.Property(f => f.Rating)
                   .IsRequired();

            builder.Property(f => f.Comments)
                   .IsRequired();

            //builder.HasOne(f => f.User)
            //       .WithMany(u => u.Feedbacks)
            //       .HasForeignKey(f => f.UserId)
            //       .OnDelete(DeleteBehavior.Restrict);

            //builder.HasOne(f => f.Assessment)
            //       .WithMany(a => a.Feedbacks)
            //       .HasForeignKey(f => f.AssessmentId)
            //       .OnDelete(DeleteBehavior.Restrict);

            //builder.HasMany(f => f.Reports)
            //       .WithOne(r => r.Feedback)
            //       .HasForeignKey(r => r.FeedbackId)
            //       .OnDelete(DeleteBehavior.Restrict);

            builder
                .HasOne(f => f.AssessmentAssignment)
                .WithOne(a => a.Feedback)
                .HasForeignKey<Feedback>(f => f.AssignmentId).
                OnDelete(DeleteBehavior.Restrict); 

        }
    }
}

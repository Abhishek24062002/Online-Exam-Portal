﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib
{
    public class InstructorApprovalConfig : IEntityTypeConfiguration<InstructorApproval>
    {
        public void Configure(EntityTypeBuilder<InstructorApproval> builder)
        {
            builder.ToTable("Instructor_Approval");

            builder.HasKey(a => a.ApprovalId);

            builder.Property(a => a.UserId)
                   .IsRequired();

            builder.Property(a => a.ApprovalStatus)
       .IsRequired()
       .HasConversion<string>()
       .HasMaxLength(50);



            builder.HasOne(a => a.User)
                   .WithMany(u => u.InstructorApprovals)
                   .HasForeignKey(a => a.UserId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace ClassLib.Configuration
{
    public class CandidateRequestConfig : IEntityTypeConfiguration<CandidateRequest>
    {
        public void Configure(EntityTypeBuilder<CandidateRequest> builder)
        {
            builder.ToTable("Candidate_Request");

            builder.HasKey(r => r.RequestId);

            builder.Property(r => r.UserId)
                   .IsRequired();

            builder.Property(r => r.PackageId)
                   .IsRequired();

            builder.Property(r => r.RequestStatus)
        .IsRequired()
        .HasConversion<string>()
        .HasMaxLength(50);


            builder.Property(r => r.ReviewedBY)
            //       //.IsRequired()
                  .HasMaxLength(255);

            builder.Property(r => r.ReviewDate);
            //       //.IsRequired();

            builder.HasOne(r => r.User)
                   .WithMany(u => u.CandidateRequests)
                   .HasForeignKey(r => r.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(r => r.AssessmentPackage)
                   .WithMany(p => p.CandidateRequests)
                   .HasForeignKey(r => r.PackageId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(r => r.InstructorRequestViews)
                   .WithOne(v => v.CandidateRequest)
                   .HasForeignKey(v => v.RequestId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

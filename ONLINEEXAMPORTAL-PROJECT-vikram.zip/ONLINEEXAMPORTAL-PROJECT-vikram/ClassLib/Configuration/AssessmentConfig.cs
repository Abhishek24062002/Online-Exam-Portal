﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class AssessmentConfig : IEntityTypeConfiguration<Assessment>
{
    public void Configure(EntityTypeBuilder<Assessment> builder)
    {
        builder.ToTable("Assessment");

        builder.HasKey(a => a.AssessmentId);

        builder.Property(a => a.Title)
               .IsRequired()
               .HasMaxLength(255);

        builder.Property(a => a.Description)
               .IsRequired()
               .HasMaxLength(255);

        builder.Property(a => a.AssessmentType)
               .IsRequired()
               .HasConversion<string>()
               .HasMaxLength(50);

        builder.Property(a => a.ScheduledDate).IsRequired();
        builder.Property(a => a.Duration).IsRequired();
        builder.Property(a => a.MaxMark).IsRequired();
        builder.Property(a => a.PassMark).IsRequired();
        builder.Property(a => a.Status).IsRequired().HasMaxLength(50);
        builder.Property(a => a.EndTime).IsRequired();

        builder.HasOne(a => a.CreatedByUser)
               .WithMany(u => u.CreatedAssessments)
               .HasForeignKey(a => a.CreatedByUserId)
               .OnDelete(DeleteBehavior.Cascade);

        // ✅ Configure nullable foreign key for package
        builder.HasOne(a => a.Package)
               .WithMany(p => p.Assessments)
               .HasForeignKey(a => a.packageId)
               .OnDelete(DeleteBehavior.Cascade);

        builder.HasMany(a => a.Questions)
               .WithOne(q => q.Assessment)
               .HasForeignKey(q => q.AssessmentId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasMany(a => a.Responses)
               .WithOne(r => r.Assessment)
               .HasForeignKey(r => r.AssessmentId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(a => a.Title);
        builder.HasIndex(a => a.AssessmentType);
        builder.HasIndex(a => a.ScheduledDate);
    }
}

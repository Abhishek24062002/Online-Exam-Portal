﻿using ClassLib.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ClassLib.Configuration
{
    public class ReportConfig : IEntityTypeConfiguration<Report>
    {
        public void Configure(EntityTypeBuilder<Report> builder)
        {
            builder.ToTable("Report");

            builder.HasKey(r => r.ReportId);

            builder.Property(r => r.UserId)
                   .IsRequired();

            builder.Property(r => r.AttemptId)
                   .IsRequired();

            builder.Property(r => r.FeedbackId)
                   .IsRequired();

            builder.Property(r => r.Remarks)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.Property(r => r.MarkDetails)
                   .IsRequired()
                   .HasMaxLength(255);

            builder.HasOne(r => r.User)
                   .WithMany(u => u.Reports)
                   .HasForeignKey(r => r.UserId)
                   .OnDelete(DeleteBehavior.Restrict);

            //builder.HasOne(r => r.Response)
            //       .WithMany(resp => resp.Reports)
            //       .HasForeignKey(r => r.ResponseId)
            //       .OnDelete(DeleteBehavior.Restrict);

            //builder.HasOne(r => r.ExamAttempt).WithOne(e => e.Report).HasForeignKey<ExamAttempt>(r => r.AttemptId);

            builder.HasOne(r => r.Feedback)
                   .WithOne(f => f.Reports)
                   .HasForeignKey<Report>(r => r.FeedbackId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}

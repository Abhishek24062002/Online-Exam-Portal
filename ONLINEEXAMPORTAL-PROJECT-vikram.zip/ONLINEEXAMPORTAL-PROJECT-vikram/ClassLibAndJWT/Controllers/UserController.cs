﻿using ClassLib;
using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using ClassLib.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OnlineExamPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class UserController : ControllerBase
    {
        private readonly IEmailService _emailService;
        private readonly IUserService _service;
       
        public UserController( IUserService service, IEmailService emailService)
        {
            _emailService = emailService;
            _service = service;
           
        }


        

        [HttpPost("register")]
        public async Task<IActionResult> Create([FromForm] UserDTO user)
        {
            if (user == null)
                return BadRequest("Enter all details");
            else if (user.RoleType == RoleType.Admin)
            {
                return BadRequest("You cannot create a Admin Account");
            }
            else
            {
                if (_service.IsValidEmail(user.Email) &&
                     _service.IsValidPassword(user.Password))
                {
                    var response = await _service.CreateAsync(user);

                    if (response != null)
                    {
                        // Send welcome email
                        var subject = "Welcome to Online Exam Portal!";
                        //var body = $"<h2>Hello {response.Name},</h2><p>Your account has been successfully created. You can now <a href='/login'>log in</a> and start using the platform.</p><br/><p>Thank you!</p>";
                        var body = $"Hello {response.Name},\n\nYour account has been successfully created.\nYou can now log in and start using the platform.\n\nThank you!";

                        try
                        {
                            await _emailService.SendEmailAsync(response.Email, subject, body);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Failed to send welcome email: {ex.Message}");
                            // Optionally log or handle email failure
                        }

                        return Ok(new
                        {
                            message = $"Welcome, {response.Name}! Your account has been created successfully.",
                            redirectTo = "/login"
                        });
                    }
                }

                //return Unauthorized("Cannot create user at the moment");
                return Unauthorized("Enter  Details in valid format ");
            }
        }


        [HttpGet("AllUserDetails")]
       //[Authorize(Roles = "Admin")]
        public ActionResult<IEnumerable<UserDTO>> GetDetails()
        {
            var items = _service.GetAll();
            if (items != null)
                return Ok(items);

            return BadRequest("cannot fetch right now");


        }


        [HttpGet("GetUser{email}")]
        public async Task<IActionResult> Getuser(string email)
        {
            var response = await _service.GetUser(email);
            if (response != null)
                return Ok(response);
            return BadRequest("couldn't fetch details right now ");

        }

        [HttpPut("updateUserDetails")]
        public IActionResult Update([FromBody] UserDTO user)
        {   
            var response= _service.UpdateUser(user);
            if (response !=null)
            return Ok("updated Successfully");

            return BadRequest("Cannot update user");

        }

        [HttpDelete("deleteUser")]
         [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete([FromForm] string email)
        {
            var response = await _service.DeleteByEmailAsync(email);
            if (response != null)
            {
                return Ok("Removed Successfully.");
            }
            return BadRequest("Unable to remove");
        }

       // [HttpDelete("deleteUser")]
        //public async Task<IActionResult> Delete([FromForm] int id)
        //{

        //    var response =await _service.DeleteByIdAsync(id);
        //    if (response !=null)
        //    {
        //         return Ok("Removed Successfully.");
        //    }
        //    return BadRequest("Unable to remove");


        //}














        [HttpGet("fetch")]
       
        public ContentResult fetchFromClaim()
        {
            string useNAME = User.FindFirst(ClaimTypes.Name).Value.ToString();
            string useEMAIL = User.FindFirst(ClaimTypes.Email).Value.ToString();
            string useRole = User.FindFirst(ClaimTypes.Role).Value.ToString();
            string usePassword = User.FindFirst("Password")?.Value.ToString();
          // string useRegDate = User.FindFirst("RegistrationDate")?.Value.ToString();

            return Content(" Name:   " + useNAME +  " Email:   "+ useEMAIL + "     Password:  " + usePassword + "    role:  "+useRole);
        }



    }
}

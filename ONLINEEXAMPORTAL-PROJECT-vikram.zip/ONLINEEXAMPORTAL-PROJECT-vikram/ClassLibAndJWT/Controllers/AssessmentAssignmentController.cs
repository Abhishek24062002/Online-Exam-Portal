﻿using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssessmentAssignmentController : ControllerBase
    {
        private readonly IAssessmentAssignmentService _service;

        public AssessmentAssignmentController(IAssessmentAssignmentService service)
        {
            _service = service;
        }

        [HttpPost("enroll")]
       // [Authorize(Roles = "Admin,Instructor")]

        public async Task<IActionResult> Enroll([FromQuery] int userId, [FromQuery] int assessmentId)
        {
            var result = await _service.EnrollAsync(userId, assessmentId);
            return Ok(new
            {
                Message = "Enrollment successful.",
                AssignmentId = result.AssignmentId,
                AssignedDate = result.AssignedDate
            });
        }

        [HttpGet("user/{userId}")]
        //[Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetByUserId(int userId)
        {
            var result = await _service.GetByUserIdAsync(userId);
            return result.Any() ? Ok(result) : NotFound($"No assignments found for UserId {userId}.");
        }





      

    }
}

﻿using ClassLib;

using ClassLib.Dto;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Repository;
using ClassLib.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
//[Authorize(Roles = "Candidate")]

public class ExamAttemptController : ControllerBase
{
    private readonly IExamAttemptService _service;

    public ExamAttemptController(IExamAttemptService service)
    {
        _service = service;
    }

    [HttpGet("ExamAttempted")]
    public async Task<IActionResult> GetAll()
    {
        var dtoList = await _service.GetAllAttemptsAsync();
        return Ok(dtoList);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var dto = await _service.GetAttemptByIdAsync(id);
        if (dto == null) return NotFound();
        return Ok(dto);
    }

    [HttpGet("assessment/attempts/Byassessmentid")]
    public IActionResult GetAssessmentAttempts([FromQuery] int assessmentId)
    {
        var count = _service.GetAttemptCountByAssessmentId(assessmentId);
        var users = _service.GetUsersByAssessmentId(assessmentId);

        var result = new
        {
            AssessmentId = assessmentId,
            AttemptCount = count,
            Candidates = users
        };

        return Ok(result);
    }

    [HttpPost("update-status")]
    public async Task<IActionResult> UpdateStatus([FromQuery] int userId, [FromQuery] int assessmentId)
    {
        await _service.UpdateAttemptStatusAsync(userId, assessmentId);
        return Ok(new { Message = "Attempt status updated successfully." });
    }

    [HttpPost("create-attempt")]
   
    public async Task<IActionResult> CreateAttempt([FromBody] CreateExamAttemptDTO dto)
    {
        var result = await _service.CreateAttemptAsync(dto);
        return Ok(result);
    }

}

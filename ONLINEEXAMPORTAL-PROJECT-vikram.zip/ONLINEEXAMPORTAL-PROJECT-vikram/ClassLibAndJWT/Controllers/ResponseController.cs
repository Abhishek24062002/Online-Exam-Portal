﻿using ClassLib.Dto;
using ClassLib.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
   // [Authorize(Roles = "Admin,Instructor")]

    public class ResponseController : ControllerBase
    {
        private readonly IResponseService _service;

        public ResponseController(IResponseService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var result = await _service.GetAllAsync();
            return result.Any() ? Ok(result) : NotFound("No responses found.");
        }

        [HttpGet("user/{userId}/assessment/{assessmentId}")]
        public async Task<IActionResult> GetUserResponses(int userId, int assessmentId)
        {
            var result = await _service.GetAllAsync(userId, assessmentId);
            return result.Any() ? Ok(result) : NotFound($"No responses found for UserId {userId} and AssessmentId {assessmentId}.");
        }

        [HttpPost]
        public async Task<IActionResult> SubmitResponse([FromBody] SubmitResponseDto dto)
        {
            var result = await _service.SubmitAsync(dto);
            return Ok(new
            {
                Message = "Response submitted.",
                IsCorrect = result.ObtainedMark > 0,
                ObtainedMark = result.ObtainedMark
            });
        }

        [HttpDelete("user/{userId}/assessment/{assessmentId}")]
        public async Task<IActionResult> DeleteUserResponses(int userId, int assessmentId)
        {
            var success = await _service.DeleteResponsesAsync(userId, assessmentId);
            if (success)
                return NoContent();
            return NotFound("No responses found to delete.");
        }
    }
}

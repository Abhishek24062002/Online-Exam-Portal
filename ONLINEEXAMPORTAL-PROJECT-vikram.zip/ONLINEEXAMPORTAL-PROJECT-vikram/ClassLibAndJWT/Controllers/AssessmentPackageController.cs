﻿using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssessmentPackageController : ControllerBase
    {
        private readonly IAssessmentPackageService _service;

        public AssessmentPackageController(IAssessmentPackageService service)
        {
            _service = service;
        }

        //  Get all packages
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var result = await _service.GetAllAsync();
            return result.Any() ? Ok(result) : NotFound("No assessment packages found.");
        }

        //  Get a specific package by ID
        [HttpGet("GetById/{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var result = await _service.GetPackageByIdAsync(id);
            return result.Any() ? Ok(result) : NotFound($"No package found with ID {id}.");
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetByPackId(int id)
        {
            var result =  _service.GetPackageById(id);
            return result!=null ? Ok(result) : NotFound($"No package found with ID {id}.");
        }

        //  Get packages assigned to a user
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetByUserId(int userId)
        {
            var result = await _service.GetPackagesByUserIdAsync(userId);
            return result.Any() ? Ok(result) : NotFound($"No packages found for UserId {userId}.");
        }

        //  Create a new package with embedded assessments
        [HttpPost]
        [Authorize(Roles = "Admin,Instructor")]

        public async Task<IActionResult> CreatePackage([FromBody] CreateAssessmentPackageDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.PackageName))
            {
                return BadRequest("Package name is required.");
            }

            var result = await _service.AddPackageAsync(dto);

            return Ok(new
            {
                Message = "Assessment package created successfully.",
                
                PackageName = result.PackageName,
                AssessmentsAdded = result.Assessments.Count
            });
        }

        //  Update an existing package
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Instructor")]

        public async Task<IActionResult> Update(int id, [FromBody] CreateAssessmentPackageDto updated)
        {
            var success = await _service.UpdateAsync(id, updated);
            return success ? Ok(new { Message = "Package updated successfully." }) : NotFound($"No package found with ID {id} to update.");
        }

        //  Delete a package
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,Instructor")]

        public async Task<IActionResult> Delete(int id)
        {
            var success = await _service.DeleteAsync(id);
            return success ? Ok(new { Message = "Package deleted successfully." }) : NotFound($"No package found with ID {id} to delete.");
        }

        //  Search for assessments by title keyword
        [HttpGet("name/{packageName}")]
        public async Task<IActionResult> GetAssessmentsByPackageName(string packageName)
        {
            var result = await _service.GetAssessmentsByTitleKeywordAsync(packageName);
            return result.Any() ? Ok(result) : NotFound($"No assessments found under package name containing '{packageName}'.");
        }


    }
}

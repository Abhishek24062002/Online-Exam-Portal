﻿using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace OnlineExamPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize(Roles = "Admin")]
    public class InstructorApprovalController : ControllerBase
    {
        private readonly IUserService _service;

        public InstructorApprovalController(IUserService service)
        {

            _service = service;
           
        }
        [HttpPost("approve/{userId}")]
       // [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApproveInstructor(int userId)
        {
            var response =  await _service.Approval(userId);
            if (response != null)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

        [HttpGet("Approval")]
        //[Authorize(Roles = "Admin")]
        public IActionResult GetApprove()
        {
            var response =  _service.GetApprovalList();
            if (response != null)
            {
                return Ok(response);
            }
            return BadRequest(response);
        }

    }
}

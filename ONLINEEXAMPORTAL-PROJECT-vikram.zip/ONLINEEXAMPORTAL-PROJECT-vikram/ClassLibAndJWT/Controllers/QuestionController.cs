﻿using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
   // [Authorize(Roles = "Admin,Instructor")]

    public class QuestionController : ControllerBase
    {
        private readonly IQuestionService _service;

        public QuestionController(IQuestionService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var questions = await _service.GetAllAsync();
            return questions.Any() ? Ok(questions) : NotFound("No questions found.");
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetQuestionById(int id)
        {
            var question = await _service.GetByIdAsync(id);
            return question.Any() ? Ok(question) : NotFound($"No question found for QuestionId {id}");
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CreateQuestionDto dto)
        {
            if (dto.Options == null || dto.Options.Count < 2)
                return BadRequest("Each question must have at least two options.");

            var question = new Question
            {
                AssessmentId = dto.AssessmentId,
                QuestionText = dto.QuestionText,
                QuestionType = dto.QuestionType,
                Mark = dto.Mark,
                //IsAttempted = false,
                Options = dto.Options.Select(o => new Option
                {
                    OptionsText = o.OptionsText,
                    Answer = o.Answer
                }).ToList()
            };

            var result = await _service.AddAsync(question);
            return Ok(new
            {
                Message = "Question and options added successfully.",
                QuestionId = result.QuestionId,
                Options = result.Options.Select(o => new { o.OptionId, o.OptionsText })
            });
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] CreateQuestionDto updated)
        {
            var success = await _service.UpdateAsync(id, updated);
            return success ? Ok("Updated") : NotFound();
        }

        //[HttpDelete("{id}")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var success = await _service.DeleteAsync(id);
        //    return success ? Ok("Deleted") : NotFound();
        //}

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _service.DeleteAsync(id);
            if (success)
            {
                return Ok(new { message = "Deleted successfully" }); 
            }
            else
            {
                return NotFound(new { message = "Question not found" });
            }
        }
    }
}

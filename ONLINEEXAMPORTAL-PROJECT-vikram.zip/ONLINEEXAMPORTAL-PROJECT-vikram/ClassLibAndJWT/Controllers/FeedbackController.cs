﻿using ClassLib.Dto;
using ClassLib.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
   // [Authorize(Roles = "Candidate")]

    public class FeedbackController : ControllerBase
    {
        private readonly IFeedbackService _service;

        public FeedbackController(IFeedbackService service)
        {
            _service = service;
        }

        //[HttpPost("create")]
        //public async Task<IActionResult> CreateFeedback([FromBody] CreateFeedbackDto dto)
        //{
        //    var result = await _service.CreateFeedbackAsync(dto);
        //    return Ok(result);
        //}

        [HttpPost("create")]

        public async Task<IActionResult> CreateFeedback([FromBody] CreateFeedbackDto dto)
        {
            try
            {
                var result = await _service.CreateFeedbackAsync(dto);
                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPut("update/{id}")]

        public async Task<IActionResult> UpdateFeedback(int id, [FromBody] UpdateFeedbackDto dto)
        {
            var success = await _service.UpdateFeedbackAsync(id, dto);
            return success ? Ok("Feedback updated.") : NotFound("Feedback not found.");
        }

        [HttpGet("{id}")]

        public async Task<IActionResult> GetFeedbackById(int id)
        {
            var feedback = await _service.GetFeedbackByIdAsync(id);
            return feedback != null ? Ok(feedback) : NotFound("Feedback not found.");
        }

        [HttpGet("all")]
        public async Task<IActionResult> GetAllFeedbacks()
        {
            var feedbacks = await _service.GetAllFeedbacksAsync();
            return Ok(feedbacks);
        }
    }
}

﻿using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    //[Authorize(Roles = "Admin,Instructor")]

    public class OptionController : ControllerBase
    {
        private readonly IOptionService _service;

        public OptionController(IOptionService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll() =>
            Ok(await _service.GetAllAsync());

        [HttpGet("option/{id}")]
        public async Task<IActionResult> GetOptionById(int id)
        {
            var result = await _service.GetByIdAsync(id);
            return result.Any() ? Ok(result) : NotFound($"No option found for QuestionId {id}");
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CreateOptionDto option, int questionId) =>
            Ok(await _service.AddAsync(option,questionId));

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Option updated) =>
            await _service.UpdateAsync(id, updated) ? Ok("Updated") : NotFound();

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id) =>
            await _service.DeleteAsync(id) ? Ok("Deleted") : NotFound();
    }
}

﻿using ClassLib;
using ClassLib.Data;
using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using ClassLib.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace OnlineExamPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
       
        //private readonly IConfiguration _configuration;
        private readonly IUserService _service;
        private readonly IEmailService _emailService;
        
        public LoginController(IUserService service, IEmailService emailService)
        {
            
            _service=service;
           // _configuration = configuration;
            _emailService = emailService;
        }

        //[HttpPost("login")]
        //public IActionResult Login([FromForm] string email, [FromForm] string password)
        //{
        //bool success = false;
        //var Record = _context.Users.FirstOrDefault(u => u.Name == username && u.Password == password);
        //if (Record != null)
        //    success = true;


        //if (success)
        //{
        //    var JwtToken = GenerateToken(Record);

        //    return Ok(new { Token = JwtToken });
        //}
        //return Content("Account NOt Found .");

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody]LoginDTO credentials)
        {
            
            if (credentials == null)
            {
                return BadRequest("Enter all the details");
            }
            var result = await _service.LoginAsync(credentials);

            if (result == null)
                    return BadRequest("Login Failed !!!");


            //if (result == null)
            //    {
            //        return Unauthorized("Invalid credentials");
            //    }

             var JwtToken = _service.GenerateToken(result);

             return Ok(new { Token =JwtToken });
           
        }

        


      

        //[HttpPost("register")]
        //public async Task<IActionResult> Create([FromForm] UserDTO user)
        //{
        //    if (user == null)
        //        return BadRequest("Enter all details");

        //    var response = await _service.CreateAsync(user);
        //    if (response != null)
        //    {
        //        // Send welcome email
        //        var subject = "Welcome to Online Exam Portal!";
        //        //var body = $"<h2>Hello {response.Name},</h2><p>Your account has been successfully created. You can now <a href='/login'>log in</a> and start using the platform.</p><br/><p>Thank you!</p>";
        //        var body = $"Hello {response.Name},\n\nYour account has been successfully created.\nYou can now log in and start using the platform.\n\nThank you!";

        //        try
        //        {
        //            await _emailService.SendEmailAsync(response.Email, subject, body);
        //        }
        //        catch (Exception ex)
        //        {
        //            Console.WriteLine($"Failed to send welcome email: {ex.Message}");
        //            // Optionally log or handle email failure
        //        }

        //        return Ok(new
        //        {
        //            message = $"Welcome, {response.Name}! Your account has been created successfully.",
        //            redirectTo = "/login"
        //        });
        //    }

        //    return Unauthorized("Cannot create user at the moment");
        //}



        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordDto dto)
        {
            var token = await _service.RequestPasswordResetAsync(dto.Email, Request.Headers["origin"]);
            return Ok(new
            {
                message = "If that email is registered, you will receive a reset link shortly.",
                token = token
            });
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto dto)
        {
            await _service.ResetPasswordAsync(dto);
            return Ok(new { message = "Password has been reset successfully." });
        }






    }
}

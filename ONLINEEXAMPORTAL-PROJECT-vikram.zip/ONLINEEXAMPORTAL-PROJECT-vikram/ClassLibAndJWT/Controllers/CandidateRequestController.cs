﻿using ClassLib.Dto;
using ClassLib.IService;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class CandidateRequestController : ControllerBase
{
    private readonly ICandidateRequestService _service;

    public CandidateRequestController(ICandidateRequestService service)
    {
        _service = service;
    }

    [HttpPost("create")]
    public async Task<IActionResult> Create([FromForm] CandidateRequestDTO dto)
    {
        var result = await _service.CreateAsync(dto);
        return result != null ? Ok(result) : BadRequest("Failed to create request");
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAll()
    {
        var requests = await _service.GetAllAsync();
        return requests!=null? Ok(requests):BadRequest("response not received");
    }

    [HttpGet("FullDetail")]
    public async Task<IActionResult?> GetAlllllll()
    {
        var requests = await _service.GetAll();
        return requests != null ? Ok(requests) : BadRequest("response not received");
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var request = await _service.GetByIdAsync(id);
        return request != null ? Ok(request) : NotFound("Request not found");
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var success = await _service.DeleteAsync(id);
        return success ? Ok("Request deleted") : BadRequest("Delete failed");
    }

    [HttpGet("by-user/{userId}")]
    public async Task<IActionResult> GetByUserId(int userId)
    {
        var requests = await _service.GetByUserIdAsync(userId);
        return Ok(requests);
    }

    [HttpGet("by-status/{status}")]
    public async Task<IActionResult> GetByStatus(string status)
    {
        var requests = await _service.GetByStatusAsync(status);
        return Ok(requests);
    }
}

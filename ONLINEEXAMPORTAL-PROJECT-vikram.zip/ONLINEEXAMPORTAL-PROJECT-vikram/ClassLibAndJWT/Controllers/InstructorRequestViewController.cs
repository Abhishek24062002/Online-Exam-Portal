﻿using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace OnlineExamPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize(Roles = "Admin,Instructor")]

    public class InstructorRequestViewController : ControllerBase
    {
        private readonly IInstructorRequestViewService _service;

           public InstructorRequestViewController(IInstructorRequestViewService service)
        {
            _service = service;
        }


        [HttpGet("getRequest")]
        public async  Task<IActionResult> Get()
        {
            var response = await _service.GetInstructorsRequestAsync();
            if (response == null)
            {
                return NotFound("cannot fetch request");
            }
                return Ok(response);
        }

        //[HttpPut("Approval{requestId}")]
        [HttpPut("Approval/{requestId}/{status}")]
        public async Task<IActionResult> Put(int requestId,RequestStatus status)
       
        {
            
            var response = await _service.GiveApproval(requestId,status);
            if (response != null)
            {
                return Ok(response);
            }
            return BadRequest("cannot access");
        }

    }
}

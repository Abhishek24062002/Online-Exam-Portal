﻿using ClassLib.Dto;
using ClassLib.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class ReportController : ControllerBase
    {
        private readonly IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService;
        }

        [HttpPost("generate")]
        public async Task<IActionResult> GenerateReports()
        {
            await _reportService.GenerateReportsAsync();
            return Ok("Reports generated successfully.");
        }

        // 1️⃣ Get all reports grouped by assessment
        [HttpGet("all")]
        public async Task<IActionResult> GetAllReports()
        {
            var reports = await _reportService.GetFilteredReportsAsync(null, null);
            return Ok(reports);
        }

        // 2️⃣ Filter reports by assessment title or user name
        [HttpGet("filter")]
        public async Task<IActionResult> FilterReports([FromQuery] string? assessmentTitle, [FromQuery] string? userName)
        {
            var reports = await _reportService.GetFilteredReportsAsync(assessmentTitle, userName);
            return Ok(reports);
        }
    }


}
﻿using ClassLib.Dto;
using ClassLib.IService;
using ClassLib.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLib.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssessmentController : ControllerBase
    {
        private readonly IAssessmentService _service;

        public AssessmentController(IAssessmentService service)
        {
            _service = service;
        }

       /* (Optional) Use at Controller or Action Level
If you want more granular control, you can apply it directly to a controller or method:

            [ServiceFilter(typeof(CustomExceptionFilter))]
        [HttpGet("get-assessment/{id}")]
        public IActionResult GetAssessment(int id)
        {
            // Your logic here
        }
       */

        [HttpGet("AllAssessments")]
      // [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetAll()
        {
            var assessments = await _service.GetAllAsync();
            return assessments.Any() ? Ok(assessments) : NotFound("No assessments found.");
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var assessment = await _service.GetByIdAsync(id);
            return assessment.Any() ? Ok(assessment) : NotFound($"No assessment found with ID {id}.");
        }

        [HttpGet("search/{keyword}")]
        public async Task<IActionResult> GetByKeyword(string keyword)
        {
            var result = await _service.GetAssessmentsByKeywordAsync(keyword);
            return result.Any() ? Ok(result) : NotFound($"No assessments found for keyword '{keyword}'.");
        }

        [HttpGet("package/{packageName}")]
        public async Task<IActionResult> GetByPackageName(string packageName)
        {
            var result = await _service.GetAssessmentsByPackageNameAsync(packageName);
            return result.Any() ? Ok(result) : NotFound($"No assessments found for package '{packageName}'.");
        }

        [HttpGet("creator/{userId}")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetByCreator(int userId)
        {
            var result = await _service.GetAssessmentsByCreatorIdAsync(userId);
            return result.Any() ? Ok(result) : NotFound($"No assessments created by user ID {userId}.");
        }

        [HttpGet("assigned/user/{userId}")]
        public async Task<IActionResult> GetAssignedAssessmentsByUserId(int userId)
        {
            var result = await _service.GetAssignedAssessmentsByUserIdAsync(userId);
            return result.Any() ? Ok(result) : NotFound($"No assessments assigned to user ID {userId}.");
        }

        [HttpPost("CreateAssesment")]
       [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> Add([FromBody] CreateAssessmentDto dto)
        {
            var result = await _service.AddAsync(dto);

            //if (result == null)
            //{
            //    return BadRequest();
            //}
            return Ok(new
            {
                Message = "Assessment created successfully",
                AssessmentId = result.AssessmentId,
                Title = result.Title,
                ScheduledDate = result.ScheduledDate
            });
        }

        [HttpPut("UpdateAssessment/{id}")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> Update(int id, [FromBody] CreateAssessmentDto updated)
        {
            var success = await _service.UpdateAsync(id, updated);

            if (!success)
                return BadRequest("Update failed. Assessment not found or invalid data.");

            return Ok("Assessment updated successfully.");
        }


        [HttpDelete("DeleteAssesment{id}")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _service.DeleteAsync(id);
            return success ? Ok("Deleted") : NotFound();
        }

        [HttpGet("{assessmentId}/questions")]
        public async Task<IActionResult> GetQuestionsWithOptions(int assessmentId)
        {
            var result = await _service.GetQuestionsWithOptionsByAssessmentIdAsync(assessmentId);
            return result.Any()
                ? Ok(result)
                : NotFound($"No questions found for assessment ID {assessmentId}.");
        }

        [HttpGet("{assessmentId}/questions/DemoExam")]
        public async Task<IActionResult> GetQuestionsWithOptionsExam(int assessmentId)
        {
            var result = await _service.GetQuestionsWithOptionsExamByAssessmentIdAsync(assessmentId);
            return result.Any()
                ? Ok(result)
                : NotFound($"No questions found for assessment ID {assessmentId}.");
        }

        [HttpGet("{assessmentId}/user/{userId}/obtainedmark")]
        public async Task<IActionResult> GetObtainedMark(int assessmentId, int userId)
        {
            var obtainedMark = await _service.GetObtainedMarkByUserAsync(userId, assessmentId);
            return Ok(new
            {
                AssessmentId = assessmentId,
                UserId = userId,
                ObtainedMark = obtainedMark
            });
        }

        [HttpGet("{assessmentId}/summary")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetAssessmentSummary(int assessmentId)
        {
            var summary = await _service.GetAssessmentSummaryAsync(assessmentId);
            return Ok(summary);
        }

        [HttpGet("{assessmentId}/users")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetUsersByAssessment(int assessmentId)
        {
            var users = await _service.GetUsersByAssessmentAsync(assessmentId);
            return users.Any() ? Ok(users) : NotFound("No users found for this assessment.");
        }



        [HttpGet("GetPackage/{userId}")]
        [Authorize(Roles = "Admin,Instructor")]
        public async Task<IActionResult> GetPackageFromAssessment(int userId)
        {
            var package = await _service.GetPackages(userId);
            return package.Any() ? Ok(package) : NotFound("No users found for this assessment.");

        }
    }
}


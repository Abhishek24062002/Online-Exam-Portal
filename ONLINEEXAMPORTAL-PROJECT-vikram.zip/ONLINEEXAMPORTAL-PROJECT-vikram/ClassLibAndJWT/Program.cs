using ClassLib.Data;
using ClassLib.IRepository;
using ClassLib.IService;
using ClassLib.Models;
using ClassLib.Repositories;
using ClassLib.Repository;
using ClassLib.Service;
using ClassLib.Services;
//using ClassLib.SignalR_Hub;
//using ExceptionFilter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Abstractions;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.Resource;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.Win32;
using System;
using System.Text;
using System.Text.Json.Serialization;

namespace OnlineExamPortal
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            var link = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>();
            
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAngularApp",
                    policy => policy.WithOrigins(link)
                                    .AllowAnyHeader()
                                    .AllowAnyMethod());
            });

            builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnectionString")));

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddScoped<IUserService, UserService>();
            builder.Services.AddScoped<IUserRepository, UserRepository>();
            builder.Services.AddScoped<IEmailService, EmailService>();
            builder.Services.AddScoped<IAssessmentService, AssessmentService>();

            builder.Services.AddScoped<IAssessmentRepository, AssessmentRepository>();

            builder.Services.AddScoped<IAssessmentPackageRepository, AssessmentPackageRepository>();
            builder.Services.AddScoped<IAssessmentPackageService, AssessmentPackageService>();

            builder.Services.AddScoped<IQuestionRepository, QuestionRepository>();
            builder.Services.AddScoped<IQuestionService, QuestionService>();

            builder.Services.AddScoped<IOptionRepository, OptionRepository>();
            builder.Services.AddScoped<IOptionService, OptionService>();

            builder.Services.AddScoped<IResponseRepository, ResponseRepository>();
            builder.Services.AddScoped<IResponseService, ResponseService>();

            builder.Services.AddScoped<IExamAttemptRepository, ExamAttemptRepository>();
            builder.Services.AddScoped<IExamAttemptService, ExamAttemptService>();


            builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
            builder.Services.AddScoped<IFeedbackService, FeedbackService>();

            builder.Services.AddScoped<IInstructorRequestViewService, InstructorRequestViewService>();
            builder.Services.AddScoped<IInstructorRequestViewRepository, InstructorRequestViewRepository>();







            builder.Services.AddScoped<ICandidateRequestRepository, CandidateRequestRepository>();
            builder.Services.AddScoped<ICandidateRequestService, CandidateRequestService>();

            builder.Services.AddScoped<IAssessmentAssignmentRepository, AssessmentAssignmentRepository>();
            builder.Services.AddScoped<IAssessmentAssignmentService, AssessmentAssignmentService>();

            builder.Services.AddScoped<IReportRepository, ReportRepository>();
            builder.Services.AddScoped<IReportService, ReportService>();


            builder.Services.AddControllers(options =>
            {
                options.Filters.Add<CustomExceptionFilter>();
            });  

            builder.Services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                options.JsonSerializerOptions.WriteIndented = true;
            });
            builder.Services.AddSignalR(); 

            
            var key = builder.Configuration.GetValue<string>("ApiSettings:Secret");
            builder.Services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddJwtBearer(x =>
                {
                    x.RequireHttpsMetadata = false;
                    x.SaveToken = true;
                    x.TokenValidationParameters = new TokenValidationParameters
                    {
                        
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(key)),
                        ValidateIssuer = false,
                        ValidateAudience = false
                    };
                });
            


            builder.Services.AddAuthorization();
            
            builder.Services.AddSwaggerGen(c =>
            {
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme (Example: 'Bearer 12345abcdef')",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "bearer",
                            Name = "Authorization",
                            In = ParameterLocation.Header
                        },
                        new List<string>()
                    }
                });
            });



            var app = builder.Build();

            app.UseCors("AllowAngularApp");

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();


            app.MapControllers();

           


            app.Run();
        }
    }
}

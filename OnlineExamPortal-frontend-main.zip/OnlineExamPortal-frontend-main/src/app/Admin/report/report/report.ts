import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportService, CandidateReport } from '../../../services/report';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report.html',
  styleUrls: ['./report.css']
})
export class Report {
  candidates: CandidateReport[] = [];
  loading: boolean = false;
  errorMessage: string = '';

  constructor(private reportService: ReportService) {}

//   generateAndLoadReport() {
//     this.loading = true;
//     this.errorMessage = '';

//     this.reportService.generateReport().subscribe({
//       next: () => {
//         this.reportService.getCandidateReport().subscribe({
//           next: (data) => {
//             this.candidates = data;
//             this.loading = false;
//           },
//           error: (err) => {
//             this.errorMessage = 'Failed to load candidate report.';
//             console.error(err);
//             this.loading = false;
//           }
//         });
//       },
//       error: (err) => {
//         this.errorMessage = 'Failed to generate report.';
//         console.error(err);
//         this.loading = false;
//       }
//     });
//   }
// }


generateAndLoadReport() {
  this.loading = true;
  this.errorMessage = '';

  const reportPayload = {
    assessmentId: 2, 
    createdBy: 'admin',
    timestamp: new Date().toISOString()
  };

  this.reportService.generateReport(reportPayload).subscribe({
    next: () => {
      this.reportService.getCandidateReport().subscribe({
        next: (data) => {
          this.candidates = data;
          this.loading = false;
        },
        error: (err) => {
          this.errorMessage = 'Failed to load candidate report.';
          console.error(err);
          this.loading = false;
        }
      });
    },
    error: (err) => {
      this.errorMessage = 'Failed to generate report.';
      console.error(err);
      this.loading = false;
    }
  });
}}

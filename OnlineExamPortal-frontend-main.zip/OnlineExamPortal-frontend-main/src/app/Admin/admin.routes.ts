import { Routes } from '@angular/router';
// import { Admin } from './admin/admin/admin';
import { Admin } from './admin/admin';
import { authGuard} from '../shared/auth-guard';

export const adminRoutes: Routes = [
  {
    path: 'admin',
    component: Admin,
    canActivate: [authGuard],
  data: { roles: ['admin'] },
    children: [
      {
        path: 'admin-dashboard',
        loadComponent: () =>
          import('./admin-dashboard/admin-dashboard').then(m => m.AdminDashboard),
      },
      {
        path: 'approve-instructor',
        loadComponent: () =>
          import('./approve-instructor/approve-instructor').then(m => m.ApproveInstructor),
      },
      {
        path: 'manage-users',
        loadComponent: () =>
          import('./manage-users/manage-users').then(m => m.ManageUsers),
      },
      {
        path: 'report',
        loadComponent: () =>
          import('./report/report/report').then(m => m.Report),
      },
      {
        path: '',
        redirectTo: 'admin-dashboard',
        pathMatch: 'full',
      },
    ],
  },
];

import { Component, OnInit, Inject } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
 
import { HttpClient } from '@angular/common/http';    
import { RouterLink,RouterLinkActive, RouterOutlet} from '@angular/router';
// import { ApproveInstructor } from '../approve-instructor/approve-instructor'
import { ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../services/admin';

 import { AdminDashboard } from '../admin-dashboard/admin-dashboard';

 import { Logout } from '../../shared/logout/logout';

 
 
export class SidebarComponent {}
@Component({
  selector: 'app-admin',
  standalone: true,
  templateUrl: './admin.html',
  styleUrls: ['./admin.css'],
  imports: [HttpClientModule, RouterLink, RouterLinkActive, ReactiveFormsModule, RouterOutlet, Logout],
  providers: [AdminService],
})
export class Admin implements OnInit {
  totalUsers: number = 0;
  totalAssessments: number = 0;
 
  constructor(private adminService: AdminService) {}
 
  ngOnInit(): void {
    this.fetchDashboardData();
  }
 
  fetchDashboardData(): void {
    this.adminService.getTotalUsers().subscribe({
      next: (data) => this.totalUsers = data,
      error: (err) => console.error('Error fetching total users:', err),
    });
 
    this.adminService.getTotalAssessments().subscribe({
      next: (data) => this.totalAssessments = data,
      error: (err) => console.error('Error fetching total assessments:', err),
    });
  }
}
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { Auth } from '../services/auth';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})

export class Home implements OnInit{
  constructor(private auth : Auth) {}
  image="./assets/home.jpg";
  ngOnInit(){
    if(this.auth.isLogged()){
      console.log("Auth login : "+ this.auth.getRole());
      const role=this.auth.roleDefiner(this.auth.getRole().toString());
      console.log(role)
      
  
      // this.router.navigateByUrl('/dashboard');
     }
     else{
      console.log("Auth  : "+ this.auth.getRole());
      localStorage.clear();
      sessionStorage.clear();
     }
  }
}


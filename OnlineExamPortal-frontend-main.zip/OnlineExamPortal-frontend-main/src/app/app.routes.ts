
import { Routes } from "@angular/router";
import { authGuard } from "./shared/auth-guard";
import { adminRoutes } from "./Admin/admin.routes";
import { Dashboard } from "./Candidate/dashboard/dashboard/dashboard";
import { Instructor } from "./Instructor/instructor/instructor";
import { InstructorDashboard } from "./Instructor/instructor-dashboard/instructor-dashboard";


export const routes: Routes = [
   ...adminRoutes,
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    //loadComponent: () => import('./home/home').then(m => m.Home),
    loadComponent: () => import('./home/home').then(m => m.Home),

    },
   
    {
      path:'entry-page',
      loadComponent: () => import('./entry-page/entry-page').then(m => m.EntryPage),
      
      children:[
    
  {
    path: 'login',
    loadComponent: () => import('./Login/login/login').then(m => m.Login),
    
  },
  {
    path:'forgot-password',
    loadComponent: () => import('./Login/forgot-password/forgot-password').then(m => m.ForgotPassword)
  },

  {
    path: 'register',
    loadComponent: () => import('./Register/register/register').then(m => m.Register)
  },
  ]
},

{
  path: 'dashboard',
  component: Dashboard,
  canActivate: [authGuard],
  data: { roles: ['candidate'] },
  children: [
   
    {
      path: 'profile',

      loadComponent: () =>
        import('./Candidate/Profile/profile/profile').then(m => m.ProfileComponent),
     

    },
    {
      path: 'assessments',
      loadComponent: () =>
        import('./Candidate/assessment/available-assessment/available-assessment').then(m => m.AvailableAssessment)
    },
  
    {
      path: 'packages',
      loadComponent: () =>
        import('./Candidate/package/package/package').then(m => m.PackagesComponent),
    
    },
    {
      path: 'result',
      loadComponent: () =>
        import('./Candidate/assessment/assessment-result/assessment-result').then(m => m.AssessmentResultComponent)
    },
    {
      path: '',
      redirectTo: '', // or 'condidate' if you want that as default
      pathMatch: 'full'
    }
  ]
},

{
  path: 'assessment/:id',
  loadComponent: () =>
    import('./Candidate/assessment/assessment/assessment').then(m => m.Assessment)
},


  // {
  //   path: 'instructor',
  //   loadComponent: () => import('./Instructor/instructor/instructor').then(m => m.Instructor)
  // },
  // {
  //   path:'instructor-profile',
  //   loadComponent: () => import('./Instructor/profile/profile').then(m => m.Profile)
  // },
  // {
  //   path:'instructor-assessment',
  //   loadComponent: () => import('./Instructor/assessments/assessment-dashboard/assessment-dashboard').then(m => m.Assessment)
  // },
  // {
  //   path: 'create-assessment',
  //   loadComponent: () => import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
  // }
  // ,
  // {
  //   path: 'update-assessment/:id',
  //   loadComponent: () => import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
  // },
  // {
  //   path: 'requests',
  //   loadComponent: () => import('./Instructor/requests/requests').then(m => m.Requests)
  // },
//   {path: 'admin-dashboard',
//     loadComponent: () => import('./Admin/admin-dashboard/admin-dashboard').then(m => m.AdminDashboard)
//   },
//   {path: 'approve-instructor',
//     loadComponent: () => import('./Admin/approve-instructor/approve-instructor').then(m => m.ApproveInstructor)
//   },
//   {
//     path: 'manage-users',
//     loadComponent: () => import('./Admin/manage-users/manage-users').then(m => m.ManageUsers)
//   },
   
  
//   {
//     path: 'report',
//     loadComponent: () => import('./Admin/report/report/report').then(m => m.Report)
//   },
  // { 
  //   path: 'admin',
  //   loadChildren: () => import('./Admin/admin.routes').then(m => m.adminRoutes)
  // },..
//   {
//     path: 'instructor-package',
//     loadComponent: () => import('./Instructor/instructor-package/instructor-package').then(m => m.InstructorPackage)
   
//   }
// ,
{
  path: 'unauthorized',
  loadComponent: () => import('./shared/unauthorized/unauthorized').then(m => m.Unauthorized)
},
  // {
  //   path: 'instructor',
  //   loadComponent: () => import('./Instructor/instructor/instructor').then(m => m.Instructor),
  //   canActivate: [authGuard],
  // data: { roles: ['instructor'] }
  // },
  // {
  //   path:'instructor-profile',
  //   loadComponent: () => import('./Instructor/profile/profile').then(m => m.Profile)
  // },
  // {
  //   path:'instructor-assessment',
  //   loadComponent: () => import('./Instructor/assessments/assessment-dashboard/assessment-dashboard').then(m => m.Assessment)
  // },
  // {
  //   path: 'create-assessment',
  //   loadComponent: () => import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
  // }
  // ,
  // {
  //   path: 'update-assessment/:id',
  //   loadComponent: () => import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
  // },
  // {
  //   path: 'requests',
  //   loadComponent: () => import('./Instructor/requests/requests').then(m => m.Requests)
  // },
  // {
  //   path: 'instructor-dashboard',
  //   loadComponent: () => import('./Instructor/instructor-dashboard/instructor-dashboard').then(m => m.InstructorDashboard)
  // },
  // {
  //   path: 'instructor-package',
  //   loadComponent: () => import('./Instructor/instructor-package/instructor-package').then(m => m.InstructorPackage)

  // },
  // },
  // {
  //   path: 'app-create-assessment-package',
  //   loadComponent: () => import('./Instructor/instructor-package/create-assessment-package-component/create-assessment-package-component').then(m => m.CreateAssessmentPackageComponent)
   
  // },
  // {
  //   path: 'app-create-assessment-package/:id',
  //   loadComponent: () => import('./Instructor/instructor-package/create-assessment-package-component/create-assessment-package-component').then(m => m.CreateAssessmentPackageComponent)



  

 
  {
    path: 'instructor-dashboard',
    component: Instructor,
    canActivate: [authGuard],
  data: { roles: ['instructor'] },
    children: [
   {
    path: 'instructor',
    loadComponent: () => import('./Instructor/instructor-dashboard/instructor-dashboard').then(m => m.InstructorDashboard)
  },
   
      {
        path: 'profile',
        loadComponent: () =>
          import('./Instructor/profile/profile').then(m => m.Profile)
      },
      {
        path: 'assessments',
        loadComponent: () =>
          import('./Instructor/assessments/assessment-dashboard/assessment-dashboard').then(m => m.Assessment)
      },
      {
        path: 'assessments/create-assessment',
        loadComponent: () =>
          import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
      },
  
      {
        path: 'assessments/update-assessment/:id',
        loadComponent: () =>
          import('./Instructor/assessments/create-assessment/create-assessment').then(m => m.CreateAssessment)
      },
      {
        path: 'requests',
        loadComponent: () =>
          import('./Instructor/requests/requests').then(m => m.Requests)
      },
      {
        path: 'packages',
        loadComponent: () =>
          import('./Instructor/instructor-package/instructor-package').then(m => m.InstructorPackage)
      },
      {
        path: 'create-assessment-package',
        loadComponent: () =>
          import('./Instructor/instructor-package/create-assessment-package-component/create-assessment-package-component').then(m => m.CreateAssessmentPackageComponent)
      },
      {
        path: 'create-assessment-package/:id',
        loadComponent: () =>
          import('./Instructor/instructor-package/create-assessment-package-component/create-assessment-package-component').then(m => m.CreateAssessmentPackageComponent)
      },
      {
        path: 'assessments/assessment-questions/:id',
        loadComponent: () =>
          import('./Instructor/assessments/assessment-questions/assessment-questions').then(m => m.AssessmentQuestions)
      },
      
  {
    path: 'instructor-assign-assessment',
    loadComponent: () => import('./Instructor/assign-assessment/assign-assessment').then(m => m.AssignAssessmentComponent)
  }
    
    ]
  },
  {
    path: 'reset-password',
    loadComponent: () => import('./Login/reset-password/reset-password').then(m => m.ResetPassword)
 
  }
  

  
 
];
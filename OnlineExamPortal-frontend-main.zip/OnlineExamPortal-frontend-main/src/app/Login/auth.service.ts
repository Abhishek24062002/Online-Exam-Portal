import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
 
const API_URL = 'https://localhost:7201/api/Login'; // Replace with your actual backend URL
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) {}
 
  forgotPassword(email: string): Observable<any> {
    console.log("forgot password :",email);
    return this.http.post(`${API_URL}/forgot-password`, { email });
  }
 
  resetPassword(token: string, newPassword: string): Observable<any> {
   console.log("reset token :",token);
   
    return this.http.post(`${API_URL}/reset-password`, { token, newPassword });
  }
}
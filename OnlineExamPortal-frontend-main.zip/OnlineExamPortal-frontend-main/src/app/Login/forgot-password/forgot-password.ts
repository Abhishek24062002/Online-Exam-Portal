import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
 
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';

import { RouterModule } from '@angular/router';
import { Auth } from '../../services/auth';


 
@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule,CommonModule,RouterModule],
  templateUrl: './forgot-password.html',
  styleUrls: ['./forgot-password.css']
})
export class ForgotPassword implements OnInit {
  
  ngOnInit(){
      this.backgroundStyle = {
      'background-image': `linear-gradient(135deg, rgba(74, 58, 255, 0.6), rgba(78, 205, 196, 0.6)), url('${this.imagePath}')`,
      'background-size': 'cover',
      'background-position': 'center',
      'background-repeat': 'no-repeat',
      'height': '100vh',
      'display': 'flex',
      'justify-content': 'center',
      'align-items': 'center'
    };
    if(this.auth.isLogged()){
      console.log("Auth login : "+ this.auth.getRole());
      const role=this.auth.roleDefiner(this.auth.getRole().toString());
      console.log(role)
      
  
      // this.router.navigateByUrl('/dashboard');
     }
     else{
      localStorage.clear();
      console.log("Auth  : "+ this.auth.getRole());

     }
  }
  email = '';
  message = '';
  loading = false;
 

imagePath = './assets/register.jpg';
 
  backgroundStyle: { [key: string]: string } = {};
 
  //constructor(private authService: AuthService) {}
 
  // ngOnInit(): void {
  //   this.backgroundStyle = {
  //     'background-image': `linear-gradient(135deg, rgba(74, 58, 255, 0.6), rgba(78, 205, 196, 0.6)), url('${this.imagePath}')`,
  //     'background-size': 'cover',
  //     'background-position': 'center',
  //     'background-repeat': 'no-repeat',
  //     'height': '100vh',
  //     'display': 'flex',
  //     'justify-content': 'center',
  //     'align-items': 'center'
  //   };
  // }
 

 constructor(private authService: AuthService,private auth: Auth) {}
  
  

  submit() {
    this.loading = true;
    this.authService.forgotPassword(this.email).subscribe({
      next: (res) => {
        this.message = res.message;
        this.loading = false;
      },
      error: (err) => {
        this.message = 'Something went wrong.';
        this.loading = false;
      }
    });
  }
}
 
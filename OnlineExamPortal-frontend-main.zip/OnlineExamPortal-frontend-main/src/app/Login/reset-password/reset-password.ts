import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';
import { FormsModule } from '@angular/forms';
 
@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reset-password.html',
  styleUrls: ['./reset-password.css']
})
export class ResetPassword  implements OnInit {
  token = '';
  newPassword = '';
  message = '';
  loading = false;
 
  constructor(private route: ActivatedRoute, private authService: AuthService) {}
 
  ngOnInit(): void {
    this.token = this.route.snapshot.queryParams['token'];
  }
 
  submit() {
    this.loading = true;
    this.authService.resetPassword(this.token, this.newPassword).subscribe({
      next: (res) => {
        this.message = res.message;
        this.loading = false;
      },
      error: (err) => {
        this.message = 'Failed to reset password.';
        this.loading = false;
      }
    });
  }
}
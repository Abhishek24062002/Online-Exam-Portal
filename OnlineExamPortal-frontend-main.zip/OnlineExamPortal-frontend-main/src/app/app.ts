import { Component, signal } from '@angular/core';
import { NavigationStart, Router, RouterOutlet } from '@angular/router';
import { Condidate } from "./Candidate/candidate/candidate";
import { Register } from './Register/register/register';
import { ReactiveFormsModule } from '@angular/forms';
import {  HttpClientModule } from '@angular/common/http';
import { Login } from './Login/login/login';
import { Home } from './home/home';
import { HttpClient } from '@angular/common/http';
import { AssessmentResultComponent } from './Candidate/assessment/assessment-result/assessment-result';
import { AssessmentStateService } from './services/assessment-state-service';

@Component({
  selector: 'app-root',
  standalone: true, // ✅ Add this
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('OnlineExamPortal');
  
  
}
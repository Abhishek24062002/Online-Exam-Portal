import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { OnInit } from '@angular/core';
import { Auth } from '../services/auth';
import { Login } from '../Login/login/login';

@Component({
  selector: 'app-entry-page',
  imports: [RouterModule],
  templateUrl: './entry-page.html',
  styleUrl: './entry-page.css'
})
export class EntryPage implements OnInit{
  image1 = './assets/register.jpg';
  constructor(private auth : Auth){}
  ngOnInit(){
    if(this.auth.isLogged()){
      console.log("Auth login : "+ this.auth.getRole());
      const role=this.auth.roleDefiner(this.auth.getRole().toString());
      console.log(role)
      
  
      // this.router.navigateByUrl('/dashboard');
     }
     else{
      console.log("Auth  : "+ this.auth.getRole());
      localStorage.clear();
     }
  }

}

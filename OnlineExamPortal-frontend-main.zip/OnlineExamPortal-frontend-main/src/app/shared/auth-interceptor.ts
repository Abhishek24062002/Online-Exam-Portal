// import { HttpInterceptorFn } from '@angular/common/http';
// import { inject } from '@angular/core';
//  import { HttpInterceptorFn } from '@angular/common/http';
// import { Auth } from '../services/auth';

// export const authInterceptor: HttpInterceptorFn = (req, next) => {
//   const service =inject(Auth)
  

//   const authReq = req.clone({
//     headers: req.headers.set('Authorization', `Bearer ${service.getToken()}`)
//   });
//   console.log('Auth Header:', req.headers.get('Authorization'));
//   if(service.isLogged()){
//     const authReq = req.clone({
//       headers: req.headers.set('Authorization', service.getToken() )
//     })
//     return next(authReq)
//   }else{
//     return next(req)
//   }
// };

import { inject } from '@angular/core';
import { AuthService } from '../Login/auth.service';
import { HttpInterceptorFn } from '@angular/common/http';
import { Auth } from '../services/auth';


export const authInterceptor: HttpInterceptorFn = (req, next) => {
  
  const authService = inject(Auth);
  const token = authService.getToken();


  if(authService.isLogged()){  const authReq = req.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  });
  console.log('Auth Header:', authReq.headers.get('Authorization'));
  return next(authReq);
}
return next(req);
};


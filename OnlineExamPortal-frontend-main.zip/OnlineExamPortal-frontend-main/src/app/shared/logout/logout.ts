import { Component } from '@angular/core';
import { Auth } from '../../services/auth';
import { Router } from '@angular/router';
 

@Component({
  selector: 'app-logout',
  imports: [],
  templateUrl: './logout.html',
  styleUrl: './logout.css'
})
export class Logout {
  constructor(private auth : Auth,private router: Router) {}
  
  OnLogout(){
    this.auth.logout();

    this.router.navigateByUrl('');
    
  }
}

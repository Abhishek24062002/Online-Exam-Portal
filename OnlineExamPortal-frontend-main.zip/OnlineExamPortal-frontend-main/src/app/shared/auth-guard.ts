import { inject, Inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Auth } from '../services/auth';
// import { AuthService } from '../Register/register.service

export const authGuard: CanActivateFn = (route, state) => {

  const authService = inject(Auth)
  const router = inject(Router);
  if(authService.isLogged() ){
    const userRole = authService.getRole();
    console.log(userRole);
     
    // e.g., 'candidate' or 'instructor'
    const allowedRoles = route.data?.['roles'] as Array<string>;
    if (allowedRoles && !allowedRoles.includes(userRole)) {

     router.navigateByUrl('/unauthorized'); // or redirect to dashboard
      return false;
    }
    return true;
  }else{
    router.navigateByUrl('');
    return false;
  }
  
};

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router ,NavigationEnd} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { EnrolledAssessmentsComponent } from "../../assessment/enrolled-assessments/enrolled-assessments";
import { Auth } from '../../../services/auth';
import { ProfileComponent } from '../../Profile/profile/profile';
import { PackagesComponent } from '../../package/package/package';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AssessmentResultComponent } from '../../assessment/assessment-result/assessment-result';
import { filter } from 'rxjs/operators';
 
import { Logout } from '../../../shared/logout/logout';
import { AvailableAssessment } from "../../assessment/available-assessment/available-assessment";
 
 
 
 
 
@Component({
  selector: 'app-dashboard',
  standalone: true,
 
 
 
 
  imports: [
    CommonModule,
    RouterModule,

    // ProfileComponent,
    EnrolledAssessmentsComponent,
    //PackagesComponent,
    FormsModule,
    Logout,
    HttpClientModule,
    //AvailableAssessment
],
 
 
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
 
 
 
 
export class Dashboard implements OnInit {
  userId: number = 0;
  userName: string = '';
  enrolledPackages: any[] = [];
  assessmentsMap: { [key: number]: number } = {};
  isBaseDashboard = false;
 
  constructor(private auth: Auth, private router: Router, private http: HttpClient) {}
 
  ngOnInit(): void {
    const storedId = localStorage.getItem('userId');
    const storedName = localStorage.getItem('name');

      // ✅ Check current URL immediately
    this.isBaseDashboard = this.router.url === '/dashboard';

    // ✅ Also listen for future navigations
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.isBaseDashboard = event.urlAfterRedirects === '/dashboard';
      });
 
    if (storedId) {
      this.userId = parseInt(storedId, 10);
      this.loadEnrolledPackages();
    }
 
    if (storedName) {
      this.userName = storedName;
    }
       
  }
 
  loadEnrolledPackages(): void {
    this.http.get<any[]>(`https://localhost:7201/api/AssessmentPackage/user/${this.userId}`).subscribe({
      next: (res) => {
        this.enrolledPackages = res;
        this.enrolledPackages.forEach(pkg => {
          this.http.get<any[]>(`https://localhost:7201/api/Assessment/package/${pkg.packageName}`).subscribe({
            next: (assessments) => this.assessmentsMap[pkg.packageId] = assessments.length,
            error: (err) => console.error(`Failed to load assessments for ${pkg.packageName}`, err)
          });
        });
      },
      error: (err) => console.error('Failed to load enrolled packages', err)
    });
  }
 
  OnLogout(): void {
    localStorage.clear();
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
 
}
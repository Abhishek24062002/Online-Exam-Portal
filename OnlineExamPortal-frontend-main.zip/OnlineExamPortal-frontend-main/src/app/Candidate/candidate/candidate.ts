import { Component } from '@angular/core';
import { Dashboard}from '../dashboard/dashboard/dashboard';
@Component({
  selector: 'app-condidate',
  standalone: true,


  imports: [],

  templateUrl: './candidate.html',
  styleUrl: './candidate.css'
})
export class Condidate {

}

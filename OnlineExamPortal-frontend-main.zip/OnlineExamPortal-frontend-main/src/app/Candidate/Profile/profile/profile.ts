


import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, HttpClientModule,CommonModule,FormsModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.css']
})
export class ProfileComponent implements OnInit {
  name: string = '';
  email: string = '';
  userId: number = 0;
  requestedPackageNames: string[] = [];
  completedAssessments: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadUserFromLocalStorage();
   
    this.fetchRequestedPackages();
    this.fetchCompletedAssessmentDetails();
  }

  loadUserFromLocalStorage(): void {
    this.name = localStorage.getItem('name') || '';
    this.email = localStorage.getItem('userEmail') || '';
    this.userId = Number(localStorage.getItem('userId')) || 0;
  }



  fetchRequestedPackages(): void {
    this.http.get<any[]>(`https://localhost:7201/api/CandidateRequest/by-user/${this.userId}`)
      .subscribe({
        next: requests => {
          const requestedPackageIds = requests.map(req => req.packageId);
          this.loadPackageNames(requestedPackageIds);
        },
        error: err => console.error('Error fetching user requests:', err)
      });
  }

  loadPackageNames(packageIds: number[]): void {
    this.http.get<any[]>(`https://localhost:7201/api/AssessmentPackage`)
      .subscribe({
        next: packages => {
          this.requestedPackageNames = packages
            .filter(pkg => packageIds.includes(pkg.packageId))
            .map(pkg => pkg.packageName);
        },
        error: err => console.error('Error fetching package list:', err)
      });
  }

  fetchCompletedAssessmentDetails(): void {
    this.http.get<any[]>(`https://localhost:7201/api/ExamAttempt/ExamAttempted`)
      .subscribe(attempts => {
        attempts.forEach(attempt => {
          this.http.get<any[]>(`https://localhost:7201/api/Assessment/${attempt.assessmentId}`)
            .subscribe(assessmentList => {
              const assessment = assessmentList[0];
              attempt.assessmentTitle = assessment?.title || 'Untitled';
              this.completedAssessments.push(attempt);
            });
        });
      });
  }
}

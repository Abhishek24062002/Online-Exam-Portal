import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-feedback',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feedback.html',
  styleUrls: ['./feedback.css']
})
export class Feedback implements OnInit {
  @Input() userId!: number;
  @Input() assessmentId!: number;
  @Input() assignmentId!: number;
  @Output() feedbackCompleted = new EventEmitter<void>();

  submissionCount = 0;
  feedbackSubmitted = false;
  message: string = '';

  feedback: { rating: number; comments: string } = {
    rating: 0,
    comments: ''
  };

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    console.log('Feedback component initialized with:', this.userId, this.assessmentId, this.assignmentId);
  }

  setRating(star: number): void {
    this.feedback.rating = star;
  }

  submitFeedback(): void {
    this.submissionCount++;

    if (this.feedbackSubmitted) {
      this.message = '✅ We’ve already recorded your feedback for this assessment.';
      return;
    }

    const payload = {
      userId: this.userId,
      assessmentId: this.assessmentId,
      assignmentId: this.assignmentId,
      rating: this.feedback.rating,
      comments: this.feedback.comments
    };

    this.http.post('https://localhost:7201/api/Feedback/create', payload).subscribe({
      next: () => {
        this.feedbackSubmitted = true;
        this.message = '🎉 Thank you for your feedback!';
        this.feedbackCompleted.emit();
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.message = 'You have already submitted the feedback.';
        console.error(err);

        setTimeout(() => {
    this.router.navigate(['/dashboard']);
  }, 2000);
      }
    });
  }
}

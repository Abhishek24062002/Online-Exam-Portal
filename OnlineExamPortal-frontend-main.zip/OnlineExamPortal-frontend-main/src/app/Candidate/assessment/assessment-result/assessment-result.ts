

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ExamAttemptService } from '../../../services/exam-attempt.service';
import { AssessmentService } from '../../../services/assessment.service';
import { Feedback } from '../feedback/feedback';

@Component({
  selector: 'app-assessment-result',
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule, Feedback],
  templateUrl: './assessment-result.html',
  styleUrls: ['./assessment-result.css']
})
export class AssessmentResultComponent implements OnInit {
  userId!: number;
  assessmentId!: number;
  assignmentTitle: string = '';
  results: any[] = [];
  showResults: boolean = false;
  loading: boolean = false;
  assignmentId!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private examAttemptService: ExamAttemptService,
    private assessmentService: AssessmentService
  ) {}

  ngOnInit(): void {
    this.userId = Number(this.route.snapshot.queryParamMap.get('userId')) || 0;
    this.assessmentId = Number(this.route.snapshot.queryParamMap.get('assessmentId')) || 0;
  
    if (!this.userId || !this.assessmentId) {
      console.warn('Missing query params');
      return;
    }
  
    this.loading = true;
  
    //  Get assessment results
    this.examAttemptService.getAllAttempts().subscribe({
      next: (res) => {
        this.results = res.filter(r =>
          String(r.userId) === String(this.userId) &&
          String(r.assessmentId) === String(this.assessmentId)
        );
        this.showResults = true;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to fetch results', err);
        this.loading = false;
      }
    });
  
    //  Fetch assessment title
    this.assessmentService.getassessmentById(this.assessmentId).subscribe({
      next: (data: any[]) => {
        const assignment = data.find(item => item?.assessmentId === this.assessmentId);
        this.assignmentTitle = assignment?.title || 'Untitled';
      },
      error: (err) => {
        console.error('Failed to fetch assignment title', err);
      }
    });
  
    //  Match assessmentId to get correct assignmentId
    this.assessmentService.getAssignedAssessments(this.userId).subscribe({
      next: (assigned: any[]) => {
        const match = assigned.find(a => a.assessmentId === this.assessmentId);
        this.assignmentId = match?.assignmentId || 0;
  
        if (!match) {
          console.warn(`No matching assignment found for assessmentId: ${this.assessmentId}`);
        }
      },
      error: (err) => {
        console.error('Failed to fetch assigned assessments', err);
      }
    });
  }
  goToDashboard(): void {
    this.router.navigate(['/dashboard']); 
  }
  
//   feedbackSubmitted: boolean = false;

// onFeedbackSubmitted(): void {
//   this.feedbackSubmitted = true;
// }

}


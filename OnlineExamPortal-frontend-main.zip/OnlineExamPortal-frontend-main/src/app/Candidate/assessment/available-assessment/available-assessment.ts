import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AssessmentService } from '../../../services/assessment.service';
import { forkJoin } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-availableassessment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './available-assessment.html',
  styleUrls: ['./available-assessment.css']
})
export class AvailableAssessment implements OnInit {

  userId: any = localStorage.getItem('userId') ?? 0;
  details: any[] = [];       
  assessments: any[] = [];    
  completion: any[] = [];    
  image1 = './assets/Man.png'; 

  constructor(private http: HttpClient, private service: AssessmentService) {}

  ngOnInit(): void {
    this.loadAvailableAssessments();
  }

  loadAvailableAssessments(): void {
    forkJoin({
      enrolled: this.service.getAssignmentDetails(this.userId),
      all: this.service.getallassessments()
    }).subscribe({
      next: ({ enrolled, all }) => {
        this.details = enrolled;
  
        const enrolledIds = enrolled.map((e: any) => e.assessmentId);
  
     
        this.assessments = all.filter((a: any) =>
          !enrolledIds.includes(a.assessmentId) &&
          a.packageId === null
        );
        
      },
      error: (err) => console.error('Failed to load assessments', err)
    });
  }
  

  enrollAssessment(assessmentId: number): void {
    this.service.enrollUserToAssessment(this.userId, assessmentId).subscribe({
      next: () => {
        alert('Enrollment successful!');
        this.loadAvailableAssessments(); 
        this.loadCompletionStatus();    
      },
      error: (err) => {
        console.error('Enrollment failed', err);
        alert('Could not enroll. Try again.');
      }
    });
  }

  loadCompletionStatus(): void {
    this.service.getAssignmentDetails(this.userId).subscribe({
      next: (res) => {
        console.log('Completion status:', res);
        this.completion = res;
      },
      error: (err) => console.error('Completion status load failed', err)
    });
  }

  getCompletionStatus(assessmentId: any): boolean {
    return this.completion.some(c => c.assessmentId === assessmentId && c.completed);
  }

  takeAssessment(assessmentId: any): void {
    console.log('Taking assessment:', assessmentId);
   
  }

  viewResult(assessmentId: any): void {
    console.log('Viewing result for:', assessmentId);
   
  }
}

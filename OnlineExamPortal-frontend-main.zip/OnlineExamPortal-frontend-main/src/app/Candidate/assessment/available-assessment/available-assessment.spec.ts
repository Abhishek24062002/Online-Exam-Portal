import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailableAssessment } from './available-assessment';

describe('AvailableAssessment', () => {
  let component: AvailableAssessment;
  let fixture: ComponentFixture<AvailableAssessment>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AvailableAssessment]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AvailableAssessment);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

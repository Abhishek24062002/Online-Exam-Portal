import { Component } from '@angular/core';

@Component({
  selector: 'app-upcomig-assessment',
  imports: [],
  templateUrl: './upcomig-assessment.html',
  styleUrl: './upcomig-assessment.css'
})
export class UpcomigAssessment {

}

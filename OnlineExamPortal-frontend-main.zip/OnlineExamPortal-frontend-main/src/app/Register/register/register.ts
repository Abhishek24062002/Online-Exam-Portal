


import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Auth } from '../../services/auth';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, HttpClientModule,RouterModule,CommonModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register implements OnInit{
  public getJsonValue: any;

 
image1 = './assets/register.jpg';
  imageSectionStyle: { [key: string]: string } = {};

  constructor(private http: HttpClient,private auth : Auth , private route : Router) {}

  // Form-bound properties
  name: string = '';
  email: string = '';
  password: string = '';
  roleType: string = '0'; // default to Candidate

 

 
 


  

   
    ngOnInit(){
  
  this.imageSectionStyle = {
      'background-image': `url('${this.image1}')`,
      'background-size': 'cover',
      'background-position': 'center',
      'background-repeat': 'no-repeat'
    };
      if(this.auth.isLogged()){
        console.log("Auth login : "+ this.auth.getRole());
        const role=this.auth.roleDefiner(this.auth.getRole().toString());
        console.log(role)
        
    
        // this.router.navigateByUrl('/dashboard');
       }
       else{
        console.log("Auth  : "+ this.auth.getRole());
        localStorage.clear();
        sessionStorage.clear();
       }
    }

  // public getMethod(): void {
  //   this.http.get('https://localhost:7201/api/Assessment/AllAssessments').subscribe({
  //     next: (data) => {
  //       console.log('GET response:', data);
  //       this.getJsonValue = data;
  //     },
  //     error: (err) => {
  //       console.error('GET failed:', err);
  //     }
  //   });
  // }
  public postMethod(): void {
    const formData = new FormData();
    formData.append('name', this.name);
    formData.append('email', this.email);
    formData.append('password', this.password);
    formData.append('registrationDate', new Date().toISOString());
    formData.append('roleType', this.roleType);
 
    this.http.post('https://localhost:7201/api/User/register', formData).subscribe({
      next: (data) => {
        console.log('POST response:', data);
        alert('User registered successfully!');
        this.route.navigateByUrl('/entry-page/login');
      },
      error: (err) => {
        console.error('POST failed:', err);
        alert('Registration failed. Please check your input.');
      }
    });
  }
}
 
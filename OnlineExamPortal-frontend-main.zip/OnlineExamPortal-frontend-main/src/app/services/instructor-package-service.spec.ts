import { TestBed } from '@angular/core/testing';

import { InstructorPackage } from './instructor-package';

describe('InstructorPackage', () => {
  let service: InstructorPackage;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstructorPackage);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
 import { Router } from '@angular/router';
import { inject } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class Auth {
  
  constructor(private router: Router) { }

  
  isLogged(){
    return sessionStorage.getItem('token') != null? true : false;
  }
  logout(){
    // localStorage.removeItem('userRole');
    // localStorage.removeItem('userEmail');
    // localStorage.removeItem('userId');
    // localStorage.removeItem('name');
    sessionStorage.removeItem('token');
     localStorage.clear();
  }
  roleDefiner(role: string) {
    role=role.toLowerCase();
    switch (role) {
      case 'candidate':
          this.router.navigateByUrl('/dashboard');
        break;
      case 'instructor':
          this.router.navigateByUrl('/instructor-dashboard/instructor');
        break;
      case 'admin':
          this.router.navigateByUrl('/admin');
        break;
      default:
          this.router.navigateByUrl('/home');
        break;
    }
  }
  getToken(){
    return sessionStorage.getItem('token') || '';
  }
  getRole(){
    return localStorage.getItem('userRole')?.toLocaleLowerCase() || '';
  }
  getUserId(){
    return localStorage.getItem('userId') || '';
  }


}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface CandidateReport {
  userName: string;
  email: string;
  assessmentTitle: string;
  totalMarkObtained: number;
}

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private generateUrl = 'https://localhost:7201/api/Report/generate';
  private getAllUrl = 'https://localhost:7201/api/Report/all';

  constructor(private http: HttpClient) {}

 
// generateReport(report: any): Observable<any> {
//   return this.http.post(this.generateUrl, report);
// }

  
generateReport(report: any): Observable<string> {
  return this.http.post(this.generateUrl, report, { responseType: 'text' });
}

  getCandidateReport(): Observable<CandidateReport[]> {
    return this.http.get<CandidateReport[]>(this.getAllUrl);
  }
}

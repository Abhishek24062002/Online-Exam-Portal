import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment.development';

export interface Assessment {
  id?: number;
  title: string;
  description: string;
  scheduledDate: string;
  duration: number;
  maxMark: number;
  passMark: number;
  status: string;
  endTime: string;
  assessmentType: number;
  createdByUserId?: string;
}

export interface AssessmentPackagePayload {
  id?: number;
  packageName: string;
  assessments: Assessment[];
}

@Injectable({
  providedIn: 'root'
})
export class InstructorPackageService {
   
  constructor( private http: HttpClient) { }
 

  //https://localhost:7201/api/AssessmentPackage https://localhost:7201/api/Assessment/GetPackage/15

  getAllpackages(id :number):Observable<any[]>{
    return this.http.get<any[]>(`${environment.apiUrl}/Assessment/GetPackage/${id}`).pipe(
   
      //return this.http.get<any[]>(`https://localhost:7201/api/AssessmentPackage`).pipe(

      catchError((error) => {
        console.error('Error fetching packages:', error);
        return throwError(() => new Error('Failed to load packages.'));
      })
    );
  }

  // enrollPackage(id: number): Observable<any> {
  //   // As requested, this is a POST request. The endpoint is a guess based on REST conventions.
  //   // It likely enrolls the currently authenticated instructor.
  //   return this.http.post(`${environment.apiUrl}/AssessmentPackage/${id}/enroll`, {}).pipe(
  //     catchError((error) => {
  //       console.error(`Error enrolling in package ${id}:`, error);
  //       return throwError(() => new Error('Failed to enroll in package.'));
  //     })
  //   );
  // }

  // getPackageById(id: number): Observable<AssessmentPackagePayload> {
  //   return this.http.get<AssessmentPackagePayload>(`${environment.apiUrl}/AssessmentPackage/${id}`).pipe(
  //     catchError((error) => {
  //       console.error(`Error fetching package with ID ${id}:`, error);
  //       return throwError(() => new Error('Failed to load package.'));
  //     })
  //   );
  // }
  getPackageById(id: number): Observable<any> {
    return this.http.get(`https://localhost:7201/api/AssessmentPackage/${id}`);
  }
  createPackage(payload: Partial<AssessmentPackagePayload>): Observable<any> {
    if(payload.assessments !=null && payload.assessments.length >0){
       
    return this.http.post<any>(`${environment.apiUrl}/AssessmentPackage`, payload).pipe(
      catchError((error) => {
        console.error('Error creating package:', error);
        return throwError(() => new Error('Failed to create package.'));
      })
    );}
    else{
      alert("cannot create a package without assesments")
      return  throwError(() => new Error('Failed to create package.'));
    }
  }

  // updatePackage(id: number, payload: AssessmentPackagePayload): Observable<any> {
  //   return this.http.put<any>(`${environment.apiUrl}/AssessmentPackage/${id}`, payload).pipe(
  //     catchError((error) => {
  //       console.error(`Error updating package with ID ${id}:`, error);
  //       return throwError(() => new Error('Failed to update package.'));
  //     })
  //   );
  // }
  
  updatePackage(id: number, payload: AssessmentPackagePayload): Observable<any> {
    console.log(`payload : ${JSON.stringify(payload)}`);
    console.log(`id : ${id}`);
    console.log(`payload`);
   
    return this.http.put(`https://localhost:7201/api/AssessmentPackage/${id.toString()}`, payload);
  }

 
  deletePackage(id :number){
    return this.http.delete(`${environment.apiUrl}/AssessmentPackage/${id}`).pipe(catchError((error) => {
      console.error('Error deleting package:', error);
      return throwError(() => new Error('Failed to create package.'));
    }));
  }
}

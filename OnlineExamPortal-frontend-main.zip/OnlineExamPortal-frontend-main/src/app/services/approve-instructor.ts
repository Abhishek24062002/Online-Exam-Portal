import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class ApproveInstructorService {
  
private getUrl = 'https://localhost:7201/api/InstructorApproval/Approval';
private actionUrl = 'https://localhost:7201/api/InstructorApproval/approve';

 
  constructor(private http: HttpClient) {}
 
  // Fetch instructor requests
 

  getInstructorRequests(): Observable<any[]> {
    return this.http.get<any[]>(this.getUrl);
  }

  

 
 
  // Approve instructor
  
approveInstructor(userId: string): Observable<any> {
  return this.http.post(`${this.actionUrl}/${userId}?status=2`, null);
}

 
  // Reject instructor
 

  rejectInstructor(userId: string): Observable<any> {
    return this.http.post(`${this.actionUrl}/${userId}?status=3`, null);
  }}
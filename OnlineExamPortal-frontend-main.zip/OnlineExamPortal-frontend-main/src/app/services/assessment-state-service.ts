// assessment-state.service.ts

 import { Router } from '@angular/router';
import { inject } from '@angular/core';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AssessmentStateService {
  private currentAssessmentId: string | null = null;
  private inProgress = false;

  startAssessment(id: string): void {
    this.currentAssessmentId = id;
    this.inProgress = true;
    console.log('Assessment started with ID:', id);
    console.log('progress status    :',this.inProgress);
    function goFullscreen() {
      const elem = document.documentElement;
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      }
    }
    goFullscreen();
   // return true;
  }

  endAssessment(): void {
    this.currentAssessmentId = null;
    this.inProgress = false;
    console.log('Assessment ended');
    function completedAssessment() {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch((err) => {
          console.error("Error exiting fullscreen:", err);
        });
      }
    
      // Your other cleanup logic
     
    }
    completedAssessment();
  }

  isAssessmentInProgress(): boolean {
    console.log('isAssessmentInProgress !!!',this.inProgress);
    
    return this.inProgress;
  }

  getCurrentAssessmentUrl(): string {
    console.log('getCurrentAssessmentUrl called');
    
    return `/assessment/${this.currentAssessmentId}`;
  }
}
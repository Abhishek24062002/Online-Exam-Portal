import { TestBed } from '@angular/core/testing';

import { InstructorDashboard } from './instructor-dashboard';

describe('InstructorDashboard', () => {
  let service: InstructorDashboard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InstructorDashboard);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

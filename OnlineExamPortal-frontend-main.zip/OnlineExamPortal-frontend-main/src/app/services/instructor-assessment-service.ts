import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { map } from 'rxjs/operators';
 
@Injectable({
  providedIn: 'root'
})
export class InstructorAssessmentService {
  private baseUrl = 'https://localhost:7201/api/Assessment';
 
  constructor(private http: HttpClient) {}
 
  // ✅ Get all assessments
  getAllAssessments(id:any): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/creator/${id}`).pipe(
      catchError((error) => {
        console.error('Error fetching assessments:', error);
        return throwError(() => new Error('Failed to load assessments.'));
      })
    );
  }
 
  // ✅ Create new assessment
  addAssessment(assessment: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/CreateAssesment`, assessment).pipe(
      catchError((error) => {
        console.error('Error creating assessment:', error);
        return throwError(() => new Error('Failed to create assessment.'));
      })
    );
  }
 
  // ✅ Get assessment by ID
  getAssessmentById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`).pipe(
      catchError((error) => {
        console.error(`Error fetching assessment with ID ${id}:`, error);
        return throwError(() => new Error('Failed to load assessment.'));
      })
    );
  }
 
  // ✅ Update assessment by ID
  updateAssessment(id: number, assessment: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/UpdateAssessment/${id}`, assessment).pipe(
      catchError((error) => {
        if(error.status === 200){
            alert('Assessment updated successfully.');
            
        }
        //console.error(`Error updating assessment with ID ${id}:`, error);
        return throwError(() => new Error('updated succesfully'));
      })
    );
  }
 
  getTotalUsers(): Observable<number> {
     return this.http.get<any[]>('https://localhost:7201/api/User/AllUserDetails')
       .pipe(
         map(users => users.length)
       );
   }
 
createQuestion(question: any) {
  return this.http.post<any>(`https://localhost:7201/api/Question`, question).pipe(
    catchError((error) => {
      console.error('Error creating assessment:', error);
      return throwError(() => new Error('Failed to create assessment.'));
    })
  );
}
 
 
updateQuestion(id: number, payload: any) {
  return this.http.put(`https://localhost:7201/api/Question/${id}`, payload);
}
 
 
getAssessmentQuestions(id: number) {
  return this.http.get<any[]>(`https://localhost:7201/api/Assessment/${id}/questions`);
}
 
deleteQuestion(id: number) {
  return this.http.delete(`https://localhost:7201/api/Question/${id}`);
}
 
deleteAssessment(id: number) {
  return this.http.delete(`https://localhost:7201/api/Assessment/DeleteAssesment${id}`);
}
 
 
  // updateQuestion(assessmentId: number, questionId: number, question: any) {
  //   return this.http.put<any>(`https://localhost:7201/api/Question`, question);
  // }
}
 
 
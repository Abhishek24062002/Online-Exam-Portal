import { TestBed } from '@angular/core/testing';

import { AssessmentStateService } from './assessment-state-service';

describe('AssessmentStateService', () => {
  let service: AssessmentStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssessmentStateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

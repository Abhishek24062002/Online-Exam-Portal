import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
 
export interface User {
 
  name: string;
  email: string;
}
 
@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'https://localhost:7201/api/User';
 
  constructor(private http: HttpClient) {}
 
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>('https://localhost:7201/api/User/AllUserDetails');
  }
 
 
deleteUser(email: string) {
  //return this.http.delete<void>(`https://localhost:7201/api/User/deleteUser`);
  const options = {
    body: new HttpParams().set('email', email),
    headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
  };
const url =`https://localhost:7201/api/User/deleteUser`;
  this.http.delete(url, options);

  return this.http.delete(url, options);
}
 
}
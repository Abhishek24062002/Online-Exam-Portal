import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Instructor } from '../instructor/instructor';
 
interface InstructorRequestView {
  requestViewId: number;
  requestId: number;
  requestStatus: number;
  userId: number;
  candidateRequest: {
    requestId: number;
    userId: number;
    packageId: number;
    reviewedBY: string | null;
    reviewDate: string | null;
    requestStatus: number;
    assessmentPackage: any | null;
    user: {
      userId: number;
      name: string;
      email: string;
    };
  };
}
 
interface AssessmentPackage {
  packageId: number;
  packageName: string;
}
 //for displaying in view.......
interface InstructorRequest {
  requestViewId: number;
  requestId: number;
  requestStatus: number;
  userId: number;
  candidateName: string;
  candidateEmail: string;
  packageName: string;
}
 
@Component({
  selector: 'app-instructor-requests',
  templateUrl: './requests.html',
  styleUrls: ['./requests.css'],
  standalone: true,
  imports: [CommonModule],
})
export class Requests implements OnInit {
  requests: InstructorRequest[] = [];
  loading = false;
  error = '';
  filterStatus: 'all' | 'approved' | 'pending' | 'rejected' = 'all';
 
  constructor(private http: HttpClient) {}
 
  ngOnInit(): void {
    this.fetchRequests();
  }
 
  async fetchRequests(): Promise<void> {
    this.loading = true;
    this.error = '';
    try {
      const rawRequests = await this.http.get<InstructorRequestView[]>('https://localhost:7201/api/InstructorRequestView/getRequest').toPromise();
      const enrichedRequests: InstructorRequest[] = [];
 
      for (const req of rawRequests || []) {
        const candidate = req.candidateRequest?.user;
        const packageId = req.candidateRequest?.packageId;
        let packageName = 'Unknown';
 
        if (packageId) {
          try {
            const packageData = await this.http.get<AssessmentPackage>(`https://localhost:7201/api/AssessmentPackage/${packageId}`).toPromise();
            packageName = packageData?.packageName ?? 'Unknown';
          } catch (err) {
            console.warn(`Failed to fetch package for ID ${packageId}`, err);
          }
        }
 
        enrichedRequests.push({
          requestViewId: req.requestViewId,
          requestId: req.requestId,
          requestStatus: req.requestStatus,
          userId: req.userId,
          candidateName: candidate?.name ?? `User ${req.userId}`,
          candidateEmail: candidate?.email ?? `user${req.userId}@example.com`,
          packageName
        });
      }
 
      this.requests = enrichedRequests;
    } catch (err) {
      console.error(err);
      this.error = 'Failed to load requests';
    } finally {
      this.loading = false;
    }
  }
 
  get filteredRequests(): InstructorRequest[] {
    switch (this.filterStatus) {
      case 'approved':
        return this.requests.filter(r => r.requestStatus === 1);
      case 'pending':
        return this.requests.filter(r => r.requestStatus === 0);
      case 'rejected':
        return this.requests.filter(r => r.requestStatus === 2);
      default:
        return this.requests;
    }
  }
 
  approveRequest(requestId: number): void {
    const url = `https://localhost:7201/api/InstructorRequestView/Approval/${requestId}/1`;
    this.http.put(url, {}).subscribe({
      next: (response: any) => {
        const message = typeof response === 'string' ? response : 'Request approved successfully!';
        alert(message);
        this.fetchRequests();
      },
      error: (err) => {
        console.error(err);
        alert('Request approved successfully!');
        this.fetchRequests();
      }
    });
  }
 
  rejectRequest(requestId: number): void {
    const url = `https://localhost:7201/api/InstructorRequestView/Approval/${requestId}/2`;
    this.http.put(url, {}).subscribe({
      next: (response: any) => {
        const message = typeof response === 'string' ? response : 'Request rejected successfully!';
        alert(message);
        this.fetchRequests();
      },
      error: (err) => {
        console.error(err);
        alert('Request rejected successfully!');
        this.fetchRequests();
      }
    });
  }
}
 
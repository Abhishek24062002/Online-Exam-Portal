import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstructorPackage } from './instructor-package';

describe('InstructorPackage', () => {
  let component: InstructorPackage;
  let fixture: ComponentFixture<InstructorPackage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InstructorPackage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InstructorPackage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { InstructorPackageService, AssessmentPackagePayload } from '../../../services/instructor-package-service';
// import { Auth } from '../../../services/auth.service';
import { Auth } from '../../../services/auth';






@Component({
  selector: 'app-create-assessment-package',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  
  templateUrl: './create-assessment-package-component.html',
   styleUrl: './create-assessment-package-component.css'
})
export class CreateAssessmentPackageComponent implements OnInit {
  packageForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private packageService: InstructorPackageService,
    private router: Router,
    private authService: Auth,
    private route: ActivatedRoute
  ) {
    this.packageForm = this.fb.group({
      packageName: ['', Validators.required],
      assessments: this.fb.array([])
    });
  }
   isInEdit : boolean = false;
  ngOnInit(): void {
    const routeId = this.route.snapshot.paramMap.get('id'); // from URL
    const navState = this.router.getCurrentNavigation()?.extras.state;
   // const packageId = navState?.['packageId'];
    const packageId = navState?.['packageId'] || routeId;
     this.isInEdit = navState?.['isInEdit'];
    console.log("package id : "+packageId);
    

    if (packageId) {
        console.log("package id : "+packageId);
        this.isInEdit = true;
        console.log("package isInedit : "+this.isInEdit);
      this.loadPackage(packageId);
    }

    
    this.addAssessment();
  }

  get assessments(): FormArray {
    return this.packageForm.get('assessments') as FormArray;
  }

  newAssessment(): FormGroup {
    
    
    return this.fb.group({
      title: ['', Validators.required],
      description: [''],
      assessmentType: [0, Validators.required], // Default to Quiz
      status: ['Scheduled', Validators.required],
      scheduledDate: ['', Validators.required],
      endTime: ['', Validators.required],
      duration: [60, [Validators.required, Validators.min(1)]],
      maxMark: [100, [Validators.required, Validators.min(1)]],
      passMark: [40, [Validators.required, Validators.min(1)]],
      createdByUserId: [this.authService.getUserId()]
      

      
    });
  }
  

  addAssessment(): void {
    this.assessments.push(this.newAssessment());
  }

  removeAssessment(index: number): void {
    this.assessments.removeAt(index);
  }
  backMenu(){
    this.router.navigate(['/instructor-dashboard/packages']);
  }
//   onSubmit(): void {
//     if (this.packageForm.invalid) {
//       alert('Please fill all required fields correctly.');
//       this.packageForm.markAllAsTouched(); // To show validation errors
//       return;
//     }

//     const payload: AssessmentPackagePayload = this.packageForm.value;
    
//     console.log(payload);

//     this.packageService.createPackage(payload).subscribe({
//       next: (response) => {
//         console.log('Package created successfully', response);
//         alert('Package created successfully!');
//         this.router.navigate(['/instructor-package']); // Navigate to the package list
//       },
//       error: (err) => {
//         console.error('Failed to create package', err);
//         alert('Failed to create package. Please try again.');
//       }
//     });
//   }

packageId: number | null = null;

  
onSubmit(): void {
    if (this.packageForm.invalid) {
      alert('Please fill all required fields correctly.');
      this.packageForm.markAllAsTouched();
      return;
    }
  
    const payload: AssessmentPackagePayload = this.packageForm.value;
  
    if (this.packageId && this.isInEdit) {
      
      this.packageService.updatePackage(this.packageId, payload).subscribe({
        next: (response) => {
          alert('Package updated successfully!');
          this.router.navigate(['/instructor-dashboard/packages']);
        },
        error: (err) => {
          console.error('Failed to update package', err);
          alert('Update failed. Please try again.');
        }
      });
    } else {
      
      
      this.packageService.createPackage(payload).subscribe({
        next: (response) => {
          alert('Package created successfully!');
          this.router.navigate(['/instructor-dashboard/packages']);
        },
        error: (err) => {
          console.error('Failed to create package', err);
          alert('Creation failed. Please try again.');
        }
      });
    
    }
  }
  
  loadPackage(id: number): void {
    this.packageId = id;
  
    this.packageService.getPackageById(id).subscribe({
      next: (data) => {
        this.packageForm.patchValue({
          packageName: data.packageName
        });
  
        this.assessments.clear();
  
        if (Array.isArray(data.assessments)) {
          data.assessments.forEach((assessment: any) => {
            this.assessments.push(this.fb.group({
              title: [assessment.title, Validators.required],
              description: [assessment.description],
              assessmentType: [assessment.assessmentType, Validators.required],
              status: [assessment.status, Validators.required],
              scheduledDate: [assessment.scheduledDate, Validators.required],
              endTime: [assessment.endTime, Validators.required],
              duration: [assessment.duration, [Validators.required, Validators.min(1)]],
              maxMark: [assessment.maxMark, [Validators.required, Validators.min(1)]],
              passMark: [assessment.passMark, [Validators.required, Validators.min(1)]],
              createdByUserId: [assessment.createdByUserId]
            }));
          });
        } else {
          console.warn('No assessments found in package data');
        }
      },
      error: (err) => {
        console.error('Failed to load package', err);
        alert('Could not load package data.');
      }
    });
  }
  
  
}


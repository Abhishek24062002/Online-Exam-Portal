import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAssessmentPackageComponent } from './create-assessment-package-component';

describe('CreateAssessmentPackageComponent', () => {
  let component: CreateAssessmentPackageComponent;
  let fixture: ComponentFixture<CreateAssessmentPackageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateAssessmentPackageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateAssessmentPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

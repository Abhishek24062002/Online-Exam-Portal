import { AfterContentInit, Component, Input, OnInit } from '@angular/core';
import { InstructorPackageService } from '../../services/instructor-package-service';
import { CommonModule } from '@angular/common';
import {  RouterModule, Router, NavigationExtras } from '@angular/router';
import { CreateAssessmentPackageComponent } from './create-assessment-package-component/create-assessment-package-component';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-instructor-package',
  standalone: true,
   imports: [CommonModule, RouterModule],
  templateUrl: './instructor-package.html',
  styleUrls: ['./instructor-package.css']
})
export class InstructorPackage implements OnInit{
   AssessmentTypeLabels: { [key: number]: string } = {
    0: 'Quiz',
    1: 'Assignment',
    2: 'Interview'
  };
    constructor(private service : InstructorPackageService , private router: Router, private auth : Auth){}
  packages : any[]=[];
  pId : number = 0;
  ngOnInit(): void {
    
   this.loadPage();
  }
  loadPage(){
    this.pId=Number(this.auth.getUserId())
    this.service.getAllpackages(this.pId).subscribe({
      next: (res) =>{ 
        console.log('Packages:', res);
        this.packages = res;
        console.log('Packages:', JSON.stringify(res, null, 2));
      },
      error: (err) => {console.error('Failed to load packages', err);
        alert('you haven\t created any package yet' );
      }
    });
  }
  
createPackage() {
  this.router.navigate(['/instructor-dashboard/create-assessment-package']);
}

editPackage(id : number){
  this.router.navigate(['/instructor-dashboard/create-assessment-package/',id],{
    state: { packageId: id,isInEdit : true }
  });
}


deletePackage(ids :number) {
  if (confirm('Are you sure you want to delete this package?')) {
    this.service.deletePackage(ids).subscribe({
      next: () => {
        alert('Package deleted successfully!');
        this.loadPage();
       // this.router.navigate(['/instructor-package']);
       
      },
      error: (err) => {
        
  

        console.error('Failed to delete package', err);
        alert('Failed to delete package. Please try again.');
      }
    });
  }
}

    
}

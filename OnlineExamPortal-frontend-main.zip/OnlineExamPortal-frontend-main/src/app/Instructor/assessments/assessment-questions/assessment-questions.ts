
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { InstructorAssessmentService } from '../../../services/instructor-assessment-service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';

declare var bootstrap: any;

@Component({
  selector: 'app-assessment-questions',
  templateUrl: './assessment-questions.html',
  styleUrls: ['./assessment-questions.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,RouterModule],

})
export class AssessmentQuestions implements OnInit {
  assessmentId!: number;

  questions: {
    questionId: number;
    questionText: string;
    questionType: string;
    mark: number;
    options: {
      optionId: number;
      optionsText: string;
      answer: string;
    }[];
  }[] = [];

  questionForm!: FormGroup;
  isSubmitting = false;

  constructor(
    private route: ActivatedRoute,
    private service: InstructorAssessmentService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.assessmentId = +this.route.snapshot.paramMap.get('id')!;
    this.loadQuestions();
    this.initForm();
  }

  loadQuestions(): void {
    this.service.getAssessmentQuestions(this.assessmentId).subscribe({
      next: (data) => {
        this.questions = data;
      },
      error: (err) => {
        console.error('Failed to load questions:', err);
      },
    });
  }

  initForm(): void {
    this.questionForm = this.fb.group({
      questionText: ['', Validators.required],
      questionType: ['', Validators.required],
      mark: [0, [Validators.required, Validators.min(1)]],
      options: this.fb.array([this.createOption(), this.createOption()])
    });
  }

  get options(): FormArray {
    return this.questionForm.get('options') as FormArray;
  }

  createOption(): FormGroup {
    return this.fb.group({
      optionsText: ['', Validators.required],
      answer: [false]
    });
  }

  addOption(): void {
    this.options.push(this.createOption());
  }

  removeOption(index: number): void {
    if (this.options.length > 2) {
      this.options.removeAt(index);
    } else {
      alert('Each question must have at least two options.');
    }
  }

onSubmit(): void {
  if (this.questionForm.invalid || this.options.length < 1) {
    alert('Please fill all required fields and ensure at least two options.');
    return;
  }

  this.isSubmitting = true;

  const payload = {
    questionText: this.questionForm.value.questionText,
    questionType: this.questionForm.value.questionType,
    mark: this.questionForm.value.mark,
    assessmentId: this.assessmentId,
    optionId: 0, // Not used in update logic but required by DTO
    options: this.questionForm.value.options.map((opt: any) => ({
      optionsText: opt.optionsText,
      answer: opt.answer ? "True" : "False"
    }))
  };

  if (this.editMode && this.editingQuestionId !== null) {
    // Update existing question
    this.service.updateQuestion(this.editingQuestionId, payload).subscribe({
      next: () => {
        this.loadQuestions(); // Refresh list
        this.resetForm();
        alert('Question updated successfully!');
         this.loadQuestions();
      },
      error: (err) => {
        console.error('Failed to update question:', err);
        this.loadQuestions(); // Refresh list
        this.resetForm();
        alert('Question updated successfully!');
         this.loadQuestions();
      }
    });
  } else {
    // Create new question
    this.service.createQuestion(payload).subscribe({
      next: (response) => {
        this.questions.push(response);
        this.resetForm();
        alert('Question added successfully!');
         this.loadQuestions();
      },
      error: (err) => {
        console.error('Failed to create question:', err);
        alert('Failed to add question. Please try again.');
        this.isSubmitting = false;
         this.loadQuestions();
      }
    });
  }
}


editMode = false;
editingQuestionId: number | null = null;

editQuestion(question: any): void {
  this.editMode = true;
  this.editingQuestionId = question.questionId;

  this.questionForm.patchValue({
    questionText: question.questionText,
    questionType: question.questionType,
    mark: question.mark
  });

  const optionsArray: FormArray = this.fb.array([]);
  question.options.forEach((opt: any) => {
    optionsArray.push(this.fb.group({
      optionsText: [opt.optionsText, Validators.required],
      answer: [opt.answer === 'True']
    }));
  });

  this.questionForm.setControl('options', optionsArray);

  const modalElement = document.getElementById('questionModal');
  const modalInstance = new bootstrap.Modal(modalElement!);
  modalInstance.show();
}


resetForm(): void {
  this.questionForm.reset();
  this.questionForm.setControl('options', this.fb.array([this.createOption(), this.createOption()]));
  this.editMode = false;
  this.editingQuestionId = null;
  this.isSubmitting = false;

  const modalElement = document.getElementById('questionModal');
  const modalInstance = bootstrap.Modal.getInstance(modalElement!);
  modalInstance?.hide();
}

  deleteQuestion(id: number): void {
    if (!confirm('Are you sure you want to delete this question?')) {
      return;
    }

    this.service.deleteQuestion(id).subscribe({
      next: () => {
        this.questions = this.questions.filter(q => q.questionId !== id);
        alert('Question deleted successfully.');
        this.loadQuestions();
      },
      error: (err) => {
        console.error('Failed to delete question:', err);
        alert('Failed to delete question. Please try again.');
         this.loadQuestions();
      }
    });
  }
  openNewQuestionModal() {
  this.questionForm.reset();
  this.editMode = false;
}

}












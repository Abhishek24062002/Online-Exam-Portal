import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentQuestions } from './assessment-questions';

describe('AssessmentQuestions', () => {
  let component: AssessmentQuestions;
  let fixture: ComponentFixture<AssessmentQuestions>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssessmentQuestions]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssessmentQuestions);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

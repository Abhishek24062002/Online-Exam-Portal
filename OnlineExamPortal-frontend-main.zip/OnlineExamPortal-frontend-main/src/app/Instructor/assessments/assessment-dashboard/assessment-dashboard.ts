import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterModule } from '@angular/router';

import { Instructor } from '../../instructor/instructor';
import { InstructorAssessmentService } from '../../../services/instructor-assessment-service';
 
 
@Component({
  selector: 'app-assessment',
  standalone: true,
  imports: [CommonModule, RouterModule,RouterLink],
  templateUrl: './assessment-dashboard.html',
  styleUrls: ['./assessment-dashboard.css'],
})
export class Assessment implements OnInit {
  assessments: any[] = [];
  errorMessage: string = '';
 
  constructor(private service: InstructorAssessmentService) {}

  createdByUserId = localStorage.getItem('userId');
 
  ngOnInit(): void {
    this.loadAssessments();
  }
 
  loadAssessments(): void {
  this.service.getAllAssessments(this.createdByUserId).subscribe({
    next: (data) => {
      console.log('Assessments:', data); // Add this line
      this.assessments = data;
    },
    error: (err) => this.errorMessage = 'Failed to load assessments.'
  });
}

 
  
 
 
  getAssessmentType(type: number): string {
    switch (type) {
      case 0: return 'Quiz';
      case 1: return 'Assignment';
      case 2: return 'Interview';
      default: return 'Unknown';
    }
  }



confirmAndDelete(id: number): void {
  if (!confirm('Are you sure you want to delete this assessment?')) return;

  this.service.deleteAssessment(id).subscribe({
    next: () => {
      this.assessments = this.assessments.filter(a => a.assessmentId !== id);
      alert('Assessment deleted successfully.');
    },
    error: () => {
      alert('Failed to delete assessment.');
    }
  });
}

deleteAssessment(id: number): void {
  if (!confirm('Are you sure you want to delete this assessment?')) {
    return;
  }
 
  this.service.deleteAssessment(id).subscribe({
    next: () => {
      this.assessments = this.assessments.filter(a => a.assessmentId == id);
      alert('Assessment deleted successfully.');
    },
    error: (err) => {
      console.error('Failed to delete assessment:', err);
      alert('Assessment deleted successfully.');
      window.location.reload();
    }
  });
}

image="./assets/instructor-assement-header.jpg";
}
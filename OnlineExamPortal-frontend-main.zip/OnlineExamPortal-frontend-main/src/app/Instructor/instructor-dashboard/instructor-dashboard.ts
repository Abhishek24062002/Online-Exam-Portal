import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InstructorDashboardService } from '../../services/instructor-dashboard';
import { Router, RouterModule } from '@angular/router';
import { Instructor } from '../instructor/instructor';  
import { ReactiveFormsModule } from '@angular/forms';

import { InstructorPackageService } from '../../services/instructor-package-service';
import { Auth } from '../../services/auth';
import { InstructorPackage } from '../instructor-package/instructor-package';
@Component({
  selector: 'app-instructor-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, CommonModule],
  templateUrl: './instructor-dashboard.html',
  styleUrl: './instructor-dashboard.css'
})
export class InstructorDashboard implements OnInit {
  totalUsers: number = 0;
  totalAssessments: number = 0;
  totalPackages: number = 0;
  totalApprovedRequests: number = 0;
  pendingRequestCount: number = 0;

   name: string = '';

  createbyUserId = localStorage.getItem('userId');

 
  
  packageCount : number=0;
  
 

  constructor(private instructorService: InstructorDashboardService ,private packService : InstructorPackageService, private auth : Auth)  {
    this.name = localStorage.getItem('name') || 'Instructor';
  }


  ngOnInit(): void {
    this.instructorService.getApprovedRequests().subscribe({
      next: data => this.totalApprovedRequests = data,
      error: err => console.error('Error fetching approved requests:', err)
    });

    this.instructorService.getPendingRequests().subscribe({
      next: data => {this.pendingRequestCount = data;
      console.log(this.pendingRequestCount);},
      error: err => console.error('Error fetching pending requests:', err)
    });



    this.instructorService.getTotalAssessments(this.createbyUserId).subscribe({
      next: data => this.totalAssessments = data,
      error: err => console.error('Error fetching total assessments:', err)
    });

    // this.instructorService.getTotalPackages(this.createbyUserId).subscribe({
    //   next: data => this.totalPackages = data,
    //   error: err => console.error('Error fetching total packages:', err)
    // });
   
    const id=Number(this.auth.getUserId())
    this.packService.getAllpackages(id).subscribe({
      next: (res) =>{ 
        console.log('Packages:', res);
        this.packageCount = res.length;
        console.log('Packages:', JSON.stringify(res, null, 2));
      },
      error: (err) => console.error('Failed to load packages', err)
    });
  }

 
}

import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router, RouterLink ,RouterModule} from '@angular/router';
import { Auth } from '../../services/auth';
import { Logout } from '../../shared/logout/logout';

@Component({
  selector: 'app-instructor',
  standalone: true,

  imports: [RouterLink, HttpClientModule, RouterModule,Logout],
  //imports: [RouterLink, HttpClientModule,Logout,RouterModule],

  templateUrl: './instructor.html',
  styleUrls: ['./instructor.css']
})
export class Instructor {
  name: string = '';

  constructor(private auth:Auth , private router: Router) {
    this.name = localStorage.getItem('name') || 'Instructor';
  }

  OnLogout() {
    this.auth.logout();
    this.router.navigateByUrl('entry-page/login');
  }
}

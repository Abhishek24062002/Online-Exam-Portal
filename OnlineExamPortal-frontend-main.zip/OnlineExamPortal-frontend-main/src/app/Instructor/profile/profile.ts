import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InstructorAssessmentService } from '../../services/instructor-assessment-service';
import { Instructor } from '../instructor/instructor';
 
interface UserProfile {
  userId: number;
  name: string;
  email: string;
  password: string;
  registrationDate: string;
  roleType: number;
  passwordResetToken?: string | null;
  tokenExpiry?: string | null;
  assessmentAssignments?: any[];
  candidateRequests?: any[];
}
 
@Component({
  selector: 'app-profile',
  templateUrl: './profile.html',
  styleUrls: ['./profile.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class Profile implements OnInit {
  user: UserProfile = {
    userId: 0,
    name: '',
    email: '',
    password: '',
    registrationDate: '',
    roleType: 0
  };
 
  loading = false;
  error = '';
  successMessage = '';
  showModal = false;
  showPassword = false;
  showChangePasswordModal = false;
  newPassword = '';
  confirmPassword = '';
  passwordError = '';
  profileimage = "./assets/Man.png";
 
  constructor(private http: HttpClient, private assessmentService: InstructorAssessmentService) {}
 
  ngOnInit(): void {
    this.fetchUserProfile();
  }
 
  fetchUserProfile(): void {
    this.loading = true;
    const email = localStorage.getItem('userEmail'); 
    if (!email) {
      this.error = 'No email found for logged-in user.';
      this.loading = false;
      return;
    }
 
    const encodedEmail = encodeURIComponent(email);
    const url = `https://localhost:7201/api/User/GetUser${encodedEmail}`;
 
    this.http.get<UserProfile>(url).subscribe({
      next: (data) => {
        this.user = data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load profile';
        this.loading = false;
      }
    });
  }
 
  openModal(): void {
    this.showModal = true;
  }
 
  closeModal(): void {
    this.showModal = false;
    this.successMessage = '';
    this.error = '';
  }
 
  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }
 
  updateProfile(): void {
    const updateUrl = 'https://localhost:7201/api/User/updateUserDetails';
    const payload = {
      name: this.user.name,
      email: this.user.email
    };
 
    this.http.put(updateUrl, payload).subscribe({
      next: () => {
        this.successMessage = 'Profile updated successfully!';
        this.closeModal();
        this.fetchUserProfile();
      },
      error: () => {
        this.error = 'Failed to update profile';
      }
    });
  }
 
  openChangePasswordModal(): void {
    this.showChangePasswordModal = true;
    this.newPassword = '';
    this.confirmPassword = '';
    this.passwordError = '';
  }
 
  closeChangePasswordModal(): void {
    this.showChangePasswordModal = false;
    this.passwordError = '';
  }
 
  updatePassword(): void {
    if (this.newPassword !== this.confirmPassword) {
      this.passwordError = 'Passwords do not match.';
      return;
    }
 
    const updateUrl = 'https://localhost:7201/api/User/updateUserDetails';
    const payload = {
      name: this.user.name,
      email: this.user.email,
      password: this.newPassword
    };
 
    this.http.put(updateUrl, payload).subscribe({
      next: () => {
        this.successMessage = 'Password updated successfully!';
        this.closeChangePasswordModal();
        this.fetchUserProfile();
      },
      error: () => {
        this.passwordError = 'Failed to update password.';
      }
    });
  }
}
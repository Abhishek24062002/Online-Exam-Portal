// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-assign-assessment',
//   imports: [],
//   templateUrl: './assign-assessment.html',
//   styleUrl: './assign-assessment.css'
// })
// export class AssignAssessment {

// }




// import { Component } from '@angular/core';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
// import { CommonModule } from '@angular/common';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { switchMap } from 'rxjs/operators';
// import { of } from 'rxjs';



// @Component({
//   selector: 'app-assign-assessment',
//   standalone: true,
//   imports: [CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule],
//   templateUrl: './assign-assessment.html',
//   styleUrls: ['./assign-assessment.css']
// })
// export class AssignAssessmentComponent {
//   userId: number | null = null;
//   assessmentId: number | null = null;
//   assignedAssessments: number[] = [];
//   message: string = '';

//   constructor(private http: HttpClient) {}

//   getAssignedAssessments(userId: number) {
//     const url = `https://localhost:7201/api/AssessmentAssignment/user/${userId}`;
//     this.http.get<any[]>(url).subscribe({
//       next: (data) => {
//         this.assignedAssessments = data.map(a => a.assessmentId);
//       },
//       error: (err) => {
//         console.error('Error fetching assigned assessments', err);
//         this.assignedAssessments = [];
//       }
//     });
//   }

//   onUserChange() {
//     if (this.userId) {
//       this.getAssignedAssessments(this.userId);
//     }
//   }

//   // assignAssessment() {
//   //   if (!this.userId || !this.assessmentId) {
//   //     this.message = '⚠️ Please enter both User ID and Assessment ID.';
//   //     return;
//   //   }
  
//   //   // Refresh assigned assessments before checking
//   //   this.getAssignedAssessments(this.userId);
  
//   //   setTimeout(() => {
//   //     if (this.assignedAssessments.includes(Number(this.assessmentId))) {
//   //       this.message = '⚠️ This user has already been assigned this assessment.';
//   //       return;
//   //     }
  
//   //     const url = `https://localhost:7201/api/AssessmentAssignment/enroll?userId=${this.userId}&assessmentId=${this.assessmentId}`;
//   //     this.http.post(url, {}).subscribe({
//   //       next: (response: any) => {
//   //         this.message = `✅ ${response.message}`;
//   //         this.getAssignedAssessments(this.userId!);
//   //       },
//   //       error: (err) => {
//   //         console.error('Assignment failed', err);
//   //         this.message = '❌ Failed to assign assessment.';
//   //       }
//   //     });
//   //   }, 500); // Delay to allow async fetch to complete



//   assignAssessment() {
//     if (!this.userId || !this.assessmentId) {
//       this.message = '⚠️ Please enter both User ID and Assessment ID.';
//       return;
//     }
  
//     const url = `https://localhost:7201/api/AssessmentAssignment/user/${this.userId}`;
//     this.http.get<any[]>(url).pipe(
//       // First get assigned assessments
//       switchMap((data) => {
//         this.assignedAssessments = data.map(a => a.assessmentId);
  
//         if (this.assignedAssessments.includes(Number(this.assessmentId))) {
//           this.message = '⚠️ This user has already been assigned this assessment.';
//           return of(null); // Stop here
//         }
  
//         // Proceed to assign
//         const assignUrl = `https://localhost:7201/api/AssessmentAssignment/enroll?userId=${this.userId}&assessmentId=${this.assessmentId}`;
//         return this.http.post(assignUrl, {});
//       })
//     ).subscribe({
//       next: (response: any) => {
//         if (response) {
//           this.message = `✅ ${response.message}`;
//           this.getAssignedAssessments(this.userId!); // Refresh list
//         }
//       },
//       error: (err) => {
//         console.error('Assignment failed', err);
//         this.message = '❌ Failed to assign assessment.';
//       }
//     });
//   }  
// }  





import { Component } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { switchMap } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-assign-assessment',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './assign-assessment.html',
  styleUrls: ['./assign-assessment.css']
})
export class AssignAssessmentComponent {
  userId: number | null = null;
  assessmentId: number | null = null;
  assignedAssessments: number[] = [];
  message: string = '';

  constructor(private http: HttpClient) {}

  getAssignedAssessments(userId: number) {
    const url = `https://localhost:7201/api/AssessmentAssignment/user/${userId}`;
    this.http.get<any[]>(url).subscribe({
      next: (data) => {
        this.assignedAssessments = data.map(a => a.assessmentId);
      },
      error: (err) => {
        console.error('Error fetching assigned assessments', err);
        this.assignedAssessments = [];
      }
    });
  }

  isAlreadyAssigned(): boolean {
    return this.assessmentId !== null && this.assignedAssessments.includes(this.assessmentId);
  }
  

  onUserChange() {
    if (this.userId) {
      this.getAssignedAssessments(this.userId);
    }
  }

  assignAssessment() {
    if (!this.userId || !this.assessmentId) {
      this.message = '⚠️ Please enter both User ID and Assessment ID.';
      return;
    }

    const url = `https://localhost:7201/api/AssessmentAssignment/user/${this.userId}`;
    this.http.get<any[]>(url).pipe(
      switchMap((data) => {
        this.assignedAssessments = data.map(a => a.assessmentId);

        if (this.assignedAssessments.includes(Number(this.assessmentId))) {
          this.message = '⚠️ This user has already been assigned this assessment.';
          return of(null);
        }

        const assignUrl = `https://localhost:7201/api/AssessmentAssignment/enroll?userId=${this.userId}&assessmentId=${this.assessmentId}`;
        return this.http.post(assignUrl, {});
      })
    ).subscribe({
      next: (response: any) => {
        if (response) {
          this.message = `✅ ${response.message}`;
          this.getAssignedAssessments(this.userId!);
        }
      },
      error: (err) => {
        console.error('Assignment failed', err);
        this.message = '❌ Failed to assign assessment.';
      }
    });
  }
}


